<?php


    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        //if(!empty($_FILES['upload']['tmp_name'])){
				//	$dest_path = $this->config->item('upload_path');
				//	$destination = $dest_path.'procedure-forms-uploads/';
				//	$NewImageName = rand(4,10000)."-".$_FILES['upload']['name'];
				//	$transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
				//	move_uploaded_file($_FILES['upload']['tmp_name'], $destination.$NewImageName);
				//	$_POST['upload'] = $transaction_img;
			//	}
        
        
        $sql = "SELECT * FROM `pre_embryo_transfer_iui` WHERE iic_id=$iic_id";
        $select_result = run_select_query($sql); 
		
		
	 if(!empty($_POST['procedures']) && isset($_POST['procedures'])){
            //$_POST['physical_examination'] = serialize($_POST['physical_examination']);
			$_POST['procedures']=implode(',', $_POST['procedures']);
        }
        if(!empty($_POST['applicablemedicine']) && isset($_POST['applicablemedicine'])){
            // $_POST['applicablemedicine'] = serialize($_POST['applicablemedicine']);
			 $_POST['applicablemedicine']=implode(',', $_POST['applicablemedicine']);
			 
        }
		
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `pre_embryo_transfer_iui` SET ";
            $sqlArr = array();
         
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE  pre_embryo_transfer_iui SET ";
          
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE iic_id=$iic_id";
        }
        $result = run_form_query($query);  
        
     
	  if($result){
         header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Discharge form inserted!').'&t='.base64_encode('success'));
        	die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		  die();
        }
	 
	 
    }
    $sql = "SELECT * FROM `pre_embryo_transfer_iui` WHERE iic_id=$iic_id";
$select_result = run_select_query($sql);
?>



 <?php $procedures = $applicablemedicine = array();
    if(!empty($select_result['procedures'])){
        $procedures = explode(',',$select_result['procedures']);
    }
    if(!empty($select_result['applicablemedicine'])){
        $applicablemedicine = explode(',', $select_result['applicablemedicine']);
    }
  ?>



<div class="ga-pro">
<h3>Please strike out whichever is not applicable</h3>
<form action="" enctype='multipart/form-data' method="post">

<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
  <input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
  <input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">




 <table width="100%" class="vb45rt">
<tbody>
<tr style="background: #b3b9b7;">
<td colspan="2" width="57%">
<strong>Details of Female Partner</strong>
</td>
<td width="42%">
<strong>IIC ID: <input type="text" name="iic_id" value="<?php echo $iic_id;?>"></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Name : <?php echo $patient_data['wife_name']; ?> </strong>
</td>
<td width="42%">
<strong>Husband Name : <?php echo $patient_data['husband_name']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Age: <?php echo $patient_data['wife_age']; ?> </strong>
</td>
<td width="42%">
<strong>Age: <?php echo $patient_data['husband_age']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Blood group: <input type="text" name="female_blood_group" value="<?php echo isset($select_result['female_blood_group'])?$select_result['female_blood_group']:""; ?>"></strong>

</td>
<td width="42%">
<strong>Blood group: <input type="text" name="husband_blood_group" value="<?php echo isset($select_result['husband_blood_group'])?$select_result['husband_blood_group']:""; ?>"></strong>

</td>
</tr>
<tr>
<td width="50%">
<strong>Name of Procedure : <input type="checkbox" class="PRE-EMBRYO-TRANSFER" name="procedures[]" value="PRE-EMBRYO TRANSFER" <?php if(!empty($select_result['procedures']) && in_array('PRE-EMBRYO TRANSFER',$procedures)){echo "checked";}?>>PRE-EMBRYO TRANSFER <input type="checkbox" class="IUI" name="procedures[]" value="IUI" <?php if(!empty($select_result['procedures']) && in_array('IUI',$procedures)){echo "checked";}?>>IUI</strong>

 

</td>
<td colspan="2" width="50%">
 <strong>Date of procedure:  <input type="date" class="Admission" name="date_of_procedure" value="<?php echo isset($select_result['date_of_procedure'])?$select_result['date_of_procedure']:""; ?>">  </strong>
 
</td>
</tr>

</tbody>
</table>
<table>
<tbody>
<tr>
<td width="60">
Check
applicable
</td>
<td width="94">
Medication
</td>
<td width="93">
Dosage
</td>
<td width="83">
Route
</td>
<td width="122">
Times
</td>
<td width="56">
Timings
</td>
<td width="69">
When to
start
</td>
<td width="46">
How
many
days
</td>
</tr>
<tr>
<td>


 



 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Ceftum (500 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Ceftum (500 mg)',$applicablemedicine)){echo "checked";}?>>
 
</td>
<td width="94">
Tab Ceftum (500 mg)
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Twice daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Three
days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap.Pantoprazole (40 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Cap.Pantoprazole (40 mg)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Cap.Pantoprazole (40 mg)
</td>
<td width="93">
1 CAP
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
Before meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Three
days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Syp cremaffin" <?php if(!empty($select_result['applicablemedicine']) && in_array('Syp cremaffin',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="94">
Syp cremaffin
</td>
<td width="93">
1 TSF
</td>
<td width="83">
Oral
</td>
<td width="122">
SOS
</td>
<td width="56">
After dinner
</td>
<td width="69">
SOS(if
constipation
</td>
<td width="46"></td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Estrabet (2mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Estrabet (2mg)',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="94">
Tab Estrabet (2mg)
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Twice /thrice/four times daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Ecosprin (75 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Ecosprin (75 mg)',$applicablemedicine)){echo "checked";}?>>
 
</td>
<td width="94">
Tab Ecosprin (75 mg)
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
Tomorrow
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Inj sugest" <?php if(!empty($select_result['applicablemedicine']) && in_array('Inj sugest',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Inj sugest
</td>
<td width="93">
100 mg
</td>
<td width="83">
intramuscular
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Medrol (8mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Medrol (8mg)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Tab Medrol (8mg)
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
Tomorrow
</td>
<td width="46">
Three
days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Wysolone" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Wysolone',$applicablemedicine)){echo "checked";}?>>
 
</td>
<td width="94">
Tab Wysolone
</td>
<td width="93">
5mg/10mg/15mg
</td>
<td width="83">
oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
Tomorrow
</td>
<td width="46">
Three
days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Crinone gel8%" <?php if(!empty($select_result['applicablemedicine']) && in_array('Crinone gel8%',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="94">
Crinone gel8%
</td>
<td width="93">
QS
</td>
<td width="83">
Vaginal
</td>
<td width="122">
Once daily
</td>
<td width="56">
Before going
to sleep
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Duphaston (10 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Duphaston (10 mg)',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="94">
Tab Duphaston (10 mg)
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Thrice daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil L" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil L',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Biophil L
</td>
<td width="93">
1 CAP
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil O3" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil O3',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Biophil O3
</td>
<td width="93">
1 CAP
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil Q" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil Q',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Biophil Q
</td>
<td width="93">
1 CAP
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="BIOLARG SACHET" <?php if(!empty($select_result['applicablemedicine']) && in_array('BIOLARG SACHET',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
BIOLARG SACHET
</td>
<td width="93">
1 SACHET
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Inj clexane" <?php if(!empty($select_result['applicablemedicine']) && in_array('Inj clexane',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="94">
Inj clexane
</td>
<td width="93">
40 mg
</td>
<td width="83">
subcutaneous
</td>
<td width="122">
Once daily/alternate/biweekly
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Inj Puberjen JO 7500" <?php if(!empty($select_result['applicablemedicine']) && in_array('Inj Puberjen JO 7500',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Inj Puberjen JO 7500
</td>
<td width="93">
100 mg
</td>
<td width="83">
subcutaneous
</td>
<td width="122">
Once daily/alternate/biweekly
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Allegra" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Allegra',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Tab Allegra
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Montair LC" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Montair LC',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="94">
Tab Montair LC
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Shelcal (500 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Shelcal (500 mg)',$applicablemedicine)){echo "checked";}?>>
 
</td>
<td width="94">
Tab Shelcal (500 mg)
</td>
<td width="93">
1 TAB
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap Fericip XT" <?php if(!empty($select_result['applicablemedicine']) && in_array('Cap Fericip XT',$applicablemedicine)){echo "checked";}?>>
 
</td>
<td width="94">
Cap Fericip XT
</td>
<td width="93">
1 CAP
</td>
<td width="83">
Oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Biophil Vita" <?php if(!empty($select_result['applicablemedicine'])  && in_array('Tab Biophil Vita',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Tab Biophil Vita
</td>
<td width="93">
1 cap
</td>
<td width="83">
oral
</td>
<td width="122">
Once daily
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
Six days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap Vit D3 (60000 IU)" <?php if(!empty($select_result['applicablemedicine']) && isset($select_result['applicablemedicine']) && in_array('Cap Vit D3 (60000 IU)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="94">
Cap Vit D3 (60000 IU)
</td>
<td width="93">
1 CAP
</td>
<td width="83">
oral
</td>
<td width="122">
weekly
</td>
<td width="56">
After meals
</td>
<td width="69">
immediately
</td>
<td width="46">
six days
</td>
</tr>
</tbody>
</table>
<div class="nb56ty">
  <label for="other">Other Medication1:</label>
  <input type="text" class="other1" name="Other_Medication1" value="<?php echo isset($select_result['Other_Medication1'])?$select_result['Other_Medication1']:""; ?>"><br> 
    <label for="other">Other Medication2:</label>
  <input type="text" class="other2" name="Other_Medication2" value="<?php echo isset($select_result['Other_Medication2'])?$select_result['Other_Medication2']:""; ?>"><br> 
    <label for="other">Other Medication3:</label>
  <input type="text" class="other3" name="Other_Medication3" value="<?php echo isset($select_result['Other_Medication3'])?$select_result['Other_Medication3']:""; ?>"><br>
</div>
   
<input type="submit" name="submit" value="submit">
<style>

input[type=checkbox], input[type=radio] {
    opacity: 1 !important;
    left: 0 !important;
    position: unset !important;
    margin: 9px !important;
}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.vb45rt td {text-align: left; padding-left: 10px;}
td {
  border: 1px solid #000;
  text-align: center;
  padding: 5px;
  
}

.ga-pro h3 {
      text-align: center;
    font-size: 25px;
}
form {
    margin-bottom: 0px;
}
.nb56ty {
    border: 1px solid #000;
}
.nb56ty input {
    width: 100%;
}
</style>    