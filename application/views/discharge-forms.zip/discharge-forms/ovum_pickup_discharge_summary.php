<?php
    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        
        $sql = "SELECT * FROM `ovum_pickup_discharge_summary` WHERE iic_id=$iic_id";
        $select_result = run_select_query($sql); 
        
          if(!empty($_POST['physical_examination']) && isset($_POST['physical_examination'])){
            $_POST['physical_examination'] = implode(',', $_POST['physical_examination']);
        }
        if(!empty($_POST['applicablemedicine']) && isset($_POST['applicablemedicine'])){
             $_POST['applicablemedicine'] = implode(',', $_POST['applicablemedicine']);
        }
        
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `ovum_pickup_discharge_summary` SET ";
            $sqlArr = array();
          
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE  ovum_pickup_discharge_summary SET ";
           
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE iic_id=$iic_id";
        }
         $result = run_form_query($query); 
        
      if($result){
         header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Discharge form inserted!').'&t='.base64_encode('success'));
        	die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		  die();
        }
    }
    $sql = "SELECT * FROM `ovum_pickup_discharge_summary` WHERE iic_id=$iic_id";
$select_result = run_select_query($sql);
?>


<?php $physical = $applicablemedicine = array();
    if(!empty($select_result['physical_examination'])){
        $physical = explode(',',$select_result['physical_examination']);
        
            }
    if(!empty($select_result['applicablemedicine'])){
        $applicablemedicine = explode(',',$select_result['applicablemedicine']);
             
    }
  ?>


<div class="ga-pro">
<h3>Discharge Summary</h3>
<form action="" enctype='multipart/form-data' method="post">


  <input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
  <input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
  <input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">
    
    








<div style="float: left; margin-bottom: 10px;">
  <label for="Admission">Date of Admission:</label>
  <input type="date" class="Admission" name="date_of_addmission" value="<?php echo isset($select_result['date_of_addmission'])?$select_result['date_of_addmission']:""; ?>">
 </div>      
<div style="float: right; margin-bottom: 10px;">
  <label for="Discharge">Date of Discharge:</label>
  <input type="date" class="Discharge" name="date_of_discharge" value="<?php echo isset($select_result['date_of_discharge'])?$select_result['date_of_discharge']:""; ?>">
 </div>       

<table width="100%" class="vb45rt">
<tbody>
<tr style="background: #b3b9b7;">
<td colspan="2" width="57%">
<strong>Details of Female Partner</strong>
</td>
<td width="42%">
<strong>IIC ID: <input type="text" name="iic_id" value="<?php echo $iic_id;?>"></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Name : <?php echo $patient_data['wife_name']; ?> </strong>
</td>
<td width="42%">
<strong>Husband&rsquo;s name : <?php echo $patient_data['husband_name']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Age: <?php echo $patient_data['wife_age']; ?></strong>
</td>
<td width="42%">
<strong>Age: <?php echo $patient_data['husband_age']; ?></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Blood group: <input type="text" name="female_blood_group" value="<?php echo isset($select_result['female_blood_group'])?$select_result['female_blood_group']:""; ?>"></strong>
</td>
<td width="42%">
<strong>Blood group: <input type="text" name="husband_blood_group" value="<?php echo isset($select_result['husband_blood_group'])?$select_result['husband_blood_group']:""; ?>"></strong>
</td>
</tr>



<tr>
<td colspan="2" width="57%">
<strong>List of Issues:

 <textarea name="female_issues" style="width:100%; height:150px;" > <?php echo isset($select_result['female_issues'])?$select_result['female_issues']:""; ?> </textarea>
</strong>
</td>
<td width="42%">
<strong>List of Issues: 

 <textarea name="male_issues" style="width:100%; height:150px;" > <?php echo isset($select_result['male_issues'])?$select_result['male_issues']:""; ?> </textarea>
</strong>

</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Medical complication:
<textarea name="female_complication" style="width:100%; height:150px;"  > <?php echo isset($select_result['female_complication'])?$select_result['female_complication']:""; ?> </textarea>
</strong>
</td>
<td width="42%">
<strong>Medical complication: 

<textarea name="male_complication" style="width:100%; height:150px;"  > <?php echo isset($select_result['male_complication'])?$select_result['male_complication']:""; ?> </textarea>
</strong>
</td>
</tr>





<tr>
<td width="50%">
<strong>Name of Procedure : Ovum Pickup</strong>
</td>
<td colspan="2" width="50%">
 <strong>Date of procedure:  <input type="date" class="date_of_procedure" name="date_of_procedure" value="<?php echo isset($select_result['date_of_procedure'])?$select_result['date_of_procedure']:""; ?>">  </strong> 
</td>
</tr>
</tbody>
</table> 
<div class="sec2">
<p><strong>Physical Examination: </strong></p>
<p><input type="radio" id="Conscious" name="Conscious" value="Conscious" <?php if(isset($select_result['Conscious'])  && $select_result['Conscious']== "Conscious"){ echo "checked";} ?>>
  <label for="Conscious">Conscious</label><br>
  <input type="radio" id="oriented" name="Conscious" value="oriented" <?php if(isset($select_result['Conscious']) && $select_result['Conscious'] == "oriented"){ echo "checked";} ?>>
  <label for="oriented">oriented</label><br>  
</p>
 <input type="checkbox" class="pallor" name="physical_examination[]" value="No pallor" <?php if(!empty($select_result['physical_examination']) && in_array('No pallor',$physical)){echo "checked";}?>>
 <label for="Condition">No pallor</label>
  <input type="checkbox" class="icterus" name="physical_examination[]" value="icterus"  <?php if(!empty($select_result['physical_examination']) && in_array('icterus',$physical)){echo "checked";}?>>
 <label for="Condition">icterus</label>
  <input type="checkbox" class="cyanosis" name="physical_examination[]" value="cyanosis" <?php if(!empty($select_result['physical_examination']) && in_array('cyanosis',$physical)){echo "checked";}?>>
 <label for="Condition">cyanosis</label>
<input type="checkbox" class="clubbing" name="physical_examination[]" value="digital clubbing" <?php if(!empty($select_result['physical_examination']) && in_array('digital clubbing',$physical)){echo "checked";}?>>
 <label for="Condition">digital clubbing</label>
<input type="checkbox" class="lymphadenopathy" name="physical_examination[]" value="lymphadenopathy" <?php if(!empty($select_result['physical_examination']) && in_array('lymphadenopathy',$physical)){echo "checked";}?>>
 <label for="Condition">lymphadenopathy</label>
 <input type="checkbox" class="oedema" name="physical_examination[]" value="pedal oedema" <?php if(!empty($select_result['physical_examination']) && in_array('pedal oedema',$physical)){echo "checked";}?>>
 <label for="Condition">pedal oedema</label>
 </p>
 <label for="BP">BP</label>
  <input type="text" class="bp" name="Patient_BP" value="<?php echo isset($select_result['Patient_BP'])?$select_result['Patient_BP']:""; ?>"> mm Hg <br>
 <label for="PR">PR</label>
  <input type="text" class="PR" name="Patient_PR" value="<?php echo isset($select_result['Patient_PR'])?$select_result['Patient_PR']:""; ?>"> / min <br>
 <label for="PR">RR</label>
  <input type="text" class="RR" name="Patient_RR" value="<?php echo isset($select_result['Patient_RR'])?$select_result['Patient_RR']:""; ?>"> / min <br>
 <label for="PR">Temp</label>
  <input type="text" class="Temp" name="Patient_Temp" value="<?php echo isset($select_result['Patient_Temp'])?$select_result['Patient_Temp']:""; ?>"> F<br>
 <label for="PR">SPO2</label>
  <input type="text" class="SPO2" name="Patient_SPO2" value="<?php echo isset($select_result['Patient_SPO2'])?$select_result['Patient_SPO2']:""; ?>"> on room air<br>
 <label for="CVS">CVS</label>
  <input type="text" class="CVS" name="Patient_CVS" value="<?php echo isset($select_result['Patient_CVS'])?$select_result['Patient_CVS']:""; ?>"><br>
 <label for="RS">RS</label>
  <input type="text" class="RS" name="Patient_RS" value="<?php echo isset($select_result['Patient_RS'])?$select_result['Patient_RS']:""; ?>"><br>
 <label for="P/A">P/A</label>
  <input type="text" class="PA" name="Patient_PA" value="<?php echo isset($select_result['Patient_PA'])?$select_result['Patient_PA']:""; ?>"><br>
 <label for="CNS">CNS</label>
  <input type="text" class="CNS" name="Patient_CNS" value="<?php echo isset($select_result['Patient_CNS'])?$select_result['Patient_CNS']:""; ?>"><br>
</div>  
</div>  
<div class="sec2">
 <label for="Course">Course in the hospital:</label>
  <input type="text" class="Course" name="Patient_Course" style="width: 100%;" value="<?php echo isset($select_result['Patient_Course'])?$select_result['Patient_Course']:""; ?>">
</div> 
<div class="sec2">
 <label for="Condition">Condition at Discharge:</label>
  <input type="text" class="Condition" name="Patient_Condition" style="width: 100%;" value="<?php echo isset($select_result['Patient_Condition'])?$select_result['Patient_Condition']:""; ?>">
</div> 

<div class="sec3">
<h4>Advice on discharge:</h4>   
<table width="623">
<tbody>
<tr>
  <td width="38">
<p><strong>Check</strong></p>
</td>
<td width="23%">
<strong>Medication</strong>
</td>
<td width="9%">
<strong>Dosage</strong>
</td>
<td width="10%">
<strong>Route</strong>
</td>
<td width="14%">
<strong>Times</strong>
</td>
<td width="13%">
<strong>Timings</strong>
</td>
<td width="13%">
<strong>When to</strong>
<strong>start</strong>
</td>
<td width="13%">
<strong>How many</strong>
<strong>days</strong>
</td>
</tr>
<tr>
  <td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="TabCeftum (500 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('TabCeftum (500 mg)',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="23%">
TabCeftum (500 mg)
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Twice daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
3 days
</td>
</tr>
<tr>
 <td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap.Pantoprazole (40 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Cap.Pantoprazole (40 mg)',$applicablemedicine)){echo "checked";}?>>
</td>  
<td width="23%">
Cap.Pantoprazole (40 mg)
</td>
<td width="9%">
1 CAP
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
Before meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
3 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Crocin(500 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Crocin(500 mg)',$applicablemedicine)){echo "checked";}?>>
</td>  
<td width="23%">
Tab Crocin(500 mg)
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
SOS <strong>Maximum three times at interval of 6 hrs. (if required)</strong>
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
1 day
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Sypcremaffin" <?php if(!empty($select_result['applicablemedicine']) && in_array('Sypcremaffin',$applicablemedicine)){echo "checked";}?>>
</td>    
<td width="23%">
Sypcremaffin
</td>
<td width="9%">
1 TSF
</td>
<td width="10%">
Oral
</td>
<td width="14%">
One TSF
</td>
<td width="13%">
After dinner
</td>
<td colspan="2" width="27%">
SOS (ifconstipation)
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Estrabet (2mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Estrabet (2mg)',$applicablemedicine)){echo "checked";}?>>
</td>    
<td width="23%">
Tab Estrabet (2mg)
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Twice /thrice/four times daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Ecosprin(75 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Ecosprin(75 mg)',$applicablemedicine)){echo "checked";}?>>
</td>     
<td width="23%">
Tab Ecosprin(75 mg)
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
Tomorrow
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Inj sugest" <?php if(!empty($select_result['applicablemedicine']) && in_array('Inj sugest',$applicablemedicine)){echo "checked";}?>>
</td>    
<td width="23%">
Inj sugest
</td>
<td width="9%">
100 mg
</td>
<td width="10%">
intramuscular
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Medrol (8mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Medrol (8mg)',$applicablemedicine)){echo "checked";}?>>

</td>   
<td width="23%">
Tab Medrol (8mg)
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
Tomorrow
</td>
<td width="13%">
3 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Wysolone" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Wysolone',$applicablemedicine)){echo "checked";}?>>
 
</td>     
<td width="23%">
Tab Wysolone
</td>
<td width="9%">
5mg/10mg/15mg
</td>
<td width="10%">
oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
Tomorrow
</td>
<td width="13%">
3 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Crinone gel"  <?php if(!empty($select_result['applicablemedicine']) && in_array('Crinone gel',$applicablemedicine)){echo "checked";}?>>
 
</td>   
<td width="23%">
Crinone gel
</td>
<td width="9%">
8%
</td>
<td width="10%">
Vaginal
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
Before going
to sleep
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Duphaston" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Duphaston',$applicablemedicine)){echo "checked";}?>>
 
</td>    
<td width="23%">
Tab Duphaston
</td>
<td width="9%">
10 mg
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Thrice daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil L" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil L',$applicablemedicine)){echo "checked";}?>>
</td>   
<td width="23%">
Biophil L
</td>
<td width="9%">
1 CAP
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil O 3" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil O 3',$applicablemedicine)){echo "checked";}?>>

</td>     
<td width="23%">
Biophil O 3
</td>
<td width="9%">
1 CAP
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil Q" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil Q',$applicablemedicine)){echo "checked";}?>>
</td>   
<td width="23%">
Biophil Q
</td>
<td width="9%">
1 CAP
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="BIOLARG" <?php if(!empty($select_result['applicablemedicine']) && in_array('BIOLARG',$applicablemedicine)){echo "checked";}?>>

</td>  
<td width="23%">
BIOLARG
</td>
<td width="9%">
1sachet
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Inj clexane" <?php if(!empty($select_result['applicablemedicine']) && in_array('Inj clexane',$applicablemedicine)){echo "checked";}?>>
</td>  
<td width="23%">
Inj clexane
</td>
<td width="9%">
40 mg
</td>
<td width="10%">
subcutaneous
</td>
<td width="14%">
Once daily/alternate/biweekly
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Inj Puberjen JO 7500" <?php if(!empty($select_result['applicablemedicine']) && in_array('Inj Puberjen JO 7500',$applicablemedicine)){echo "checked";}?>>
</td>    
<td width="23%">
Inj Puberjen JO 7500
</td>
<td width="9%">
100 mg
</td>
<td width="10%">
subcutaneous
</td>
<td width="14%">
Once daily/alternate/biweekly
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Allegra" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Allegra',$applicablemedicine)){echo "checked";}?>>

</td>   
<td width="23%">
Tab Allegra
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Montair LC" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Montair LC',$applicablemedicine)){echo "checked";}?>>

</td>   
<td width="23%">
Tab Montair LC
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Shelcal (500 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Shelcal (500 mg)',$applicablemedicine)){echo "checked";}?>>
</td>  
<td width="23%">
Tab Shelcal (500 mg)
</td>
<td width="9%">
1 TAB
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap Fericip XT" <?php if(!empty($select_result['applicablemedicine']) && in_array('Cap Fericip XT',$applicablemedicine)){echo "checked";}?>>
</td>  
<td width="23%">
Cap Fericip XT
</td>
<td width="9%">
1 CAP
</td>
<td width="10%">
Oral
</td>
<td width="14%">
Once daily
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="BIOPHIL-VITA" <?php if(!empty($select_result['applicablemedicine']) && in_array('BIOPHIL-VITA',$applicablemedicine)){echo "checked";}?>>

</td>   
<td width="144">
BIOPHIL-VITA
</td>
<td width="60">
1cap
</td>
<td width="68">
oral
</td>
<td width="91">
Once daily
</td>
<td width="87">
After meals
</td>
<td width="87">
immediately
</td>
<td width="86">
6 days
</td>
</tr>
<tr>
  <td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap Vit D3 (60000 IU)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Cap Vit D3 (60000 IU)',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="23%">
Cap Vit D3 (60000 IU)
</td>
<td width="9%">
1 CAP
</td>
<td width="10%">
oral
</td>
<td width="14%">
weekly
</td>
<td width="13%">
After meals
</td>
<td width="13%">
immediately
</td>
<td width="13%">
6 days
</td>
</tr>
</tbody>
</table>

<div class="nb56ty">
  <label for="other">Other Medication1:</label>
  <input type="text" class="other1" name="Other_Medication1" value="<?php echo isset($select_result['Other_Medication1'])?$select_result['Other_Medication1']:""; ?>"><br> 
  <label for="other">Other Medication2:</label>
  <input type="text" class="other2" name="Other_Medication2" value="<?php echo isset($select_result['Other_Medication2'])?$select_result['Other_Medication2']:""; ?>"><br> 
 <label for="other">Other Medication3:</label>
  <input type="text" class="other3" name="Other_Medication3" value="<?php echo isset($select_result['Other_Medication3'])?$select_result['Other_Medication3']:""; ?>"><br> 
</div>

<div class="sec2">
<ul>
<li>Continue thyroid /antihypertensive/ diabetes medications as have been taking previously.</li>
<li>To report in emergency of the hospital near by immediately if patient has abdominal pain/ vaginal bleeding/ fever /excessive cough /giddiness /vomiting/nausea/purulent discharge.</li>
<li>To take soft diet on the day of ovum pick up.</li>
<li>To resume normal diet after one day of ovum pick up.</li>
</ul>
</div>


</div>



<div class="sec2" style="display: flex; padding-top: 5px;">
 <label for="BP"><b>Follow Up Advice:</b> Review with DR.</label>
  <input type="text" class="followup" name="Doctor_name"  value="<?php echo isset($select_result['Doctor_name'])?$select_result['Doctor_name']:""; ?>">
<br>
  <label for="followup">on </label>
  <input type="date" class="follow-up" name="advice"  value="<?php echo isset($select_result['advice'])?$select_result['advice']:""; ?>">

<br>
  <input type="time" id="appt" name="appt"  value="<?php echo isset($select_result['appt'])?$select_result['appt']:""; ?>">
  <label for="followup">in with Prior appointment. </label>

</div>


<div class="sec2">
  <p><strong>Please seek expert Medical Advice If:</strong></p>
<ul>
<li>High grade Fever.</li>
<li>Loose stools/ coffee coloured vomiting or passing black stools like coal tar.</li>
<li>Bleeding from any site.</li>
<li>Chest pain, breathing difficulty, loss of consciousness, profuse sweating, giddiness, palpitation, pain in abdomen.</li>
<li>Reduced urine output.</li>
<li>Severe weakness/ severe mouth ulcers.</li>
<li>Rash over skin/ swelling over body or lower limbs or face.</li>
</ul>

</div>
<div class="sec2">
 <label for="Sr IVF Consultant">Sr IVF Consultant</label>
  <input type="text" class="IVFConsultant" name="IVF_Consultant" value="<?php echo isset($select_result['IVF_Consultant'])?$select_result['IVF_Consultant']:""; ?>">
</div>


<input type="submit" name="submit" value="submit">

</form>
<style>

input[type=checkbox], input[type=radio] {
    opacity: 1 !important;
    left: 0 !important;
    position: unset !important;
    margin: 9px !important;
}


.sec3 {
    
    border: 1px solid #000;
    padding: 5px;
}


.sec2 {
    border: 1px solid #000;
}

.sec2 p {
    margin: 0px;
    padding: 2px 10px;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td {
  border: 1px solid #000;
  text-align: center;
  padding: 5px;
  
}

.ga-pro h3 {
      text-align: center;
    font-size: 25px;
}
form {
    padding-left: 10px;
    margin-bottom: 4px;
}
.nb56ty {
    border: 1px solid #000;
}
.nb56ty input {
    width: 100%;
}
.vb45rt td {text-align: left; padding-left: 10px;}
</style>    