<?php


    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        //if(!empty($_FILES['upload']['tmp_name'])){
				//	$dest_path = $this->config->item('upload_path');
				//	$destination = $dest_path.'procedure-forms-uploads/';
				//	$NewImageName = rand(4,10000)."-".$_FILES['upload']['name'];
				//	$transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
				//	move_uploaded_file($_FILES['upload']['tmp_name'], $destination.$NewImageName);
				//	$_POST['upload'] = $transaction_img;
			//	}
        
        
        if(!empty($_POST['physical_examination']) && isset($_POST['physical_examination'])){
            $_POST['physical_examination'] = implode(',', $_POST['physical_examination']);
        }
    
		
        $sql = "SELECT * FROM `withdrawal_bleeding_for_period` WHERE iic_id=$iic_id";
        $select_result = run_select_query($sql); 
        $select_result = array();
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `withdrawal_bleeding_for_period` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE  withdrawal_bleeding_for_period SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE iic_id=$iic_id";
        }
		
		
		
        $result = run_form_query($query);     
        
     if($result){
         header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Discharge form inserted!').'&t='.base64_encode('success'));
        	die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		  die();
        }
    }
    $sql = "SELECT * FROM `withdrawal_bleeding_for_period` WHERE iic_id=$iic_id ORDER BY id DESC limit 1";
$select_result = run_select_query($sql);
?>


<div class="ga-pro">
<h3>INDIA IVF CLINIC</h3>

    
<form action="" enctype='multipart/form-data' method="post">
 
  <input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
  <input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
  <input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">
  
  <?php $physical = array();
    if(!empty($select_result['physical_examination'])){
        $physical = explode(',',$select_result['physical_examination']);
    }
   
  ?>
 
 

 <div style="float: left; margin-bottom: 10px;">
  <label for="Admission">Center</label>
  <input type="text" class="Center" name="center" value="<?php echo isset($select_result['center'])?$select_result['center']:""; ?>"> 
 </div>      
<div style="float: right; margin-bottom: 10px;">
  <label for="Discharge">Date of Discharge:</label>
  <input type="date" class="Discharge" name="date_of_discharge" value="<?php echo isset($select_result['date_of_discharge'])?$select_result['date_of_discharge']:""; ?>">
 
 </div>  
 
 
 
 
 
 
 
 
 
<table width="100%" class="vb45rt">
<tbody>
<tr style="background: #b3b9b7;">
<td colspan="2" width="57%">
<strong>Details of Female Partner</strong>
</td>
<td width="42%">
<strong>IIC ID: <input type="text" name="iic_id" value="<?php echo $iic_id;?>"></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Name : <?php echo $patient_data['wife_name']; ?> </strong>
</td>
<td width="42%">
<strong>Husband&rsquo;s name : <?php echo $patient_data['husband_name']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Age: <?php echo $patient_data['wife_age']; ?></strong>
</td>
<td width="42%">
<strong>Age: <?php echo $patient_data['husband_age']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Blood group: <input type="text" name="female_blood_group" value="<?php echo isset($select_result['female_blood_group'])?$select_result['female_blood_group']:""; ?>"></strong>
</td>
<td width="42%">
<strong>Blood group: <input type="text" name="husband_blood_group" value="<?php echo isset($select_result['husband_blood_group'])?$select_result['husband_blood_group']:""; ?>"></strong>
</td>
</tr>

</tbody>
</table> 


  <h3>WITHDRAWAL BLEEDING FOR PERIOD NOT COME IN NON PREGNANT FEMALE</h3> 
  <br>
<div class="sec2">
  

  <input type="checkbox" class="checkbox" id="Estrabet" name="physical_examination[]" value="Estrabet" <?php if(!empty($select_result['physical_examination']) && in_array('Estrabet', $physical)){echo "checked";}?>>
  <label for="Estrabet">Tab Estrabet 2 mg - BD for - 10 days - after meals</label>
  <input type="checkbox" class="checkbox" id="Meprate" name="physical_examination[]" value="Meprate" <?php if(!empty($select_result['physical_examination']) && in_array('Meprate', $physical)){echo "checked";}?>>
  <label for="Estrabet">Tab Meprate 10 mg - BD for - 10 days - after meals</label>
<input type="checkbox" class="checkbox" id="Other" name="physical_examination[]" value="Other" <?php if(!empty($select_result['physical_examination']) && in_array('Other', $physical)){echo "checked";}?>>
  
  
  <label for="Estrabet">Other</label>

 <textarea name="Other" style="width:100%; height:150px;" > <?php echo isset($select_result['Other'])?$select_result['Other']:""; ?> </textarea>




<br>

<input type="submit" name="submit" value="submit">

</form>

</div>  
</div>  
  

<style>

.sec3 {
   
    border: 1px solid #000;
    padding: 5px;
}
.sec21 {
    border: 1px solid #000;
}

.sec21 p {
    margin: 20px;
    padding: 2px 10px;
}

.sec2 {
    border: 1px solid #000;
}

.sec2 p {
    margin: 0px;
    padding: 2px 10px;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td {
  border: 1px solid #000;
  text-align: center;
  padding: 5px;
  
}

.ga-pro h3 {
      text-align: center;
    font-size: 25px;
}

.ga-pro h4 {
      text-align: center;
    font-size: 20px;
}

form {
    padding-left: 10px;
    margin-bottom: 4px;
}

.nb56ty {
    border: 1px solid #000;
}
.nb56ty input {
    width: 100%;
}
.vb45rt td {text-align: left; padding-left: 10px;}
.sec2 ul li {    margin-bottom: 5px;}
input[type=checkbox], input[type=radio] {
    opacity: 1 !important;
    left: 0 !important;
    position: unset !important;
    margin: 9px !important;
}
.checkbox {
  appearance: none;
  transform:translateY(-50%);
  background-color: #F44336;
  width:23px;
  height:23px;
  border-radius:40px;
  margin:0px;
  outline: none; 
  display: inline-block !important;
  transition:background-color .5s;
  float: left;
}
[type="checkbox"] + label {
  float: left !important;
  padding-left: 0 !important;
}

.checkbox:before {
  content:'';
  position: absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%) rotate(45deg);
  background-color:#ffffff;
  width:20px;
  height:5px;
  border-radius:40px;
  transition:all .5s;
}

.checkbox:after {
  content:'';
  position: absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%) rotate(-45deg);
  background-color:#ffffff;
  width:20px;
  height:5px;
  border-radius:40px;
  transition:all .5s;
}
.checkbox:checked {
  background-color:#4CAF50;
}
.checkbox:checked:before {
  content:'';
  position: absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%) translate(-4px,3px) rotate(45deg);
  background-color:#ffffff;
  width:12px;
  height:5px;
  border-radius:40px;
}

.checkbox:checked:after {
  content:'';
  position: absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%) translate(3px,2px) rotate(-45deg);
  background-color:#ffffff;
  width:16px;
  height:5px;
  border-radius:40px;
}
.sec2 {
  border: 1px solid #000;
  padding: 34px 12px;
}
</style>    