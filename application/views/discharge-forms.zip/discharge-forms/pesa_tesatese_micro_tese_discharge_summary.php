<?php


    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        //if(!empty($_FILES['upload']['tmp_name'])){
				//	$dest_path = $this->config->item('upload_path');
				//	$destination = $dest_path.'procedure-forms-uploads/';
				//	$NewImageName = rand(4,10000)."-".$_FILES['upload']['name'];
				//	$transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
				//	move_uploaded_file($_FILES['upload']['tmp_name'], $destination.$NewImageName);
				//	$_POST['upload'] = $transaction_img;
			//	}
    
        
        $sql = "SELECT * FROM `pesa_tesatese_micro_tese_discharge_summary` WHERE iic_id=$iic_id";
        $select_result = run_select_query($sql); 
        
        
         if(!empty($_POST['procedures']) && isset($_POST['procedures'])){
            //$_POST['physical_examination'] = serialize($_POST['physical_examination']);
			$_POST['procedures']=implode(',', $_POST['procedures']);
        }
        
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `pesa_tesatese_micro_tese_discharge_summary` SET ";
            $sqlArr = array();
            
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE  pesa_tesatese_micro_tese_discharge_summary SET ";
     
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE iic_id=$iic_id";
        }
       $result = run_form_query($query); 
        
      if($result){
         header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Discharge form inserted!').'&t='.base64_encode('success'));
        	die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		  die();
        }
    }
    $sql = "SELECT * FROM `pesa_tesatese_micro_tese_discharge_summary` WHERE iic_id=$iic_id";
$select_result = run_select_query($sql);
?>



 <?php $procedures = array();
    if(!empty($select_result['procedures'])){
        $procedures = explode(',',$select_result['procedures']);
    }
   
  ?>




<form action="" enctype='multipart/form-data' method="post">
    
    <input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
  <input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
  <input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">
    
    
    
<div class="ga-pro">
<h3>Discharge Summary</h3>
<h4>Department of Embryology</h4>
<div style="float: left; margin-bottom: 10px;">
  <label for="Admission">Date of Admission:</label>
  <input type="date" class="Admission" name="date_of_addmission" value="<?php echo isset($select_result['date_of_addmission'])?$select_result['date_of_addmission']:""; ?>">
 </div>
     
<div style="float: right; margin-bottom: 10px;">
  <label for="Discharge">Date of Discharge:</label>
  <input type="date" class="Discharge" name="date_of_discharge" value="<?php echo isset($select_result['date_of_discharge'])?$select_result['date_of_discharge']:""; ?>">
 </div>

<table width="100%" class="vb45rt">
<tbody>
<tr style="background: #b3b9b7;">
<td colspan="2" width="57%">
<strong>Details of Female Partner</strong>
</td>
<td width="42%">
<strong>IIC ID: <input type="text" name="iic_id" value="<?php echo $iic_id;?>"></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Name : <?php echo $patient_data['wife_name']; ?> </strong>
</td>
<td width="42%">
<strong>Husband&rsquo;s name : <?php echo $patient_data['husband_name']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Age: <?php echo $patient_data['wife_age']; ?></strong>
</td>
<td width="42%">
<strong>Age: <?php echo $patient_data['husband_age']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Blood group: <input type="text" name="female_blood_group" value="<?php echo isset($select_result['female_blood_group'])?$select_result['female_blood_group']:""; ?>"></strong>
</td>
<td width="42%">
<strong>Blood group: <input type="text" name="husband_blood_group" value="<?php echo isset($select_result['husband_blood_group'])?$select_result['husband_blood_group']:""; ?>"></strong>
</td>
</tr>

<tr>
<td colspan="2" width="57%">
<strong>List of Issues:

 <textarea name="female_issues" style="width:100%; height:150px;" > <?php echo isset($select_result['female_issues'])?$select_result['female_issues']:""; ?> </textarea>
</strong>
</td>
<td width="42%">
<strong>List of Issues: 

 <textarea name="male_issues" style="width:100%; height:150px;" > <?php echo isset($select_result['male_issues'])?$select_result['male_issues']:""; ?> </textarea>
</strong>

</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Medical complication:
<textarea name="female_complication" style="width:100%; height:150px;"  > <?php echo isset($select_result['female_complication'])?$select_result['female_complication']:""; ?> </textarea>
</strong>
</td>
<td width="42%">
<strong>Medical complication: 

<textarea name="male_complication" style="width:100%; height:150px;"  > <?php echo isset($select_result['male_complication'])?$select_result['male_complication']:""; ?> </textarea>
</strong>
</td>
</tr>
<tr>
<td width="50%">
<strong>Name of Procedure : <input type="checkbox" class="PESA" value="PESA"  name="procedures[]" <?php if(!empty($select_result['procedures']) && in_array('PESA',$procedures)){echo "checked";}?>> PESA <input type="checkbox" class="TESA" name="procedures[]" value="TESA" <?php if(!empty($select_result['procedures']) && in_array('TESA',$procedures)){echo "checked";}?>> TESA <input type="checkbox" class="TESE" name="procedures[]" value="TESE" <?php if(!empty($select_result['procedures']) && in_array('TESE',$procedures)){echo "checked";}?>> TESE <input type="checkbox" class="MICROTESE" name="procedures[]" value="MICRO TESE" <?php if(!empty($select_result['procedures']) && in_array('MICRO TESE',$procedures)){echo "checked";}?>> MICRO TESE</strong>
</td>
<td colspan="2" width="50%">
<strong>Date of procedure: <input type="date" class="procedure" name="date_of_procedure" value="<?php echo isset($select_result['date_of_procedure'])?$select_result['date_of_procedure']:""; ?>"></strong>
</td>
</tr>
</tbody>
</table> 
<div class="sec2">

  <input type="text" class="Rt" name="Rt" value="<?php echo isset($select_result['Rt'])?$select_result['Rt']:""; ?>">
<label for="Rt">sperms seen /not seen Right Testes</label><br>
 
  <input type="text" class="Lt" name="Lt" value="<?php echo isset($select_result['Lt'])?$select_result['Lt']:""; ?>">
<label for="Lt">sperms seen /not seen Left Testes </label><br>



  <input type="radio" id="Sperms" name="Sperms" value="Sperms frozen" <?php if(isset($select_result['Sperms']) && $select_result['Sperms']== "Sperms frozen"){ echo "checked";} ?>>
  <label for="age1">Sperms frozen</label><br>
  <input type="radio" id="Sperms" name="Sperms" value="Not frozen" <?php if(isset($select_result['Sperms']) && $select_result['Sperms'] == "Not frozen"){ echo "checked";} ?>>
  <label for="age2">Not frozen</label><br>  


<br>
 <p>Freezing Details:<input style="margin-bottom: 5px; " type="text" class="Freezing" name="Freezing" value="<?php echo isset($select_result['Freezing'])?$select_result['Freezing']:""; ?>"> </p>

  <label for="frozen">If frozen renewal date</label>
  
  
   <input type="date" class="frozen" name="frozen" value="<?php echo isset($select_result['frozen'])?$select_result['frozen']:""; ?>">
  
<br>

  <p>Note: sperms may not survive cryopreservation process, which means on thawing nothing, or lesser quantity will be retrieved</p>

</div>  
</div>  
  


<div class="sec21">
<label for="Senior Embryologist">Senior Embryologist</label>
  <input type="text" class="SeniorEmbryologist" name="Senior_Embryologist" value="<?php echo isset($select_result['Senior_Embryologist'])?$select_result['Senior_Embryologist']:""; ?>">
</div>
<input type="submit"  name="submit" value="submit">
</form>


<style>


input[type=checkbox], input[type=radio] {
    opacity: 1 !important;
    left: 0 !important;
    position: unset !important;
    margin: 9px !important;
}


.sec3 {
   
    border: 1px solid #000;
    padding: 5px;
}
.sec21 {
    border: 1px solid #000;
}

.sec21 p {
    margin: 20px;
    padding: 2px 10px;
}

.sec2 {
    border: 1px solid #000;
    padding-top: 5px;
}


.sec2 p {
    margin: 0px;
    padding: 2px 10px;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td {
  border: 1px solid #000;
  text-align: center;
  padding: 5px;
  
}

.ga-pro h3 {
      text-align: center;
    font-size: 25px;
}

.ga-pro h4 {
      text-align: center;
    font-size: 20px;
}

form {
    padding-left: 10px;
    margin-bottom: 4px;
}

.nb56ty {
    border: 1px solid #000;
}
.nb56ty input {
    width: 100%;
}
.vb45rt td {text-align: left; padding-left: 10px;}
</style>    