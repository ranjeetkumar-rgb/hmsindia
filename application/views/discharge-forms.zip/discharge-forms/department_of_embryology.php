<?php
    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        $sql = "SELECT * FROM `discharge_summary` WHERE iic_id=$iic_id";
        $select_result = run_select_query($sql); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `discharge_summary` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
			
        }else{
            // mysql query to update data
            $query = "UPDATE discharge_summary SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE iic_id=$iic_id";
        }
         $result = run_form_query($query);  
        
          if($result){
         header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Discharge form inserted!').'&t='.base64_encode('success'));
        	die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		  die();
        }
    }
    $sql = "SELECT * FROM `discharge_summary` WHERE iic_id=$iic_id";
$select_result = run_select_query($sql);
?>




<form action="" enctype='multipart/form-data' method="post">

 <input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
  <input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
  <input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

<div class="ga-pro">
<h3>Discharge Summary</h3>
<h4>Department of Embryology</h4>
<div style="float: left; margin-bottom: 10px;">
  <label for="Admission">Date of Admission:</label>
  <input type="date" class="Admission" name="date_of_addmission" value="<?php echo isset($select_result['date_of_addmission'])?$select_result['date_of_addmission']:""; ?>"  >
 </div>
     
<div style="float: right; margin-bottom: 10px;">
  <label for="Discharge">Date of Discharge:</label>
  <input type="date" class="Discharge" name="date_of_discharge" value="<?php echo isset($select_result['date_of_discharge'])?$select_result['date_of_discharge']:""; ?>">
 </div>

<table width="100%" class="vb45rt">
<tbody>
<tr style="background: #b3b9b7;">
<td colspan="2" width="57%">
<strong>Details of Female Partner</strong>
</td>
<td width="42%">
<strong>IIC ID: <input type="text" name="iic_id" value="<?php echo $iic_id;?>"></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Name : <?php echo $patient_data['wife_name']; ?> </strong>
</td>
<td width="42%">
<strong>Husband&rsquo;s name :  <?php echo $patient_data['husband_name']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Age:  <?php echo $patient_data['wife_age']; ?> Year</strong>
</td>
<td width="42%">
<strong>Age: <?php echo $patient_data['husband_age']; ?> Year</strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Blood group: <input type="text" name="female_blood_group" value="<?php echo isset($select_result['female_blood_group'])?$select_result['female_blood_group']:""; ?>"></strong>
</td>
<td width="42%">
<strong>Blood group: <input type="text" name="husband_blood_group" value="<?php echo isset($select_result['husband_blood_group'])?$select_result['husband_blood_group']:""; ?>"></strong>
</td>
</tr>


<tr>
<td colspan="2" width="57%">
<strong>List of Issues:

 <textarea name="female_issue" style="width:100%; height:150px;" > <?php echo isset($select_result['female_issue'])?$select_result['female_issue']:""; ?> </textarea>
</strong>
</td>
<td width="42%">
<strong>List of Issues: 

 <textarea name="male_issue" style="width:100%; height:150px;" > <?php echo isset($select_result['male_issue'])?$select_result['male_issue']:""; ?> </textarea>
</strong>

</td>
</tr>


<tr>
<td colspan="2" width="57%">
<strong>Medical complication:
<textarea name="female_medical_complication" style="width:100%; height:150px;"  > <?php echo isset($select_result['female_medical_complication'])?$select_result['female_medical_complication']:""; ?> </textarea>
</strong>
</td>
<td width="42%">
<strong>Medical complication: 

<textarea name="male_medical_complication" style="width:100%; height:150px;"  > <?php echo isset($select_result['male_medical_complication'])?$select_result['male_medical_complication']:""; ?> </textarea>
</strong>
</td>
</tr>



<tr>
<td colspan="2" width="57%" style="padding-left:0px ;">
 <label for="Senior Embryologist"><strong>Name of Procedure :</strong></label>
  <input type="text" class="Issues" name="name_of_procedure" value="<?php echo isset($select_result['name_of_procedure'])?$select_result['name_of_procedure']:""; ?>">
</td>
<td colspan="2" width="57%" style="padding-left:0px ;">

  <label for="freezing"><strong>Date of freezing: </strong></label>
  <input type="date" id="freezing" name="date_of_freezing" value="<?php echo isset($select_result['date_of_freezing'])?$select_result['date_of_freezing']:""; ?>">


</td>
</tr>
</tbody>
</table> 
<div class="sec2">
   <ul>
<li>No. of oocytes retrieved <input type="text" id="oocytes" name="no_of_oocytes_retrieved" value="<?php echo isset($select_result['no_of_oocytes_retrieved'])?$select_result['no_of_oocytes_retrieved']:""; ?>"></li>
<li>Fertilization status <input type="text" id="status" name="fertilization_status" value="<?php echo isset($select_result['fertilization_status'])?$select_result['fertilization_status']:""; ?>"></li>
<li>D2  <input type="text" id="d2" name="d2" value="<?php echo isset($select_result['d2'])?$select_result['d2']:""; ?>"></li>
<li>D3  <input type="text" id="d3" name="d3" value="<?php echo isset($select_result['d3'])?$select_result['d3']:""; ?>"></li>
<li>D4  <input type="text" id="d4" name="d4" value="<?php echo isset($select_result['d4'])?$select_result['d4']:""; ?>"></li>
<li>D5  <input type="text" id="d5" name="d5" value="<?php echo isset($select_result['d5'])?$select_result['d5']:""; ?>"></li>
<li>D6  <input type="text" id="d6" name="d6" value="<?php echo isset($select_result['d6'])?$select_result['d6']:""; ?>"></li>
<li>EMBRYO STATUS  <input type="text" id="EMBRYO" name="embryo_status" value="<?php echo isset($select_result['embryo_status'])?$select_result['embryo_status']:""; ?>"></li>

<li>Embryo number and grading on day of freezing <input type="text" id="freezing" name="day_of_freezing" value="<?php echo isset($select_result['day_of_freezing'])?$select_result['day_of_freezing']:""; ?>"></li>
<li>Renewal date of embryo freezing <input type="text" id="Renewal" name="renewal_date" value="<?php echo isset($select_result['renewal_date'])?$select_result['renewal_date']:""; ?>"></li>
</ul>

<p style="margin:10px 0px;">Note: embryo/egg freezing may not survive cryopreservation process, which means on thawing nothing, or lesser quantity will be retrieved.</p>
</div>  
</div>  


<div class="sec21">
 <label for="Senior Embryologist">Senior Embryologist</label>
  <input type="text" class="SeniorEmbryologist" name="senior_embryologist" value="<?php echo isset($select_result['senior_embryologist'])?$select_result['senior_embryologist']:""; ?>">
</div>

<input type="submit" name="submit" value="submit">

</form>

<style>

.sec3 {
   
    border: 1px solid #000;
    padding: 5px;
}
.sec21 {
    border: 1px solid #000;
}

.sec21 p {
    margin: 20px;
    padding: 2px 10px;
}

.sec2 {
    border: 1px solid #000;
}

.sec2 p {
    margin: 0px;
    padding: 2px 10px;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td {
  border: 1px solid #000;
  text-align: center;
  padding: 5px;
  
}

.ga-pro h3 {
      text-align: center;
    font-size: 25px;
}

.ga-pro h4 {
      text-align: center;
    font-size: 20px;
}

form {
    padding-left: 10px;
    margin-bottom: 4px;
}

.nb56ty {
    border: 1px solid #000;
}
.nb56ty input {
    width: 100%;
}
.vb45rt td {text-align: left; padding-left: 10px;}
.sec2 ul li {    margin-bottom: 5px;}
</style>    