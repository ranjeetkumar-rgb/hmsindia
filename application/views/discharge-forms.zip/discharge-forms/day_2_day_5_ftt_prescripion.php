<?php


    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        $sql = "SELECT * FROM `day2_day5_fet_prescription` WHERE iic_id=$iic_id";
        $select_result = run_select_query($sql); 
		
		if(!empty($_POST['applicablemedicine']) && isset($_POST['applicablemedicine'])){
             $_POST['applicablemedicine'] = implode(',', $_POST['applicablemedicine']);
        }
		
		
		
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `day2_day5_fet_prescription` SET ";
            $sqlArr = array();
           
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE day2_day5_fet_prescription SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE iic_id=$iic_id";
        }
         $result = run_form_query($query);  
        
    if($result){
         header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Discharge form inserted!').'&t='.base64_encode('success'));
        	die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		  die();
        }
    }
    $sql = "SELECT * FROM `day2_day5_fet_prescription` WHERE iic_id=$iic_id";
$select_result = run_select_query($sql);
?>


<?php 
$applicablemedicine = array();

  if(!empty($select_result['applicablemedicine'])){
        $applicablemedicine = explode(',',$select_result['applicablemedicine']);
             
    }

	
 ?>



<h3 style="color: #4141ab; text-align:center;">DAY2-DAY 5 FET PRESCRIPTION </h3>
<div class="ga-pro">
<h3>Please strike out whichever is not applicable</h3>

<form action="" enctype='multipart/form-data' method="post">
    
      <input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
  <input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
  <input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

.<table width="100%">
<tbody>
<tr style="background: #b3b9b7;">
<td colspan="2" width="57%">
<strong>Details of Female Partner</strong>
</td>
<td width="42%">
<strong>IIC ID: <input type="text" name="iic_id" value="<?php echo $iic_id;?>"></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Name : <?php echo $patient_data['wife_name']; ?> </strong>
</td>
<td width="42%">
<strong>Husband&rsquo;s name : <?php echo $patient_data['husband_name']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Age: <?php echo $patient_data['wife_age']; ?></strong>
</td>
<td width="42%">
<strong>Age: <?php echo $patient_data['husband_age']; ?></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Blood group: <input type="text" name="female_blood_group" value="<?php echo isset($select_result['female_blood_group'])?$select_result['female_blood_group']:""; ?>" ></strong>
</td>
<td width="42%">
<strong>Blood group: <input type="text" name="husband_blood_group" value="<?php echo isset($select_result['husband_blood_group'])?$select_result['husband_blood_group']:""; ?>" ></strong>
</td>
</tr>


<tr>
<td width="50%">
<strong>Name of Procedure : DAY2-DAY 5 FET PRESCRIPTION</strong>
</td>
<td colspan="2" width="50%">
<strong>Date of procedure:   <input type="date" class="date_of_procedure" name="date_of_procedure" value="<?php echo isset($select_result['date_of_procedure'])?$select_result['date_of_procedure']:""; ?>">   </strong>
</td>
</tr>




</tbody>
</table>

<div class="gf45rt">
<table>
<tbody>
<tr>
<td>
Check
applicable
</td>
<td width="98">
Medication
</td>
<td width="97">
Dosage
</td>
<td>
Route
</td>
<td>
Times
</td>
<td>
Timings
</td>
<td>
When to
start
</td>
<td>
How
many
days
</td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Syp cremaffin"  <?php if(!empty($select_result['applicablemedicine']) && in_array('Syp cremaffin',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Syp
cremaffin
</td>
<td width="97">
1 TSF
</td>
<td>
Oral
</td>
<td>
One tsf
</td>
<td>
After dinner
</td>
<td>
SOS(if
constipation
</td>
<td></td>
</tr>
<tr>
<td>
 <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Estrabet (2mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Estrabet (2mg)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Tab Estrabet
(2mg)
</td>
<td width="97">
1 TAB
</td>
<td>
Oral
</td>
<td>
Twice /thrice/four times daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Ecosprin (75 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Ecosprin (75 mg)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Tab Ecosprin
(75 mg)
</td>
<td width="97">
1 TAB
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Wysolone" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Wysolone',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Tab Wysolone
</td>
<td width="97">
5mg/10mg/15mg
</td>
<td>
oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil L" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil L',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Biophil L
</td>
<td width="97">
1 CAP
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil O 3" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil O 3',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Biophil O 3
</td>
<td width="97">
1 CAP
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Biophil Q" <?php if(!empty($select_result['applicablemedicine']) && in_array('Biophil Q',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Biophil Q
</td>
<td width="97">
1 CAP
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="BIOLARG SACHET" <?php if(!empty($select_result['applicablemedicine']) && in_array('BIOLARG SACHET',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
BIOLARG SACHET
</td>
<td width="97">
1 SACHET
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Caverta (50 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Caverta (50 mg)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Tab Caverta (50 mg)
</td>
<td width="97">
1 TAB
</td>
<td>
vaginally
</td>
<td>
Once daily
</td>
<td>
At night
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap Vit D3 (60000 IU)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Cap Vit D3 (60000 IU)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Cap Vit D3 (60000 IU)
</td>
<td width="97">
1 CAP
</td>
<td>
oral
</td>
<td>
weekly
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Allegra" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Allegra',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Tab Allegra
</td>
<td width="97">
1 TAB
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Montair LC" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Montair LC',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Tab Montair LC
</td>
<td width="97">
1 TAB
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Tab Shelcal (500 mg)" <?php if(!empty($select_result['applicablemedicine']) && in_array('Tab Shelcal (500 mg)',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="98">
Tab Shelcal
(500 mg)
</td>
<td width="97">
1 TAB
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="BIOPHIL -VITA" <?php if(!empty($select_result['applicablemedicine']) && in_array('BIOPHIL -VITA',$applicablemedicine)){echo "checked";}?>>
</td>
<td width="83">
BIOPHIL -VITA
</td>
<td width="112">
1 TAB
</td>
<td width="68">
Oral
</td>
<td width="71">
Once daily
</td>
<td width="66">
After meals
</td>
<td width="88">
immediately
</td>
<td width="64">
Fourteen days
</td>
</tr>
<tr>
<td>
  <input type="checkbox" class="checkmedicine" name="applicablemedicine[]" value="Cap Fericip XT" <?php if(!empty($select_result['applicablemedicine']) && in_array('Cap Fericip XT',$applicablemedicine)){echo "checked";}?>>

</td>
<td width="98">
Cap Fericip XT
</td>
<td width="97">
1 CAP
</td>
<td>
Oral
</td>
<td>
Once daily
</td>
<td>
After meals
</td>
<td>
immediately
</td>
<td>
fourteen days
</td>
</tr>
</tbody>
</table>
<div class="nb56ty">
<label for="other">Other Medication1:</label>
  <input type="text" class="other1" name="Other_Medication1" value="<?php echo isset($select_result['Other_Medication1'])?$select_result['Other_Medication1']:""; ?>">
</div>  
<div class="nb56ty">
 <label for="other">Other Medication2:</label>
  <input type="text" class="other2" name="Other_Medication2" value="<?php echo isset($select_result['Other_Medication2'])?$select_result['Other_Medication2']:""; ?>">
</div>  
</div>

    <input type="submit" name="submit" value="submit">
    
    </form>
</div>   


<style>

input[type=checkbox], input[type=radio] {
    opacity: 1 !important;
    left: 0 !important;
    position: unset !important;
    margin: 9px !important;
}







table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td {
  border: 1px solid #000;
  text-align: center;
  padding: 5px;
 
}

.ga-pro h3 {
      text-align: center;
    font-size: 25px;
}
.gf45rt td {
    width: 0;
}
.nb56ty {
    border: 1px solid #000;
}
.nb56ty input {
    width: 100%;
}
</style>    