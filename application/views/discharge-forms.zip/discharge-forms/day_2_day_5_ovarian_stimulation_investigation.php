<?php


    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        $sql = "SELECT * FROM `day_2_day_5_ovarian_stimulation_investigation` WHERE iic_id=$iic_id";
        $select_result = run_select_query($sql); 
        
  
        
        
         if(!empty($_POST['ovarian_stimulation']) && isset($_POST['ovarian_stimulation'])){
            $_POST['ovarian_stimulation'] = implode(',', $_POST['ovarian_stimulation']);
        }
        
        
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `day_2_day_5_ovarian_stimulation_investigation` SET ";
            $sqlArr = array();
            
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE day_2_day_5_ovarian_stimulation_investigation SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE iic_id=$iic_id";
        }
             $result = run_form_query($query); 
        
    if($result){
         header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Discharge form inserted!').'&t='.base64_encode('success'));
        	die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		  die();
        }
    }
    $sql = "SELECT * FROM `day_2_day_5_ovarian_stimulation_investigation` WHERE iic_id=$iic_id";
$select_result = run_select_query($sql);
?>



<?php $ovarian =  array();
    if(!empty($select_result['ovarian_stimulation'])){
        $ovarian = explode(',',$select_result['ovarian_stimulation']);
        
            }
    
  ?>



<div class="ga-pro">
<h3>INDIA IVF CLINIC</h3>
<form action="" enctype='multipart/form-data' method="post">

<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
  <input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
  <input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">





    <div style="float: left; margin-bottom: 10px;">
	
	
	
  <label for="Center">Center</label>
  <input type="text" class="Center" name="center" value="<?php echo isset($select_result['center'])?$select_result['center']:""; ?>">
    </div>

     
<div style="float: right; margin-bottom: 10px;">
  <label for="Discharge">Date:</label>
  <input type="date" class="Discharge" value="<?php echo isset($select_result['date'])?$select_result['date']:""; ?>"  name="date">
 </div>

<table width="100%" class="vb45rt">
<tbody>
<tr style="background: #b3b9b7;">
<td colspan="2" width="57%">
<strong>Details of Female Partner</strong>
</td>
<td width="42%">
<strong>IIC ID: <input type="text" name="iic_id" value="<?php echo $iic_id;?>"></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Name : <?php echo $patient_data['wife_name']; ?> </strong>
</td>
<td width="42%">
<strong>Husband&rsquo;s name : <?php echo $patient_data['husband_name']; ?> </strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Age: <?php echo $patient_data['wife_age']; ?></strong>
</td>
<td width="42%">
<strong>Age: <?php echo $patient_data['husband_age']; ?></strong>
</td>
</tr>
<tr>
<td colspan="2" width="57%">
<strong>Blood group: <input type="text" name="female_blood_group" value="<?php echo isset($select_result['female_blood_group'])?$select_result['female_blood_group']:""; ?>"></strong>
</td>
<td width="42%">
<strong>Blood group: <input type="text" name="husband_blood_group" value="<?php echo isset($select_result['husband_blood_group'])?$select_result['husband_blood_group']:""; ?>"></strong>
</td>
</tr>

</tbody>
</table>  
 <h3>DAY 2 - DAY 5 OVARIAN STIMULATION INVESTIGATION</h3> 
<div class="sec2">
  <input type="checkbox" id="E2" name="ovarian_stimulation[]" value="Serum Estradiol [5pE2]" <?php if(!empty($select_result['ovarian_stimulation']) && isset($select_result['ovarian_stimulation']) && in_array('Serum Estradiol [5pE2]', $ovarian)){echo "checked";}?>>
  <label for="E2">Serum Estradiol (E2)</label><br>
  <input type="checkbox" id="FSH" name="ovarian_stimulation[]" value="Serum Follicle Stimulating Hormone FSH" <?php if(!empty($select_result['ovarian_stimulation']) && isset($select_result['ovarian_stimulation']) && in_array('Serum Follicle Stimulating Hormone FSH', $ovarian)){echo "checked";}?>>
  <label for="FSH">Serum Follicle Stimulating Hormone (FSH)</label><br>
<input type="checkbox" id="LH" name="ovarian_stimulation[]" value="Serum luteinizing Hormone LH"  <?php if(!empty($select_result['ovarian_stimulation']) && isset($select_result['ovarian_stimulation']) && in_array('Serum luteinizing Hormone LH', $ovarian)){echo "checked";}?>>
<label for="LH">Serum luteinizing Hormone (LH)</label><br>



  <label for="Estrabet">Others</label> <input type="text" class="Other" name="others" value="<?php echo isset($select_result['others'])?$select_result['others']:""; ?>"><br>



</div>  
    
    <input type="submit" name="submit" value="submit">
    
    </form>
</div>  
   

<style>

input[type=checkbox], input[type=radio] {
    opacity: 1 !important;
    left: 0 !important;
    position: unset !important;
    margin: 9px !important;
}

.sec3 {
   
    border: 1px solid #000;
    padding: 5px;
}
.sec21 {
    border: 1px solid #000;
}

.sec21 p {
    margin: 20px;
    padding: 2px 10px;
}

.sec2 {
    border: 1px solid #000;
}

.sec2 p {
    margin: 0px;
    padding: 2px 10px;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td {
  border: 1px solid #000;
  text-align: center;
  padding: 5px;
  
}

.ga-pro h3 {
      text-align: center;
    font-size: 25px;
}

.ga-pro h4 {
      text-align: center;
    font-size: 20px;
}

form {
    padding-left: 10px;
    margin-bottom: 4px;
}

.nb56ty {
    border: 1px solid #000;
}
.nb56ty input {
    width: 100%;
}
.vb45rt td {text-align: left; padding-left: 10px;}
.sec2 ul li {    margin-bottom: 5px;}
</style>    