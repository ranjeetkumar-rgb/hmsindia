<?php
    if(isset($_POST['submit'])){
		unset($_POST['submit']);
		
        $select_query = "SELECT * FROM `ovarian_cyst_aspiration` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `ovarian_cyst_aspiration` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE ovarian_cyst_aspiration SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `ovarian_cyst_aspiration` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
	$select_result = run_select_query($select_query);  
	
// php code to Insert data into mysql database from input text
// if(isset($_POST['submit'])){
// 	$patient_id = $_POST['patient_id'];
// 	$receipt_number = $_POST['receipt_number'];
// 	$status = $_POST['status'];
// 	// get values form input text and number
// 	$date = $_POST['date'];
// 	$time = $_POST['time'];
// 	$ht = $_POST['ht'];
// 	$wt = $_POST['wt'];
// 	$consent = $_POST['consent'];
// 	$id_ = $_POST['id_'];
// 	$bp = $_POST['bp'];
// 	$pulse = $_POST['pulse'];
// 	$resp = $_POST['resp'];
// 	$voided = $_POST['voided'];
// 	$allergies = $_POST['allergies'];
// 	$contacts = $_POST['contacts'];
// 	$denture = $_POST['denture'];
// 	$dental_bridge = $_POST['dental_bridge'];
// 	$escort = $_POST['escort'];
// 	$last_meal = $_POST['last_meal'];
// 	$indication = $_POST['indication'];
// 	$resp2 = $_POST['resp2'];
// 	$cvs = $_POST['cvs'];
// 	$cns = $_POST['cns'];
// 	$abdominal = $_POST['abdominal'];
// 	$others = $_POST['others'];
// 	$anesthetist = $_POST['anesthetist'];
// 	$doctor = $_POST['doctor'];
// 	$nurse = $_POST['nurse'];
// 	$glasses = $_POST['glasses'];
// 	$prescriptions_other = $_POST['prescriptions_other'];
// 	$npo_x_2hrs = $_POST['npo_x_2hrs'];
// 	$sips_of_fluid = $_POST['sips_of_fluid'];
// 	$fluid = $_POST['fluid'];
// 	$paracetamol = $_POST['paracetamol'];
// 	$justin_suppository = $_POST['justin_suppository'];
// 	$monitor_pulse = $_POST['monitor_pulse'];
// 	$monitor_bleeding = $_POST['monitor_bleeding'];
// 	$remove_vaginal_pack = $_POST['remove_vaginal_pack'];
// 	$normal_diet = $_POST['normal_diet'];
// 	$tab_ceftum = $_POST['tab_ceftum'];
// 	$cap_pantoprazole = $_POST['cap_pantoprazole'];
// 	$tab_crocin = $_POST['tab_crocin'];
// 	$report = $_POST['report'];

// 	// connect to mysql database using mysqli


// 	// mysql query to insert data
// 	$query = "INSERT INTO `ovarian_cyst_aspiration`(`patient_id`, `receipt_number`, `status`,`date`,`time`,`ht`,`wt`,`consent`,`id_`,`bp`,`pulse`,`resp`,`voided`,`allergies`,`contacts`,`denture`,`dental_bridge`,`escort`,`last_meal`,`indication`,`resp2`,`cvs`,`cns`,`abdominal`,`others`,`anesthetist`,`doctor`,`nurse`,`glasses`,`prescriptions_other`,`npo_x_2hrs`,`sips_of_fluid`,`fluid`,`paracetamol`,`justin_suppository`,`monitor_pulse`,`monitor_bleeding`,`remove_vaginal_pack`,`normal_diet`,`tab_ceftum`,`cap_pantoprazole`,`tab_crocin`,`report`) VALUES ('$patient_id','$receipt_number','$status','$date','$time','$ht','$wt','$consent','$id_','$bp','$pulse','$resp','$voided','$allergies','$contacts','$denture','$dental_bridge','$escort','$last_meal','$indication','$resp2','$cvs','$cns','$abdominal','$others','$anesthetist','$doctor','$nurse','$glasses','$prescriptions_other','$npo_x_2hrs','$sips_of_fluid','$fluid','$paracetamol','$justin_suppository','$monitor_pulse','$monitor_bleeding','$remove_vaginal_pack','$normal_diet','$tab_ceftum','$cap_pantoprazole','$tab_crocin','$report')";

// 	$result = run_form_query($query);

// 	if($result){
// 	header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
// 	die();
// 	}else{
// 	header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
// 	die();
// 	}
// }
?>
<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
		<input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
		<input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
		<input type="hidden" value="pending" name="status"> 
		<table class="table-bordered" width="100%">
			<tr>
				<td colspan="2">
    			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
    			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
    			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
    			            ){?>
    			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
    			    <?php } ?>
    			</td>
			</tr>
		</table>
		<table class="table-bordered" width="100%">
			<tr>
				<td>1.Stop Tablet Ecosprin/Aspirin/Baby aspirin 48 hrs prior to procedure</td>
			</tr>
			<tr>
				<td>2.Continue thyroid/antihypertensive/other medical disorder medication with sips of water in the morning of procedure.</td>
			</tr>
			<tr>
				<td>3.If you are taking oral medications for diabetes please see anesthetist three days before procedure for instructions /medications /insulin.</td>
			</tr>
			<tr>
				<td>4.Pre anesthetic check up will be done</td>
			</tr>
			<tr>
				<td>5.You should arrange for a responsible adult to accompany you home from the day stay unit following procedure and to remain with you overnight. You should not be left alone in home for 24 hrs. following the procedures We can not perform procedure if you fail to arrange an escort. You will need to rest at home all day following the procedures, but you should feel well enough to resume normal activities the day after.</td>
			</tr>
			<tr>
				<td>6.Please leave valuables and jewelry at home. Please remove nail paint and make up prior to the procedure. It is important that you do not wear any strong perfumes before the procedure.</td>
			</tr>
			<tr>
				<td>7.Please remove vaginal hair (by normal waxing/shaving/trimming ) at home before you come for procedure</td>
			</tr>
			<tr>
				<td>8.You will be kept in for approximately 2 hours after your operation to allow a full recovery. Your escort should be available to take you home.</td>
			</tr>
			<tr>
				<td>9.Please remember to inform us of any medication (other than ivf drugs) that you take regularly- i.e. inhalers, blood pressure tablets. You should bring all medication with you to the fertility unit on the day of procedure.</td>
			</tr>
			<tr>
				<td>10. Do not take alcohol for 24 hours prior to your procedure. Please refrain from smoking for as long as possible before the procedure.</td>
			</tr>
			<tr>
				<td>11.We look forward to seeing you and will do everything to ensure a safe and comfortable stay.</td>
			</tr>
			<tr>
				<td><br></td>
			</tr>
		</table>
		<table class="table-bordered" width="100%">
			<tr style="color: red;">
				<td>OVARIAN CYST ASPIRATION</td>
				<td>Date<br><input  type="date" value="<?php echo isset($select_result['date'])?$select_result['date']:""; ?>"     name="date" class="form-control" ></td>
				<td>Time<br><input  type="time" value="<?php echo isset($select_result['time'])?$select_result['time']:""; ?>"     name="time" class="form-control" ></td>
				<td>Indication<br><input  type="text" value="<?php echo isset($select_result['indication'])?$select_result['indication']:""; ?>"     maxlength="50" name="indication" class="form-control" ></td>
				<td>Allergies<br><input  type="text" value="<?php echo isset($select_result['allergies'])?$select_result['allergies']:""; ?>"     maxlength="50" name="allergies" class="form-control" ></td>
				<td>
					Consent<br>
					<label><input type="radio"  name="consent"  value="Yes"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="consent"   value="No"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['consent']) && $select_result['consent'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>
					ID <br>
					<label><input type="radio"  name="id_checked"  value="Yes"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="id_checked"   value="No"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['id_checked']) && $select_result['id_checked'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
			</tr>
			<tr style="color: red;">
				<td>PRE ASSESSMENT</td>
				<td>BP<br><input  type="text" value="<?php echo isset($select_result['bp'])?$select_result['bp']:""; ?>"     maxlength="20" name="bp" class="form-control" ></td>
				<td>
					Pulse<br>
					<label><input type="radio"  name="pulse"  value="Yes"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="pulse"   value="No"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['pulse']) && $select_result['pulse'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>
					Resp<br>
					<label><input type="radio"  name="resp"  value="Yes"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="resp"   value="No"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp']) && $select_result['resp'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>
					Voided<br>
					<label><input type="radio"  name="voided"  value="Yes"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="voided"   value="No"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['voided']) && $select_result['voided'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Ht (Cms)<br><input  type="number" value="<?php echo isset($select_result['ht'])?$select_result['ht']:""; ?>"     min="0" name="ht" class="form-control"></td>
				<td>Wt (Kg)<br><input  type="number" value="<?php echo isset($select_result['wt'])?$select_result['wt']:""; ?>"     min="0" name="wt" class="form-control"></td>
			</tr>
			<tr>
				<td>
					Glasses<br>
					<label><input type="radio"  name="glasses"  value="Yes"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="glasses"   value="No"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['glasses']) && $select_result['glasses'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>
					Contacts<br>
					<label><input type="radio"  name="contacts"  value="Yes"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="contacts"   value="No"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['contacts']) && $select_result['contacts'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>
					Denture<br>
					<label><input type="radio"  name="denture"  value="Yes"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="denture"   value="No"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['denture']) && $select_result['denture'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td colspan="2">
					Dental bridge<br>
					<label><input type="radio"  name="dental_bridge"  value="Yes"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="dental_bridge"   value="No"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>
					Valuables with escort<br>
					<label><input type="radio"  name="escort"  value="Yes"  <?php if(isset($select_result['escort']) && $select_result['escort'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="escort"   value="No"  <?php if(isset($select_result['escort']) && $select_result['escort'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['escort']) && $select_result['escort'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Last meal<br><input  type="time" value="<?php echo isset($select_result['last_meal'])?$select_result['last_meal']:""; ?>"     name="last_meal" class="form-control" ></td>
			</tr>
		</table>
		<table style="color: red;" class="table-bordered" width="100%">
			<tr>
				<td><b>Prescriptions given</b></td>
			</tr>
			<tr>
				<td>
					Injection Monocef 1 gm iv AST<br>
					Injection Pantoprazole 40 mg i.m. stat<br>
					Injection emset 1 gm iv stat<br>
					Other <input  type="text" value="<?php echo isset($select_result['prescriptions_other'])?$select_result['prescriptions_other']:""; ?>"     name="prescriptions_other" class="form-control">
				</td>
			</tr>
		</table>
		<table style="color: red;" class="table-bordered" width="100%">
			<tr>
				<td>Nurse</td>
				<td><input  type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>"     name="nurse" class="form-control"></td>
				<td>Doctor</td>
				<td><input  type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>"     name="doctor" class="form-control"></td>
				<td>Anesthetist</td>
				<td><input  type="text" value="<?php echo isset($select_result['anesthetist'])?$select_result['anesthetist']:""; ?>"     name="anesthetist" class="form-control"></td>
			</tr>
		</table>
		<table style="color: red;" class="table-bordered" width="100%">
			<tr>
				<td width="25%" style="padding: 0;">
					<table width="100%">
						<tr>
							<td colspan="2"><b>PRE ASSESSMENT</b></td>
						</tr>
						<tr>
							<td>
								No active  infection<br>
								No aspirin or NSAID a week before
							</td>
						</tr>
						<tr>
							<td colspan="2">Physical Examination</td>
						</tr>
						<tr>
							<td>
								<input  type="text" value="<?php echo isset($select_result['resp2'])?$select_result['resp2']:""; ?>"     name="resp2">
							</td>
							<td>Resp</td>
						</tr>
						<tr>
							<td>
								<input  type="text" value="<?php echo isset($select_result['cvs'])?$select_result['cvs']:""; ?>"     name="cvs">
							</td>
							<td>CVS</td>
						</tr>
						<tr>
							<td>
								<input  type="text" value="<?php echo isset($select_result['cns'])?$select_result['cns']:""; ?>"     name="cns">
							</td>
							<td>CNS</td>
						</tr>
						<tr>
							<td>
								<input  type="text" value="<?php echo isset($select_result['abdominal'])?$select_result['abdominal']:""; ?>"     name="abdominal">
							</td>
							<td>Abdominal</td>
						</tr>
						<tr>
							<td>
								<input  type="text" value="<?php echo isset($select_result['others'])?$select_result['others']:""; ?>"     name="others">
							</td>
							<td>Others</td>
						</tr>
					</table>
				</td>
				<td>
					<p>Written informed consent taken . All vitals  under normal range. Patient put in lithotomy position . The anesthetist examined the patient and given general anesthesia .Under all sterile conditions, the vulva and vagina were cleansed by betadine and draped. A condom with lubricated jelly is put on the vaginal ultrasound probe,it is introduced transvaginally  ,a baseline transvaginal ultrasound performed to see endometrium and ovaries.By single lumen needle under transvaginal ultrasound guidance with single/multiple punctures ovarian cyst drained under  anesthesia.</p>
					<p>No complications seen. Transvaginal probe taken out .Hemostasis achieved.</p>
					<p>Patient stood the procedure well.</p>
				</td>
			</tr>
		</table>
		<table style="color: red;" class="table-bordered" width="100%">
			<tr>
				<td colspan="2"><b>Intra Operative Orders</b></td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="npo_x_2hrs"  value="Yes"  <?php if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="npo_x_2hrs"   value="No"  <?php if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>NPO X 2HRS</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="sips_of_fluid"  value="Yes"  <?php if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="sips_of_fluid"   value="No"  <?php if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Sips of fluid after 2 hrs fld by soft diet</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="fluid"  value="Yes"  <?php if(isset($select_result['fluid']) && $select_result['fluid'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="fluid"   value="No"  <?php if(isset($select_result['fluid']) && $select_result['fluid'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['fluid']) && $select_result['fluid'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>i.v. fluid R.L or NS 500 ml@ 125 ml/hr</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="paracetamol"  value="Yes"  <?php if(isset($select_result['paracetamol']) && $select_result['paracetamol'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="paracetamol"   value="No"  <?php if(isset($select_result['paracetamol']) && $select_result['paracetamol'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['paracetamol']) && $select_result['paracetamol'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>i.v. paracetamol 100 ml (SOS)@8-10 drops/min</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="justin_suppository"  value="Yes"  <?php if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="justin_suppository"   value="No"  <?php if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Justin suppository per rectally</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="monitor_pulse"  value="Yes"  <?php if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="monitor_pulse"   value="No"  <?php if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Monitor pulse/BP/Spo2 continuously</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="monitor_bleeding"  value="Yes"  <?php if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="monitor_bleeding"   value="No"  <?php if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Monitor bleeding p/v every half hour</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="remove_vaginal_pack"  value="Yes"  <?php if(isset($select_result['remove_vaginal_pack']) && $select_result['remove_vaginal_pack'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="remove_vaginal_pack"   value="No"  <?php if(isset($select_result['remove_vaginal_pack']) && $select_result['remove_vaginal_pack'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['remove_vaginal_pack']) && $select_result['remove_vaginal_pack'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Remove vaginal pack if any</td>
			</tr>
		</table>
		<table style="color: red;" class="table-bordered" width="100%">
			<tr>
				<td colspan="2"><b>Post operative orders</b></td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="normal_diet"  value="Yes"  <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="normal_diet"   value="No"  <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['normal_diet']) && $select_result['normal_diet'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Normal diet</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="tab_ceftum"  value="Yes"  <?php if(isset($select_result['tab_ceftum']) && $select_result['tab_ceftum'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="tab_ceftum"   value="No"  <?php if(isset($select_result['tab_ceftum']) && $select_result['tab_ceftum'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_ceftum']) && $select_result['tab_ceftum'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Tab. Ceftum 500 mg twice daily one morning one evening after meals for 5 days</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="cap_pantoprazole"  value="Yes"  <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="cap_pantoprazole"   value="No"  <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Cap Pantoprazole 40 mg once daily in empty stomach for 5 days</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="tab_crocin"  value="Yes"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="tab_crocin"   value="No"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>Tab Crocin 500 mg thrice daily eight hourly after meals for 2 days</td>
			</tr>
			<tr>
				<td>
					<label><input type="radio"  name="report"  value="Yes"  <?php if(isset($select_result['report']) && $select_result['report'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
					<label><input type="radio"  name="report"   value="No"  <?php if(isset($select_result['report']) && $select_result['report'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['report']) && $select_result['report'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
				</td>
				<td>To report if giddiness /nausea/vomiting/bleeding/pain/fever /purulent discharge immediately</td>
			</tr>
		</table>
		<!-- /.card-body -->
		<div class="card-footer">
			<!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
			<input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
		</div>
	</form>