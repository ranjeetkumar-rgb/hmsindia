<?php
    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        $select_query = "SELECT * FROM `laparoscopy_hysteroscopy` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `laparoscopy_hysteroscopy` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }   
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE laparoscopy_hysteroscopy SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"  ;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `laparoscopy_hysteroscopy` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
    $select_result = run_select_query($select_query);  
  
?>

<!--<?php
  // php code to Insert data into mysql database from input text
  // if(isset($_POST['submit'])){
  //   $patient_id = $_POST['patient_id'];
  //   $receipt_number = $_POST['receipt_number'];
  //   $status = $_POST['status'];
    
  //   // get values form input text and number
		// $date = $_POST['date'];
		// $time = $_POST['time'];
		// $indication = $_POST['indication'];
		// $allergy = $_POST['allergy'];
		// $consent = $_POST['consent'];
		// $id_checked = $_POST['id_checked'];
		// $bp = $_POST['bp'];
		// $pulse = $_POST['pulse'];
		// $resp = $_POST['resp'];
		// $voided = $_POST['voided'];
		// $ht = $_POST['ht'];
		// $wt = $_POST['wt'];
		// $contacts = $_POST['contacts'];
		// $denture = $_POST['denture'];
		// $dental_bridge = $_POST['dental_bridge'];
		// $valuables_with_escort = $_POST['valuables_with_escort'];
		// $last_meal = $_POST['last_meal'];
		// $resp2 = $_POST['resp2'];
		// $CVS = $_POST['CVS'];
		// $CNS = $_POST['CNS'];
		// $abdominal = $_POST['abdominal'];
		// $others = $_POST['others'];
		// $uterus = $_POST['uterus'];
  //   $tubes = $_POST['tubes'];
  //   $ovaries = $_POST['ovaries'];
  //   $pod = $_POST['pod'];
  //   $liver = $_POST['liver'];
  //   $Chromopertubation = $_POST['Chromopertubation'];
  //   $any_other_findings = $_POST['any_other_findings'];
		// $operative_uterus = $_POST['operative_uterus'];
  //   $operative_tubes = $_POST['operative_tubes'];
  //   $operative_ovaries = $_POST['operative_ovaries'];
  //   $operative_pod = $_POST['operative_pod'];
  //   $operative_liver = $_POST['operative_liver'];
  //   $operative_Chromopertubation = $_POST['operative_Chromopertubation'];
  //   $operative_any_other_findings = $_POST['operative_any_other_findings'];
		// $cervix = $_POST['cervix'];
		// $vagina = $_POST['vagina'];
		// $uterine_cavity = $_POST['uterine_cavity'];
		// $ostia = $_POST['ostia'];
		// $tb = $_POST['tb'];
		// $hpe = $_POST['hpe'];
		// $operative_any_other_finding = $_POST['operative_any_other_finding'];
		// $uterine_cavity2 = $_POST['uterine_cavity2'];
		// $ostia2 = $_POST['ostia2'];
		// $tb2 = $_POST['tb2'];
		// $hpe2 = $_POST['hpe2'];
		// $operative_any_other_finding2 = $_POST['operative_any_other_finding2'];
  //   $anesthetist = $_POST['anesthetist'];
  //   $doctor = $_POST['doctor'];
  //   $nurse = $_POST['nurse'];
  //   $prescription_given = $_POST['prescription_given'];
  //   $doctor_signature = $_POST['doctor_signature'];
  //   $comments = $_POST['comments'];
  //   $endometrial_cavity = $_POST['endometrial_cavity'];
  //   $bilateral_ostia = $_POST['bilateral_ostia'];
  //   $comments1 = $_POST['comments1'];
  //   $bilateral_ovaries = $_POST['bilateral_ovaries'];
  //   $bilateral_tubes = $_POST['bilateral_tubes'];
  //   $uterus_visualized = $_POST['uterus_visualized'];
  //   $glasses = $_POST['glasses'];
  //   $hpe1 = $_POST['hpe1'];
  //   $pv = $_POST['pv'];
  //   $uterocervical_length = $_POST['uterocervical_length'];
  //   $ectocervical_canal = $_POST['ectocervical_canal'];
  //   $intra_operative = $_POST['intra_operative'];
  //   $npo_x_2hrs = $_POST['npo_x_2hrs'];
  //   $sips_of_fluid = $_POST['sips_of_fluid'];
  //   $fluid_rl = $_POST['fluid_rl'];
  //   $paracetamol = $_POST['paracetamol'];
  //   $justin_suppository = $_POST['justin_suppository'];
  //   $monitor_pulse = $_POST['monitor_pulse'];
  //   $monitor_bleeding = $_POST['monitor_bleeding'];
  //   $remove_vaginal = $_POST['remove_vaginal'];
  //   $normal_diet = $_POST['normal_diet'];
  //   $tab_ceftum = $_POST['tab_ceftum'];
  //   $cap_pantoprazole = $_POST['cap_pantoprazole'];
  //   $tab_crocin = $_POST['tab_crocin'];
  //   $report = $_POST['report'];

	 //    // connect to mysql database using mysqli
	    

	 //    // mysql query to insert data
	 //    $query = "INSERT INTO `laparoscopy_hysteroscopy`(`patient_id`, `receipt_number`, `status`,`date`,`time`,`indication`,`allergy`,`consent`,`id_checked`,`bp`,`pulse`,`resp`,`voided`,`ht`,`wt`,`contacts`,`denture`,`dental_bridge`,`valuables_with_escort`,`last_meal`,`resp2`,`CVS`,`CNS`,`abdominal`,`others`,`uterus`,`tubes`,`ovaries`,`pod`,`liver`,`Chromopertubation`,`any_other_findings`,`operative_uterus`,`operative_tubes`,`operative_ovaries`,`operative_pod`,`operative_liver`,`operative_Chromopertubation`,`operative_any_other_findings`,`cervix`,`vagina`,`uterine_cavity`,`ostia`,`tb`,`hpe`,`operative_any_other_finding`,`uterine_cavity2`,`ostia2`,`tb2`,`hpe2`,`operative_any_other_finding2`,`anesthetist`,`doctor`,`nurse`,`prescription_given`,`doctor_signature`,`comments`,`endometrial_cavity`,`bilateral_ostia`,`comments1`,`bilateral_ovaries`,`bilateral_tubes`,`uterus_visualized`,`glasses`,`hpe1`,`pv`,`uterocervical_length`,`ectocervical_canal`,`intra_operative`,`npo_x_2hrs`,`sips_of_fluid`,`fluid_rl`,`paracetamol`,`justin_suppository`,`monitor_pulse`,`monitor_bleeding`,`remove_vaginal`,`normal_diet`,`tab_ceftum`,`cap_pantoprazole`,`tab_crocin`,`report`) VALUES ('$patient_id','$receipt_number','$status','$date','$time','$indication','$allergy','$consent','$id_checked','$bp','$pulse','$resp','$voided','$ht','$wt','$contacts','$denture','$dental_bridge','$valuables_with_escort','$last_meal','$resp2','$CVS','$CNS','$abdominal','$others','$uterus','$tubes','$ovaries','$pod','$liver','$Chromopertubation','$any_other_findings','$operative_uterus','$operative_tubes','$operative_ovaries','$operative_pod','$operative_liver','$operative_Chromopertubation','$operative_any_other_findings','$cervix','$vagina','$uterine_cavity','$ostia','$tb','$hpe','$operative_any_other_finding','$uterine_cavity2','$ostia2','$tb2','$hpe2','$operative_any_other_finding2','$anesthetist','$doctor','$nurse','$prescription_given','$doctor_signature','$comments','$endometrial_cavity','$bilateral_ostia','$comments1','$bilateral_ovaries','$bilateral_tubes','$uterus_visualized','$glasses','$hpe1','$pv','$uterocervical_length','$ectocervical_canal','$intra_operative','$npo_x_2hrs','$sips_of_fluid','$fluid_rl','$paracetamol','$justin_suppository','$monitor_pulse','$monitor_bleeding','$remove_vaginal','$normal_diet','$tab_ceftum','$cap_pantoprazole','$tab_crocin','$report')";
	  
	 //    $result = run_form_query($query);

  //       if($result){
  //         header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
		// 			die();
  //       }else{
  //         header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
		// 			die();
  //       }
  // 	}
?>-->

<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
  <input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
  <input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
  <input type="hidden" value="pending" name="status"> 
    <div class="container red-field form mt-5 mb-5">
    <table class="table table-bordered table-hover mt-2 table-sm red-field tableMg">
      <thead>
        <tr>
            <td colspan="2"><h2>LAPAROSCOPY AND HYSTEROSCOPY</h2></td>
            <td colspan="2">
			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
			            ){?>
			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
			    <?php } ?>
			</td>
        </tr>
        <tr>
            <th><h4>GENERAL INSTRUCTIONS</h4></th>
        </tr>
        <tr><td>1.Stop Tablet Ecosprin/Aspirin/Baby aspirin 48 hrs prior to procedure</td></tr>
        <tr><td>2.Continue thyroid/antihypertensive/other medical disorder medication with sips of water in the morning of procedure.</td></tr>
        <tr><td>3.If you are taking oral medications for diabetes please see anesthetist three days before procedure for instructions /medications /insulin.</td></tr>
        <tr><td>4.Pre anesthetic check up will be done</td></tr>
        <tr><td>5.You should arrange for a responsible adult to accompany you home from the day stay unit following procedure and to remain with you overnight. You should not be left alone in home for 24 hrs. following the procedures We can not perform procedure if you fail to arrange an escort. You will need to rest at home all day following the procedures, but you should feel well enough to resume normal activities the day after.</td></tr>
        <tr><td>6.Please leave valuables and jewelry at home. Please remove nail paint and make up prior to the procedure. It is important that you do not wear any strong perfumes before the procedure.</td></tr>
        <tr><td>7.Please remove vaginal hair (by normal waxing/shaving/trimming ) at home before you come for procedure</td></tr>
        <tr><td>8.You will be kept in for approximately 4-6 hours after your operation to allow a full recovery with no complications. Your escort should be available to take you home.</td></tr>
        <tr><td>9.Please remember to inform us of any medication (other than ivf drugs) that you take regularly-
        i.e. inhalers, blood pressure tablets. You should bring all medication with you to the fertility unit on the day of procedure.</td></tr>
        <tr><td>10. Do not take alcohol for 24 hours prior to your procedure. Please refrain from smoking for as long as possible before the procedure.</td></tr>
        <tr><td>11.We look forward to seeing you and will do everything to ensure a safe and comfortable stay.</td></tr>
      </thead>
    </table>
            <ul class="d-flex mb-1 mt-2 list-unstyled">
            <div class = "table-responsive">
              <table class="table table-bordered table-hover table-sm">
                <thead>
                  <tr style="color: red;">
                    <td><strong>LAPAROSCOPY & HYSTEROSCOPY</strong></td>
                    <td>Date <input type="date" value="<?php echo isset($select_result['date'])?$select_result['date']:""; ?>" class="form-control" placeholder="enter a date" name="date"></td>
                    <td>Time <input type="time" value="<?php echo isset($select_result['time'])?$select_result['time']:""; ?>" class="form-control" id="appt" name="time"></td>
                    <td>Indication <input type="text" value="<?php echo isset($select_result['indication'])?$select_result['indication']:""; ?>" maxlength="50" placeholder="indication" class="form-control" name="indication"></td>
                    <td>ALLERGIES <input type="text" value="<?php echo isset($select_result['allergy'])?$select_result['allergy']:""; ?>" maxlength="50" placeholder="allergy" class="form-control" name="allergy"></td>
                    <td>Consent<br>
                      <label><input type="radio" checked name="consent" value="Yes" <?php if(isset($select_result['consent']) && $select_result['consent'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="consent" value="No" <?php if(isset($select_result['consent']) && $select_result['consent'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['consent']) && $select_result['consent'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>ID checked<br>
                      <label><input type="radio" checked name="id_checked" value="Yes" <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="id_checked" value="No" <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['id_checked']) && $select_result['id_checked'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                  </tr>
                  <tr style="color: red;">
                    <td><strong>PRE ASSESSMENT</strong></td>
                    <td>BP <input type="text" value="<?php echo isset($select_result['bp'])?$select_result['bp']:""; ?>" maxlength="20" placeholder="BP" class="form-control" name="bp"></td>
                    <td>PULSE<br>
                      <label><input type="radio" checked name="pulse" value="Yes" <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="pulse" value="No" <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['pulse']) && $select_result['pulse'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>RESP<br>
                      <label><input type="radio" checked name="resp" value="Yes" <?php if(isset($select_result['resp']) && $select_result['resp'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="resp" value="No" <?php if(isset($select_result['resp']) && $select_result['resp'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp']) && $select_result['resp'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Voided<br>
                      <label><input type="radio" checked name="voided" value="Yes" <?php if(isset($select_result['voided']) && $select_result['voided'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="voided" value="No" <?php if(isset($select_result['voided']) && $select_result['voided'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['voided']) && $select_result['voided'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>HT (Cms)<input type="number" value="<?php echo isset($select_result['ht'])?$select_result['ht']:""; ?>" min="0" class="form-control" placeholder="HT" name="ht"></td>
                    <td>WT (Kg)<input type="number" value="<?php echo isset($select_result['wt'])?$select_result['wt']:""; ?>" min="0" class="form-control" placeholder="WT" name="wt"></td>
                  </tr>
                  <tr>
                    <td>Glasses<br>
                      <label><input type="radio" checked name="glasses" value="Yes" <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="glasses" value="No" <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['glasses']) && $select_result['glasses'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Contacts<br>
                      <label><input type="radio" checked name="contacts" value="Yes" <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="contacts" value="No" <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['contacts']) && $select_result['contacts'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Denture<br>
                      <label><input type="radio" checked name="denture" value="Yes" <?php if(isset($select_result['denture']) && $select_result['denture'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="denture" value="No" <?php if(isset($select_result['denture']) && $select_result['denture'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['denture']) && $select_result['denture'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td colspan="2">Dental bridge<br>
                      <label><input type="radio" checked name="dental_bridge" value="Yes" <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="dental_bridge" value="No" <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Valuables with escort<br>
                      <label><input type="radio" checked name="valuables_with_escort" value="Yes" <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                      <label><input type="radio" checked name="valuables_with_escort" value="No" <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Last meal <input type="time" value="<?php echo isset($select_result['last_meal'])?$select_result['last_meal']:""; ?>" class="form-control" name="last_meal"></td>
                  </tr>
                </thead>
              </table>
        </div>
    </ul>
    <div class = "">
        <table class="table table-bordered table-hover table-sm red-field tableMg">
            <thead>
              <tr>
                <td colspan="1">HPE</td>
                <td colspan="3">
                  <label><input type="radio" checked name="hpe1" value="Yes" <?php if(isset($select_result['hpe1']) && $select_result['hpe1'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                  <label><input type="radio" checked name="hpe1" value="No" <?php if(isset($select_result['hpe1']) && $select_result['hpe1'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['hpe1']) && $select_result['hpe1'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                </td>
              </tr>
              <tr>
                <td colspan="4"><b>Prescriptions given</b></td>
              </tr>
              <tr>
                <td colspan="4">
                  Injection Monocef 1 gm iv AST<br>
                  Injection Pantoprazole 40 mg i.m. stat<br>
                  Injection emset 1 gm iv stat<br>
                  Other <input type="text" value="<?php echo isset($select_result['prescription_given'])?$select_result['prescription_given']:""; ?>" class="form-control" name="prescription_given">
                </td>
              </tr>
            </thead>
        </table>
        <table class="table table-bordered table-hover  table-sm red-field tableMg">
            <thead>
                <tr>
                    <th>NURSE <input type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>" maxlength="20" class="form-control" name="nurse"></th>
                    <th>DOCTOR <input type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>" maxlength="20" class="form-control" name="doctor"></th>
                    <th>Anesthetist <input type="text" value="<?php echo isset($select_result['anesthetist'])?$select_result['anesthetist']:""; ?>" maxlength="20" class="form-control" name="anesthetist"></th>
                </tr>
            </thead>
        </table>
        <div class='table-responsive'>
          <table class="table table-bordered table-sm red-field tableMg">
            <tr>
              <td style="padding: 0;">
                <table width="100%">
                  <tr>
                    <td colspan="2"><b>PRE ASSESSMENT</b></td>
                  </tr>
                  <tr>
                    <td colspan="2">
                      No sexual intercourse for 72 hours<br>
                      No active  infection<br>
                      No aspirin or NSAID a week before 
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2"><b>Physical Examination</b></td>
                  </tr>
                  <tr>
                    <td>Resp</td>
                    <td><input type="text" value="<?php echo isset($select_result['resp2'])?$select_result['resp2']:""; ?>" maxlength="20" class="form" name="resp2"></td>
                  </tr>
                  <tr>
                    <td>CVS</td>
                    <td><input type="text" value="<?php echo isset($select_result['CVS'])?$select_result['CVS']:""; ?>" maxlength="20" class="form" name="CVS"></td>
                  </tr>
                  <tr>
                    <td>CNS</td>
                    <td><input type="text" value="<?php echo isset($select_result['CNS'])?$select_result['CNS']:""; ?>" maxlength="20" class="form" name="CNS"></td>
                  </tr>
                  <tr>
                    <td>Abdominal</td>
                    <td><input type="text" value="<?php echo isset($select_result['abdominal'])?$select_result['abdominal']:""; ?>" maxlength="20" class="form" name="abdominal"></td>
                  </tr>
                  <tr>
                    <td>Others</td>
                    <td><input  type="text" value="<?php echo isset($select_result['others'])?$select_result['others']:""; ?>" maxlength="100" class="form" name="others"></td>
                  </tr>
                </table>
              </td>
              <td style="padding: 0;">
                <table width="100%">
                  <tr style="color: black;">
                    <td colspan="2"><b>Diagnostic laparoscopy</b></td>
                  </tr>
                  <tr style="color: black;">
                    <td colspan="2">
                      <p>Written informed consent taken. All vitals checked under normal range. The anesthetist examined the patient and given general anesthesia.</p>
                      <p>Patient put in supine position and painted and draped in the abdominal area. Trocar introduced through the umbilicus and two more side ports created</p>
                    </td>
                  </tr>
                  <tr style="color: black;">
                    <td>Uterus visualized</td>
                    <td><input type="text" value="<?php echo isset($select_result['uterus_visualized'])?$select_result['uterus_visualized']:""; ?>" maxlength="20" name="uterus_visualized"></td>
                  </tr>
                  <tr style="color: black;">
                    <td>Bilateral tubes visualized</td>
                    <td><input type="text" value="<?php echo isset($select_result['bilateral_tubes'])?$select_result['bilateral_tubes']:""; ?>" maxlength="20" name="bilateral_tubes"></td>
                  </tr>
                  <tr style="color: black;">
                    <td>Bilateral ovaries visualized</td>
                    <td><input type="text" value="<?php echo isset($select_result['bilateral_ovaries'])?$select_result['bilateral_ovaries']:""; ?>" maxlength="20" name="bilateral_ovaries"></td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="2">Bilateral CPT done</td>
                  </tr>
                  <tr>
                    <td colspan="2"><h3><u>Findings:</u></h3></td>
                  </tr>
                  <tr>
                    <td>Uterus</td>
                    <td><input type="text" value="<?php echo isset($select_result['uterus'])?$select_result['uterus']:""; ?>" maxlength="20" class="form" name="uterus"></td>
                  </tr>
                  <tr>
                    <td>Tubes</td>
                    <td><input type="text" value="<?php echo isset($select_result['tubes'])?$select_result['tubes']:""; ?>" maxlength="20" class="form" name="tubes"></td>
                  </tr>
                  <tr>
                    <td>Ovaries</td>
                    <td><input type="text" value="<?php echo isset($select_result['ovaries'])?$select_result['ovaries']:""; ?>" maxlength="20" class="form" name="ovaries"></td>
                  </tr>
                  <tr>
                    <td>POD</td>
                    <td><input type="text" value="<?php echo isset($select_result['pod'])?$select_result['pod']:""; ?>" maxlength="20" class="form" name="pod"></td>
                  </tr>
                  <tr>
                    <td>Liver</td>
                    <td><input type="text" value="<?php echo isset($select_result['liver'])?$select_result['liver']:""; ?>" maxlength="20" class="form" name="liver"></td>
                  </tr>
                  <tr>
                    <td>Chromopertubation</td>
                    <td><input type="text" value="<?php echo isset($select_result['Chromopertubation'])?$select_result['Chromopertubation']:""; ?>" maxlength="20" class="form" name="Chromopertubation"></td>
                  </tr>
                  <tr>
                    <td>Any other findings</td>
                    <td><input type="text" value="<?php echo isset($select_result['any_other_findings'])?$select_result['any_other_findings']:""; ?>" maxlength="20" class= "form" name="any_other_findings"></td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="2">No complications seen. Bleeding was mild/moderate. Hemostasis achieved. Patient tolerated the procedure well and was transferred to the recovery room in satisfactory condition</td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="2"><b>Operative Laparoscopy</b></td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="2">Written informed consent taken. All vitals checked under normal range. The anesthetist examined the patient and given general anesthesia.</td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="2">Patient put in supine position and painted and draped in the abdominal area. Trocar introduced through the umbilicus and two more side ports created Comments <input type="text" value="<?php echo isset($select_result['comments1'])?$select_result['comments1']:""; ?>" maxlength="20" name="comments1"></td>
                  </tr>
                  <tr>
                    <td colspan="2"><h3><u>Findings:</u></h3></td>
                  </tr>
                  <tr>
                    <td>Uterus</td>
                    <td><input type="text" value="<?php echo isset($select_result['operative_uterus'])?$select_result['operative_uterus']:""; ?>" maxlength="20" class="form" name="operative_uterus"></td>
                  </tr>
                  <tr>
                    <td>Tubes</td>
                    <td><input type="text" value="<?php echo isset($select_result['operative_tubes'])?$select_result['operative_tubes']:""; ?>" maxlength="20" class="form" name="operative_tubes"></td>
                  </tr>
                  <tr>
                    <td>Ovaries</td>
                    <td><input type="text" value="<?php echo isset($select_result['operative_ovaries'])?$select_result['operative_ovaries']:""; ?>" maxlength="20" class="form" name="operative_ovaries"></td>
                  </tr>
                  <tr>
                    <td>POD</td>
                    <td><input type="text" value="<?php echo isset($select_result['operative_pod'])?$select_result['operative_pod']:""; ?>" maxlength="20" class="form" name="operative_pod"></td>
                  </tr>
                  <tr>
                    <td>Liver</td>
                    <td><input type="text" value="<?php echo isset($select_result['operative_liver'])?$select_result['operative_liver']:""; ?>" maxlength="20" class="form" name="operative_liver"></td>
                  </tr>
                  <tr>
                    <td>Chromopertubation</td>
                    <td><input type="text" value="<?php echo isset($select_result['operative_any_other_findings'])?$select_result['operative_any_other_findings']:""; ?>" maxlength="20" class="form" name="operative_Chromopertubation"></td>
                  </tr>
                  <tr>
                    <td>Any other findings</td>
                    <td><input type="text" value="<?php echo isset($select_result['hiv_1'])?$select_result['hiv_1']:""; ?>" maxlength="20" class="form" name="operative_any_other_findings"></td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="2">No complications seen. Bleeding was mild/moderate .Hemostasis achieved. Patient tolerated the procedure well and was transferred to the recovery room in satisfactory condition</td>
                  </tr>
                </table>
                <table>
                  <tr>
                    <td style="color: black;" colspan="3"><h3><u>Diagnostic hysteroscopy</u></h3></td>
                  </tr>
                  <tr style="color: black;">
                    <td colspan="3">Patient put in lithotomy position, under all sterile conditions, the vulva and vagina were cleansed by betadine and draped. Sims speculum with tenaculum introduced.</td>
                  </tr>
                  <tr style="color: black;">
                    <td>P/S</td>
                    <td>Cervix</td>
                    <td><input type="text" value="<?php echo isset($select_result['cervix'])?$select_result['cervix']:""; ?>" maxlength="20" class="form" name="cervix"></td>
                  </tr>
                  <tr style="color: black;">
                    <td></td>
                    <td>vagina</td>
                    <td><input type="text" value="<?php echo isset($select_result['vagina'])?$select_result['vagina']:""; ?>" maxlength="20" class="form" name="vagina"></td>
                  </tr>
                  <tr style="color: black;">
                    <td>P/V</td>
                    <td></td>
                    <td><input type="text" value="<?php echo isset($select_result['pv'])?$select_result['pv']:""; ?>" maxlength="20" class="form" name="pv"></td>
                  </tr>
                  <tr style="color: black;">
                    <td>Uterocervical length</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['uterocervical_length'])?$select_result['uterocervical_length']:""; ?>" maxlength="20" class="form" name="uterocervical_length"></td>
                  </tr>
                  <tr style="color: black;">
                    <td colspan="3">Hysteroscope introduced</td>
                  </tr>
                  <tr style="color: black;">
                    <td>Ectocervical canal</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['ectocervical_canal'])?$select_result['ectocervical_canal']:""; ?>" maxlength="20" class="form" name="ectocervical_canal"></td>
                  </tr>
                  <tr style="color: black;">
                    <td>Endometrial cavity</td>
                    <td colspan="2"><input name="endometrial_cavity" maxlength="20" type="text" value="<?php echo isset($select_result['endometrial_cavity'])?$select_result['endometrial_cavity']:""; ?>"></td>
                  </tr>
                  <tr style="color: black;">
                    <td>Bilateral ostia</td>
                    <td colspan="2"><input name="bilateral_ostia" maxlength="20" type="text" value="<?php echo isset($select_result['bilateral_ostia'])?$select_result['bilateral_ostia']:""; ?>"></td>
                  </tr>
                </table>
                <table>
                  <tr>
                    <td colspan="3"><h3><u>Hysteroscopy findings:</u></h3></td>
                  </tr>
                  <tr>
                    <td>Uterine cavity</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['uterine_cavity'])?$select_result['uterine_cavity']:""; ?>" maxlength="20" class="form" name="uterine_cavity"></td>
                  </tr>
                  <tr>
                    <td>Ostia</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['ostia'])?$select_result['ostia']:""; ?>" maxlength="20" class="form" name="ostia"></td>
                  </tr>
                  <tr>
                    <td>Endometrial Biopsy:</td>
                    <td>
                      <span class= "mr-2">TB</span>
                      <label><input type="radio" checked value="Yes" <?php if(isset($select_result['tb']) && $select_result['tb'] == "Yes"){echo 'checked="checked"'; }?>  name="tb"> Yes</label>
                      <label><input type="radio" checked value="No" <?php if(isset($select_result['tb']) && $select_result['tb'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tb']) && $select_result['tb'] != "Yes"){echo 'checked="checked"';}?>  name="tb"> No</label>
                    </td>
                    <td>
                      <span class="mr-2">HPE</span>
                      <label><input type="radio" checked value="Yes" <?php if(isset($select_result['hpe']) && $select_result['hpe'] == "Yes"){echo 'checked="checked"'; }?>  name="hpe"> Yes</label>
                      <label><input type="radio" checked value="No" <?php if(isset($select_result['hpe']) && $select_result['hpe'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['hpe']) && $select_result['hpe'] != "Yes"){echo 'checked="checked"';}?>  name="hpe"> No</label>
                    </td>
                  </tr>
                  <tr>
                    <td>Any other findings</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['operative_any_other_finding'])?$select_result['operative_any_other_finding']:""; ?>" maxlength="20" class="form" name="operative_any_other_finding"></td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="3">No complications seen. Bleeding was mild/moderate .Hemostasis achieved. Patient tolerated the procedure well and was transferred to the recovery room in satisfactory condition</td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="3"><b>Operative hysteroscopy</b></td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="3">Patient put in lithotomy position ,under all sterile conditions, the vulva and vagina were cleansed by betadine and draped. Sims speculum with tenaculum introduced.</td>
                  </tr>
                  <tr>
                  <tr style="color: black;">
                    <td colspan="1">Comments</td>
                    <td colspan="2"><input name="comments" maxlength="20" type="text" value="<?php echo isset($select_result['comments'])?$select_result['comments']:""; ?>"></td>
                  </tr>
                  <tr>
                    <td colspan="3"><h3><u>Hysteroscopy findings:</u></h3></td>
                  </tr>
                  <tr>
                    <td>Uterine cavity</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['uterine_cavity2'])?$select_result['uterine_cavity2']:""; ?>" maxlength="20" class="form" name="uterine_cavity2"></td>
                  </tr>
                  <tr>
                    <td>Ostia</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['ostia2'])?$select_result['ostia2']:""; ?>" maxlength="20" class="form" name="ostia2"></td>
                  </tr>
                  <tr>
                    <td>Endometrial Biopsy:</td>
                    <td>
                      <span class= "mr-2">TB</span>
                      <label><input type="radio" checked value="Yes" <?php if(isset($select_result['tb2']) && $select_result['tb2'] == "Yes"){echo 'checked="checked"'; }?>  name="tb2"> Yes</label>
                      <label><input type="radio" checked value="No" <?php if(isset($select_result['tb2']) && $select_result['tb2'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tb2']) && $select_result['tb2'] != "Yes"){echo 'checked="checked"';}?>  name="tb2"> No</label>
                    </td>
                    <td>
                      <span class="mr-2">HPE</span>
                      <label><input type="radio" checked value="Yes" <?php if(isset($select_result['hpe2']) && $select_result['hpe2'] == "Yes"){echo 'checked="checked"'; }?>  name="hpe2"> Yes</label>
                      <label><input type="radio" checked value="No" <?php if(isset($select_result['hpe2']) && $select_result['hpe2'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['hpe2']) && $select_result['hpe2'] != "Yes"){echo 'checked="checked"';}?>  name="hpe2"> No</label>
                    </td>
                  </tr>
                  <tr>
                    <td>Any other findings</td>
                    <td colspan="2"><input type="text" value="<?php echo isset($select_result['operative_any_other_finding2'])?$select_result['operative_any_other_finding2']:""; ?>" maxlength="20" class="form" name="operative_any_other_finding2"></td>
                  </tr>
                  <tr>
                    <td style="color: black;" colspan="3">No complications seen. Bleeding was mild/moderate. Hemostasis achieved. Patient tolerated the procedure well and was transferred to the recovery room in satisfactory condition.</td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </div>
          <table class="table table-bordered table-hover mb-2 table-sm tableMg">
            <thead>
              <tr style="color: red;">
                <td colspan="2"><b>Intra-operative orders</b></td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['intra_operative']) && $select_result['intra_operative'] == "Yes"){echo 'checked="checked"'; }?>  name="intra_operative"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['intra_operative']) && $select_result['intra_operative'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['intra_operative']) && $select_result['intra_operative'] != "Yes"){echo 'checked="checked"';}?>  name="intra_operative"> No</label>
                </td>
                <td>Intra-operative orders</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] == "Yes"){echo 'checked="checked"'; }?>  name="npo_x_2hrs"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] != "Yes"){echo 'checked="checked"';}?>  name="npo_x_2hrs"> No</label>
                </td>
                <td>NPO X 2HRS</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] == "Yes"){echo 'checked="checked"'; }?>  name="sips_of_fluid"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] != "Yes"){echo 'checked="checked"';}?>  name="sips_of_fluid"> No</label>
                </td>
                <td>Sips of fluid after 2 hrs fld by soft diet</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['fluid_rl']) && $select_result['fluid_rl'] == "Yes"){echo 'checked="checked"'; }?>  name="fluid_rl"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['fluid_rl']) && $select_result['fluid_rl'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['fluid_rl']) && $select_result['fluid_rl'] != "Yes"){echo 'checked="checked"';}?>  name="fluid_rl"> No</label>
                </td>
                <td>i.v. fluid R.L or NS 500 ml@ 125 ml/hr</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['paracetamol']) && $select_result['paracetamol'] == "Yes"){echo 'checked="checked"'; }?>  name="paracetamol"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['paracetamol']) && $select_result['paracetamol'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['paracetamol']) && $select_result['paracetamol'] != "Yes"){echo 'checked="checked"';}?>  name="paracetamol"> No</label>
                </td>
                <td>i.v. paracetamol 100 ml @8-10 drops/min</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] == "Yes"){echo 'checked="checked"'; }?>  name="justin_suppository"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] != "Yes"){echo 'checked="checked"';}?>  name="justin_suppository"> No</label>
                </td>
                <td>Justin suppository per rectally</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] == "Yes"){echo 'checked="checked"'; }?>  name="monitor_pulse"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] != "Yes"){echo 'checked="checked"';}?>  name="monitor_pulse"> No</label>
                </td>
                <td>Monitor pulse/BP/Spo2 continuously</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] == "Yes"){echo 'checked="checked"'; }?>  name="monitor_bleeding"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] != "Yes"){echo 'checked="checked"';}?>  name="monitor_bleeding"> No</label>
                </td>
                <td>Monitor bleeding p/v every half hour</td>
              </tr>
              <tr>
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['remove_vaginal']) && $select_result['remove_vaginal'] == "Yes"){echo 'checked="checked"'; }?>  name="remove_vaginal"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['remove_vaginal']) && $select_result['remove_vaginal'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['remove_vaginal']) && $select_result['remove_vaginal'] != "Yes"){echo 'checked="checked"';}?>  name="remove_vaginal"> No</label>
                </td>
                <td>Remove vaginal pack if any</td>
              </tr>
              <tr style="color: red;">
                <td colspan="2"><b>Post operative orders</b></td>
              </tr>
              <tr style="color: red;">
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "Yes"){echo 'checked="checked"'; }?>  name="normal_diet"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['normal_diet']) && $select_result['normal_diet'] != "Yes"){echo 'checked="checked"';}?>  name="normal_diet"> No</label>
                </td>
                <td>Normal diet</td>
              </tr>
              <tr style="color: red;">
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['tab_ceftum']) && $select_result['tab_ceftum'] == "Yes"){echo 'checked="checked"'; }?>  name="tab_ceftum"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['tab_ceftum']) && $select_result['tab_ceftum'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_ceftum']) && $select_result['tab_ceftum'] != "Yes"){echo 'checked="checked"';}?>  name="tab_ceftum"> No</label>
                </td>
                <td>Tab. Ceftum 500 mg twice daily one morning one evening after meals for 5 days</td>
              </tr>
              <tr style="color: red;">
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "Yes"){echo 'checked="checked"'; }?>  name="cap_pantoprazole"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] != "Yes"){echo 'checked="checked"';}?>  name="cap_pantoprazole"> No</label>
                </td>
                <td>Cap Pantoprazole 40 mg once daily in empty stomach for 5 days</td>
              </tr>
              <tr style="color: red;">
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "Yes"){echo 'checked="checked"'; }?>  name="tab_crocin"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] != "Yes"){echo 'checked="checked"';}?>  name="tab_crocin"> No</label>
                </td>
                <td>Tab Crocin 500 mg thrice daily eight hourly after meals for 2 days</td>
              </tr>
              <tr style="color: red;">
                <td>
                  <label><input type="radio" checked value="Yes" <?php if(isset($select_result['report']) && $select_result['report'] == "Yes"){echo 'checked="checked"'; }?>  name="report"> Yes</label>
                  <label><input type="radio" checked value="No" <?php if(isset($select_result['report']) && $select_result['report'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['report']) && $select_result['report'] != "Yes"){echo 'checked="checked"';}?>  name="report"> No</label>
                </td>
                <td>To report if giddiness /nausea/vomiting/bleeding/pain/fever /purulent discharge immediately</td>
              </tr>
              <tr style="color: red;">
                <th colspan="2"><p>Doctors signature <input name="doctor_signature" type="text" value="<?php echo isset($select_result['doctor_signature'])?$select_result['doctor_signature']:""; ?>"></p></th>
              </tr>
            </thead> 
          </table>
        </div>
          <!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
          <input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
  </form>