<?php
	if(isset($_POST['submit'])){
		unset($_POST['submit']);
		
        if(!empty($_FILES['pic1']['tmp_name'])){
			$dest_path = $this->config->item('upload_path');
			$destination = $dest_path.'procedure-forms-uploads/';
			$NewImageName = rand(4,10000)."-".$_FILES['pic1']['name'];
			$transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
			move_uploaded_file($_FILES['pic1']['tmp_name'], $destination.$NewImageName);
			$_POST['pic1'] = $transaction_img;
		}
		if(!empty($_FILES['pic2']['tmp_name'])){
			$dest_path = $this->config->item('upload_path');
			$destination = $dest_path.'procedure-forms-uploads/';
			$NewImageName = rand(4,10000)."-".$_FILES['pic2']['name'];
			$transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
			move_uploaded_file($_FILES['pic2']['tmp_name'], $destination.$NewImageName);
			$_POST['pic2'] = $transaction_img;
		}
        
        $select_query = "SELECT * FROM `sonosalpingography` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `sonosalpingography` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE sonosalpingography SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `sonosalpingography` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
	$select_result = run_select_query($select_query);  
	
	// php code to Insert data into mysql database from input text
	// if(isset($_POST['submit'])){
	// 	$patient_id = $_POST['patient_id'];
    //     $receipt_number = $_POST['receipt_number'];
	// 	$status = $_POST['status'];
	// 	// get values form input text and number
	// 	$date = $_POST['date'];
	// 	$time = $_POST['time'];
	// 	$ht = $_POST['ht'];
	// 	$wt = $_POST['wt'];
	// 	$consent = $_POST['consent'];
	// 	$id_ = $_POST['id_'];
	// 	$bp = $_POST['bp'];
	// 	$pulse = $_POST['pulse'];
	// 	$resp = $_POST['resp'];
	// 	$voided = $_POST['voided'];
	// 	$allergies = $_POST['allergies'];
	// 	$contacts = $_POST['contacts'];
	// 	$denture = $_POST['denture'];
	// 	$dental_bridge = $_POST['dental_bridge'];
	// 	$escort = $_POST['escort'];
	// 	$last_meal = $_POST['last_meal'];
	// 	$indication = $_POST['indication'];
	// 	$resp2 = $_POST['resp2'];
	// 	$cvs = $_POST['cvs'];
	// 	$cns = $_POST['cns'];
	// 	$abdominal = $_POST['abdominal'];
	// 	$others2 = $_POST['others2'];
	// 	$other = $_POST['other'];
	// 	$right_fallopian = $_POST['right_fallopian'];
	// 	$right_description = $_POST['right_description'];
	// 	$left_fallopian = $_POST['left_fallopian'];
	// 	$left_description = $_POST['left_description'];
	// 	$described = $_POST['described'];
	// 	$pod = $_POST['pod'];
	// 	$complications = $_POST['complications'];
	// 	$other2 = $_POST['other2'];
	// 	$comments = $_POST['comments'];
	// 	$pic1 = $_POST['pic1'];
	// 	$pic2 = $_POST['pic2'];
	// 	$nurse = $_POST['nurse'];
	// 	$doctor = $_POST['doctor'];
	// 	$doctors_signature = $_POST['doctors_signature'];
	// 	$date2 = $_POST['date2'];
	// 	$bp2 = $_POST['bp2'];
	// 	$indication2 = $_POST['indication2'];
	// 	$glasses = $_POST['glasses'];
	// 	$inj_drotin = $_POST['inj_drotin'];
	// 	$inj_pantoprazole = $_POST['inj_pantoprazole'];
	// 	$lignocaine_jelly = $_POST['lignocaine_jelly'];
	// 	$other_prescription = $_POST['other_prescription'];
	// 	$primary_infertility = $_POST['primary_infertility'];
	// 	$secondary_infertility = $_POST['secondary_infertility'];
	// 	$recurrent_pregnancy_loss = $_POST['recurrent_pregnancy_loss'];
	// 	$uterine_cavity = $_POST['uterine_cavity'];
	// 	$normal_diet = $_POST['normal_diet'];
	// 	$tab_doxycycline = $_POST['tab_doxycycline'];
	// 	$cap_pantoprazole = $_POST['cap_pantoprazole'];
	// 	$tab_crocin = $_POST['tab_crocin'];
	// 	$report = $_POST['report'];

	// 	// connect to mysql database using mysqli
		
		
	// 	// mysql query to insert data
	// 	$query = "INSERT INTO `sonosalpingography`(`patient_id`, `receipt_number`, `status`,`date`,`time`,`ht`,`wt`,`consent`,`id_`,`bp`,`pulse`,`resp`,`voided`,`allergies`,`contacts`,`denture`,`dental_bridge`,`escort`,`last_meal`,`indication`,`resp2`,`cvs`,`cns`,`abdominal`,`others2`,`other`,`right_fallopian`,`right_description`,`left_fallopian`,`left_description`,`described`,`pod`,`complications`,`other2`,`comments`,`pic1`,`pic2`,`nurse`,`doctor`,`doctors_signature`,`date2`,`bp2`,`indication2`,`glasses`,`inj_drotin`,`inj_pantoprazole`,`lignocaine_jelly`,`other_prescription`,`primary_infertility`,`secondary_infertility`,`recurrent_pregnancy_loss`,`uterine_cavity`,`normal_diet`,`tab_doxycycline`,`cap_pantoprazole`,`tab_crocin`,`report`) VALUES ('$patient_id','$receipt_number','$status','$date','$time','$ht','$wt','$consent','$id_','$bp','$pulse','$resp','$voided','$allergies','$contacts','$denture','$dental_bridge','$escort','$last_meal','$indication','$resp2','$cvs','$cns','$abdominal','$others2','$other','$right_fallopian','$right_description','$left_fallopian','$left_description','$described','$pod','$complications','$other2','$comments','$pic1','$pic2','$nurse','$doctor','$doctors_signature','$date2','$bp2','$indication2','$glasses','$inj_drotin','$inj_pantoprazole','$lignocaine_jelly','$other_prescription','$primary_infertility','$secondary_infertility','$recurrent_pregnancy_loss','$uterine_cavity','$normal_diet','$tab_doxycycline','$cap_pantoprazole','$tab_crocin','$report')";
		
	// 	$result = run_form_query($query);

    //     if($result){
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
	// 				die();
    //     }else{
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
	// 				die();
    //     }
	// }
?>

<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
	<input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
	<input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
	<input type="hidden" value="pending" name="status"> 
	<table class="table-bordered">
		<tr>
			<td colspan="2" style="color: red;">SONOSALPINGOGRAPHY</td>
			<td colspan="2">
			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
			            ){?>
			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
			    <?php } ?>
			</td>
			<td style="color: red;">
				Date<br>
				<input  type="date" value="<?php echo isset($select_result['date'])?$select_result['date']:""; ?>"     name="date" class="form-control" >
			</td>
			<td style="color: red;">
				Time<br>
				<input  type="time" value="<?php echo isset($select_result['time'])?$select_result['time']:""; ?>"     name="time" class="form-control" >
			</td>
			<td style="color: red;">
				Indication<br>
				<input  type="text" value="<?php echo isset($select_result['indication'])?$select_result['indication']:""; ?>"     maxlength="50" name="indication" class="form-control" >
			</td>
			<td style="color: red;">
				Allergies<br>
				<input  type="text" value="<?php echo isset($select_result['allergies'])?$select_result['allergies']:""; ?>"     maxlength="50" name="allergies" class="form-control" >
			</td>
			<td style="color: red;">
				Consent<br>
				<input type="radio"  name="consent"   value="Yes"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="consent"   value="No"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['consent']) && $select_result['consent'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td style="color: red;">
				ID <br>
				<input type="radio"  name="id_checked"   value="Yes"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="id_checked"   value="No"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['id_checked']) && $select_result['id_checked'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td style="color: red;">
				Date<br>
				<input  type="date" value="<?php echo isset($select_result['date2'])?$select_result['date2']:""; ?>"     name="date2" class="form-control" >
			</td>
		</tr>
		<tr>
			<td style="color: red;">PRE ASSESSMENT</td>
			<td style="color: red;">
				BP<br>
				<input  type="text" value="<?php echo isset($select_result['bp'])?$select_result['bp']:""; ?>"     maxlength="20" name="bp" class="form-control" >
			</td>
			<td style="color: red;">
				PULSE<br>
				<input type="radio"  name="pulse"   value="Yes"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="pulse"   value="No"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['pulse']) && $select_result['pulse'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td style="color: red;">
				RESP<br>
				<input type="radio"  name="resp"   value="Yes"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="resp"   value="No"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp']) && $select_result['resp'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td style="color: red;">
				Voided<br>
				<input type="radio"  name="voided"   value="Yes"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="voided"   value="No"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['voided']) && $select_result['voided'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td style="color: red;">
				Ht (Cms)<br>
				<input  type="number" value="<?php echo isset($select_result['ht'])?$select_result['ht']:""; ?>"     min="0" name="ht" class="form-control" >
			</td>
			<td style="color: red;">
				Wt (Kg)<br>
				<input  type="number" value="<?php echo isset($select_result['wt'])?$select_result['wt']:""; ?>"     min="0" name="wt" class="form-control" >
			</td>
			<td style="color: red;">
				BP<br>
				<input  type="text" value="<?php echo isset($select_result['bp2'])?$select_result['bp2']:""; ?>"     maxlength="20" name="bp2" class="form-control" >
			</td>
		</tr>
		<tr>
			<td>
				Glasses<br>
				<input type="radio"  name="glasses"   value="Yes"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="glasses"   value="No"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['glasses']) && $select_result['glasses'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Contacts<br>
				<input type="radio"  name="contacts"   value="Yes"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="contacts"   value="No"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['contacts']) && $select_result['contacts'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Denture<br>
				<input type="radio"  name="denture"   value="Yes"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="denture"   value="No"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['denture']) && $select_result['denture'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td colspan="2">
				Dental bridge<br>
				<input type="radio"  name="dental_bridge"   value="Yes"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="dental_bridge"   value="No"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Valuables with escort<br>
				<input type="radio"  name="escort"   value="Yes"  <?php if(isset($select_result['escort']) && $select_result['escort'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="escort"   value="No"  <?php if(isset($select_result['escort']) && $select_result['escort'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['escort']) && $select_result['escort'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Last meal<br>
				<input  type="time" value="<?php echo isset($select_result['last_meal'])?$select_result['last_meal']:""; ?>"     name="last_meal" class="form-control" >
			</td>
			<td>
				Indication<br>
				<input  type="text" value="<?php echo isset($select_result['indication2'])?$select_result['indication2']:""; ?>"     name="indication2" class="form-control" >
			</td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td colspan="2">Prescriptions given</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="inj_drotin"   value="Yes"  <?php if(isset($select_result['inj_drotin']) && $select_result['inj_drotin'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="inj_drotin"   value="No"  <?php if(isset($select_result['inj_drotin']) && $select_result['inj_drotin'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['inj_drotin']) && $select_result['inj_drotin'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>Injection Drotin 1 amp i.m. stat</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="inj_pantoprazole"   value="Yes"  <?php if(isset($select_result['inj_pantoprazole']) && $select_result['inj_pantoprazole'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="inj_pantoprazole"   value="No"  <?php if(isset($select_result['inj_pantoprazole']) && $select_result['inj_pantoprazole'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['inj_pantoprazole']) && $select_result['inj_pantoprazole'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>Injection Pantoprazole 40 mg i.m. stat</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="lignocaine_jelly"   value="Yes"  <?php if(isset($select_result['lignocaine_jelly']) && $select_result['lignocaine_jelly'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="lignocaine_jelly"   value="No"  <?php if(isset($select_result['lignocaine_jelly']) && $select_result['lignocaine_jelly'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['lignocaine_jelly']) && $select_result['lignocaine_jelly'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>Lignocaine jelly applied vaginally</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="other_prescription"   value="Yes"  <?php if(isset($select_result['other_prescription']) && $select_result['other_prescription'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="other_prescription"   value="No"  <?php if(isset($select_result['other_prescription']) && $select_result['other_prescription'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['other_prescription']) && $select_result['other_prescription'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>Other</td>
		</tr>
	</table>
	<table class="table-bordered">
		<tr style="color: red;">
			<td>NURSE</td>
			<td><input  type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>"     maxlegth="20" name="nurse" class="form-control"></td>
			<td>DOCTOR</td>
			<td><input  type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>"     maxlegth="20" name="doctor" class="form-control"></td>
		</tr>
		<tr>
			<td width="35%" style="padding: 0;" colspan="2">
				<table width="100%">
					<tr>
						<td colspan="2">Physical Examination</td>
					</tr>
					<tr>
						<td>
							<input type="radio"  name="resp2"   value="Yes"  <?php if(isset($select_result['resp2']) && $select_result['resp2'] == "Yes"){echo 'checked="checked"'; }?> > Yes
							<input type="radio"  name="resp2"   value="No"  <?php if(isset($select_result['resp2']) && $select_result['resp2'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp2']) && $select_result['resp2'] != "Yes"){echo 'checked="checked"';}?>  > No
						</td>
						<td>Resp</td>
					</tr>
					<tr>
						<td>
							<input type="radio"  name="cvs"   value="Yes"  <?php if(isset($select_result['cvs']) && $select_result['cvs'] == "Yes"){echo 'checked="checked"'; }?> > Yes
							<input type="radio"  name="cvs"   value="No"  <?php if(isset($select_result['cvs']) && $select_result['cvs'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cvs']) && $select_result['cvs'] != "Yes"){echo 'checked="checked"';}?>  > No
						</td>
						<td>CVS</td>
					</tr>
					<tr>
						<td>
							<input type="radio"  name="cns"   value="Yes"  <?php if(isset($select_result['cns']) && $select_result['cns'] == "Yes"){echo 'checked="checked"'; }?> > Yes
							<input type="radio"  name="cns"   value="No"  <?php if(isset($select_result['cns']) && $select_result['cns'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cns']) && $select_result['cns'] != "Yes"){echo 'checked="checked"';}?>  > No
						</td>
						<td>CNS</td>
					</tr>
					<tr>
						<td>
							<input type="radio"  name="abdominal"  value="Yes"  <?php if(isset($select_result['abdominal']) && $select_result['abdominal'] == "Yes"){echo 'checked="checked"'; }?> > Yes
							<input type="radio"  name="abdominal"   value="No"  <?php if(isset($select_result['abdominal']) && $select_result['abdominal'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['abdominal']) && $select_result['abdominal'] != "Yes"){echo 'checked="checked"';}?>  > No
						</td>
						<td>Abdominal</td>
					</tr>
					<tr>
						<td>
							<input type="radio"  name="others2"   value="Yes"  <?php if(isset($select_result['others2']) && $select_result['others2'] == "Yes"){echo 'checked="checked"'; }?> > Yes
							<input type="radio"  name="others2"   value="No"  <?php if(isset($select_result['others2']) && $select_result['others2'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['others2']) && $select_result['others2'] != "Yes"){echo 'checked="checked"';}?>  > No
						</td>
						<td>Others</td>
					</tr>
				</table>
			</td>
			<td colspan="2">
				<p>Written informed consent taken . All vitals  under normal range. Patient put in lithotomy position ,under all sterile conditions, the vulva and vagina were cleansed by betadine and draped. A condom with lubricated jelly is put on the vaginal ultrasound probe,it is introduced transvaginally  ,a baseline transvaginal ultrasound performed to see endometrium and ovaries. Following baseline scan , a sterile Cuscos speculum /Sims speculum with tenaculum introduced .The cervix cleansed with betadine.A 6 Fr Foleys catheter introduced in the uterine cavity ,its bulb inflated and catheter clamped . The speculum is taken out and again the transvaginal ultrasound probe introduced .Sterile saline 20 ml is then injected into the uterine cavity through the catheter and ultrasound is performed to see spillage from both the tubes and shape of uterine cavity </p>
				<p>Rt tube spillage seen/not seen. Lt.Tube spillage seen/not seen.Uterine cavity regular/irregular .Fluid is seen/not seen in POD.</p>
				<p>No complications seen. Catheter deflated and removed from uterine cavity and speculum also removed.</p>
				<p>Patient stood the procedure well.</p>
			</td>
		</tr>
	</table>
	<table class="table-bordered" style="width: 100%; color: red;">
		<tr>
			<td style="text-align: center;">SONOSALPINGOGRAPHY REPORT</td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
	</table>
	<table class="table-bordered" style="width: 100%; color: red;">
		<tr>
			<td><b>History</b></td>
			<td>
				Primary Infertility
				<input type="radio"  name="primary_infertility"   value="Yes"  <?php if(isset($select_result['primary_infertility']) && $select_result['primary_infertility'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="primary_infertility"   value="No"  <?php if(isset($select_result['primary_infertility']) && $select_result['primary_infertility'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['primary_infertility']) && $select_result['primary_infertility'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Secondary Infertility
				<input type="radio"  name="secondary_infertility"   value="Yes"  <?php if(isset($select_result['secondary_infertility']) && $select_result['secondary_infertility'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="secondary_infertility"   value="No"  <?php if(isset($select_result['secondary_infertility']) && $select_result['secondary_infertility'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['secondary_infertility']) && $select_result['secondary_infertility'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Recurrent Pregnancy Loss
				<input type="radio"  name="recurrent_pregnancy_loss"   value="Yes"  <?php if(isset($select_result['recurrent_pregnancy_loss']) && $select_result['recurrent_pregnancy_loss'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="recurrent_pregnancy_loss"   value="No"  <?php if(isset($select_result['recurrent_pregnancy_loss']) && $select_result['recurrent_pregnancy_loss'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['recurrent_pregnancy_loss']) && $select_result['recurrent_pregnancy_loss'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
		</tr>
	</table>
	<table class="table-bordered" style="width: 100%; color: red;">
		<tr>
			<td>Other</td>
			<td><input  type="text" value="<?php echo isset($select_result['other'])?$select_result['other']:""; ?>"     maxlength="100" name="other" class="form-control"></td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td>Right Fallopian Tube:</td>
			<td>
				<input type="radio" <?php if(isset($select_result['right_fallopian']) && $select_result['right_fallopian'] == "seen"){echo 'checked="checked"'; }?>    name="right_fallopian" value="seen"> free spill of saline seen
				<input type="radio" <?php if(isset($select_result['right_fallopian']) && $select_result['right_fallopian'] == "not_seen"){echo 'checked="checked"'; }?>   name="right_fallopian" value="not_seen"> not seen
			</td>
		</tr>
		<tr>
			<td>Other/ Description</td>
			<td><input  type="text" value="<?php echo isset($select_result['right_description'])?$select_result['right_description']:""; ?>"     maxlength="100" name="right_description" class="form-control"></td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td>Left Fallopian Tube:</td>
			<td>
				<input type="radio" <?php if(isset($select_result['left_fallopian']) && $select_result['left_fallopian'] == "seen"){echo 'checked="checked"'; }?>   name="left_fallopian" value="seen"> free spill of saline seen
				<input type="radio" <?php if(isset($select_result['left_fallopian']) && $select_result['left_fallopian'] == "not_seen"){echo 'checked="checked"'; }?>   name="left_fallopian" value="not_seen"> not seen
			</td>
		</tr>
		<tr>
			<td>Other/ Description</td>
			<td><input  type="text" value="<?php echo isset($select_result['left_description'])?$select_result['left_description']:""; ?>"     maxlength="100" name="left_description" class="form-control"></td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
	</table>
	<table class="table-bordered" style="width: 100%; color: red;">
		<tr>
			<td>Uterine cavity :</td>
			<td>
				<input type="radio" <?php if(isset($select_result['uterine_cavity']) && $select_result['uterine_cavity'] == "regular"){echo 'checked="checked"'; }?>   name="uterine_cavity" value="regular"> Regular
				<input type="radio" <?php if(isset($select_result['uterine_cavity']) && $select_result['uterine_cavity'] == "Filling defect"){echo 'checked="checked"'; }?>  name="uterine_cavity" value="Filling defect"> Filling defect
			</td>
		</tr>
		<tr>
			<td></td>
			<td colspan="2" style="padding: 0;">
				<table width="100%">
					<tr>
						<td>Describe</td>
						<td><input  type="text" value="<?php echo isset($select_result['described'])?$select_result['described']:""; ?>"     name="described" class="form-control"></td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td></td>
			<td>POD:</td>
			<td>
				<input type="radio"  <?php if(isset($select_result['pod']) && $select_result['pod'] == "seen"){echo 'checked="checked"'; }?>   name="pod" value="seen"> fluid seen
				<input type="radio"  <?php if(isset($select_result['pod']) && $select_result['pod'] == "seen"){echo 'checked="checked"'; }?>   name="pod" value="not seen"> Not Seen
			</td>
		</tr>
		<tr>
			<td></td>
			<td>Pressure: Normal</td>
		</tr>
		<tr>
			<td></td>
			<td colspan="2" style="padding: 0;">
				<table width="100%">
					<tr>
						<td>Complications:</td>
						<td><input type="radio"  <?php if(isset($select_result['complications']) && $select_result['complications'] == "Pain"){echo 'checked="checked"'; }?>   name="complications" value="Pain"> Pain</td>
						<td><input type="radio"  <?php if(isset($select_result['complications']) && $select_result['complications'] == "None"){echo 'checked="checked"'; }?>  name="complications" value="None"> None</td>
						<td><input type="radio"  <?php if(isset($select_result['complications']) && $select_result['complications'] == "Mild"){echo 'checked="checked"'; }?>  name="complications" value="Mild"> Mild</td>
						<td><input type="radio"  <?php if(isset($select_result['complications']) && $select_result['complications'] == "Moderate"){echo 'checked="checked"'; }?>  name="complications" value="Moderate"> Moderate</td>
						<td><input type="radio"  <?php if(isset($select_result['complications']) && $select_result['complications'] == "Severe"){echo 'checked="checked"'; }?>  name="complications" value="Severe"> Severe</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td></td>
			<td>Other:</td>
			<td><input  type="text" value="<?php echo isset($select_result['other2'])?$select_result['other2']:""; ?>"     maxlength="100" name="other2" class="form-control"></td>
		</tr>
		<tr>
			<td></td>
			<td>Comments/Drawing</td>
			<td><input  type="text" value="<?php echo isset($select_result['comments'])?$select_result['comments']:""; ?>"     maxlength="100" name="comments" class="form-control"></td>
		</tr>
	</table>
	<table class="table-bordered" style="width: 100%; color: red;">
		<tr>
			<td>Pic1:</td>
			<td><input type="file" name="pic1" class="form-control">
			<a target="_blank" href="<?php echo !empty($select_result['pic1'])?$select_result['pic1']:"javascript:void(0)"; ?>">Download</a>
			</td>
			<td>Pic2:</td>
			<td><input type="file" name="pic2" class="form-control">
			<a target="_blank" href="<?php echo !empty($select_result['pic2'])?$select_result['pic2']:"javascript:void(0)"; ?>">Download</a>
			</td>
		</tr>
	</table>
	<table class="table-bordered" style="width: 100%; color: red;">
		<tr>
			<td colspan="2"><b>Post Procedure orders</b></td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="normal_diet"   value="Yes"  <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="normal_diet"   value="No"  <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['normal_diet']) && $select_result['normal_diet'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Normal diet
			</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="tab_doxycycline"   value="Yes"  <?php if(isset($select_result['tab_doxycycline']) && $select_result['tab_doxycycline'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="tab_doxycycline"   value="No"  <?php if(isset($select_result['tab_doxycycline']) && $select_result['tab_doxycycline'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_doxycycline']) && $select_result['tab_doxycycline'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Tab.Doxycycline 100 mg twice daily one morning one evening after meals for 5 days
			</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="cap_pantoprazole"   value="Yes"  <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="cap_pantoprazole"   value="No"  <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Cap Pantoprazole 40 mg once daily in empty stomach for 5 days
			</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="tab_crocin"   value="Yes"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="tab_crocin"   value="No"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				Tab Crocin 500 mg thrice daily eight hourly after meals for 2 days
			</td>
		</tr>
		<tr>
			<td>
				<input type="radio"  name="report"   value="Yes"  <?php if(isset($select_result['report']) && $select_result['report'] == "Yes"){echo 'checked="checked"'; }?> > Yes
				<input type="radio"  name="report"   value="No"  <?php if(isset($select_result['report']) && $select_result['report'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['report']) && $select_result['report'] != "Yes"){echo 'checked="checked"';}?>  > No
			</td>
			<td>
				To report if giddiness /nausea/vomiting/bleeding/pain/fever/purulent discharge immediately
			</td>
		</tr>
		<tr>
			<td>Doctors signature</td>
			<td><input  type="text" value="<?php echo isset($select_result['doctors_signature'])?$select_result['doctors_signature']:""; ?>"     name="doctors_signature" class="form-control"></td>
		</tr>
	</table>
	<!-- /.card-body -->
	<div class="card-footer">
		<!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
		<input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
	</div>
</form>