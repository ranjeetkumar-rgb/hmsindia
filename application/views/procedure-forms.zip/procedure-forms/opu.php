<?php

    // php code to Insert data into mysql database from input text

    if(isset($_POST['submit'])){

        unset($_POST['submit']);

    

        if(!empty($_FILES['upload']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['upload']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['upload']['tmp_name'], $destination.$NewImageName);

            $_POST['upload'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_1']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_1']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_1']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_1'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_2']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_2']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_2']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_2'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_3']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_3']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_3']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_3'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_4']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_4']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_4']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_4'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_5']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_5']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_5']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_5'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_6']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_6']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_6']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_6'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_7']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_7']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_7']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_7'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_8']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_8']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_8']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_8'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_9']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_9']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_9']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_9'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_10']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_10']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_10']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_10'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_11']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_11']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_11']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_11'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_12']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_12']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_12']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_12'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_13']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_13']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_13']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_13'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_14']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_14']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_14']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_14'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_15']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_15']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_15']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_15'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_16']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_16']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_16']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_16'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_17']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_17']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_17']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_17'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_18']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_18']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_18']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_18'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_19']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_19']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_19']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_19'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_20']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_20']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_20']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_20'] = $transaction_img;

        }

        ;

        if(!empty($_FILES['oocytes_retreived_photo_21']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_21']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_21']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_21'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_22']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_22']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_22']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_22'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_23']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_23']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_23']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_23'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_24']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_24']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_24']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_24'] = $transaction_img;

        }

        

        if(!empty($_FILES['oocytes_retreived_photo_25']['tmp_name'])){

            $dest_path = $this->config->item('upload_path');

            $destination = $dest_path.'procedure-forms-uploads/';

            $NewImageName = rand(4,10000)."-".$_FILES['oocytes_retreived_photo_25']['name'];

            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;

            move_uploaded_file($_FILES['oocytes_retreived_photo_25']['tmp_name'], $destination.$NewImageName);

            $_POST['oocytes_retreived_photo_25'] = $transaction_img;

        }

        

        $select_query = "SELECT * FROM `opu` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";

        $select_result = run_select_query($select_query); 

        if(empty($select_result)){

            // mysql query to insert data

            $query = "INSERT INTO `opu` SET ";

            $sqlArr = array();

            foreach( $_POST as $key=> $value )

            {

              $sqlArr[] = " $key = '".addslashes($value)."'";

            }       

            $query .= implode(',' , $sqlArr);

        }else{

            // mysql query to update data

            $query = "UPDATE opu SET ";

            foreach( $_POST as $key=> $value )

            {

              $sqlArr[] = " $key = '".$value."'"    ;

            }

            $query .= implode(',' , $sqlArr);

            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";

        }

        $result = run_form_query($query);        



        if($result){

          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));

					die();

        }else{

          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));

					die();

        }

    }

    $select_query = "SELECT * FROM `opu` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";

    $select_result = run_select_query($select_query);  

    

?>



<!--<?php

	// php code to Insert data into mysql database from input text

	// if(isset($_POST['submit'])){

	// 	$patient_id = $_POST['patient_id'];

 //        $receipt_number = $_POST['receipt_number'];

 //        $status = $_POST['status'];

    

	// 	// get values form input text and number

 //        $partners_name = $_POST['partners_name'];

 //        $art_bank_reg_no = $_POST['art_bank_reg_no'];

 //        $form_id = $_POST['form_id'];

 //        $donor_d = $_POST['donor_d'];

 //        $upload = $_POST['upload'];

 //        $needle_used = $_POST['needle_used'];

 //        $completion_time = $_POST['completion_time'];

 //        $trigger_time = $_POST['trigger_time'];

 //        $procdure_time = $_POST['procdure_time'];

 //        $date_1 = $_POST['date_1'];

 //        $date_2 = $_POST['date_2'];

 //        $date_3 = $_POST['date_3'];

 //        $date_4 = $_POST['date_4'];

 //        $date_5 = $_POST['date_5'];

 //        $coc_retreived_1 = $_POST['coc_retreived_1'];

 //        $coc_retreived_2 = $_POST['coc_retreived_2'];

 //        $coc_retreived_3 = $_POST['coc_retreived_3'];

 //        $coc_retreived_4 = $_POST['coc_retreived_4'];

 //        $coc_retreived_5 = $_POST['coc_retreived_5'];

 //        $oocytes_retreived_no_1 = $_POST['oocytes_retreived_no_1'];

 //        $oocytes_retreived_no_2 = $_POST['oocytes_retreived_no_2'];

 //        $oocytes_retreived_no_3 = $_POST['oocytes_retreived_no_3'];

 //        $oocytes_retreived_no_4 = $_POST['oocytes_retreived_no_4'];

 //        $oocytes_retreived_no_5 = $_POST['oocytes_retreived_no_5'];

 //        $oocytes_retreived_photo_1 = $_POST['oocytes_retreived_photo_1'];

 //        $oocytes_retreived_photo_2 = $_POST['oocytes_retreived_photo_2'];

 //        $oocytes_retreived_photo_3 = $_POST['oocytes_retreived_photo_3'];

 //        $oocytes_retreived_photo_4 = $_POST['oocytes_retreived_photo_4'];

 //        $oocytes_retreived_photo_5 = $_POST['oocytes_retreived_photo_5'];

 //        $m2_1 = $_POST['m2_1'];

 //        $m2_2 = $_POST['m2_2'];

 //        $m2_3 = $_POST['m2_3'];

 //        $m2_4 = $_POST['m2_4'];

 //        $m2_5 = $_POST['m2_5'];

 //        $m1_1 = $_POST['m1_1'];

 //        $m1_2 = $_POST['m1_2'];

 //        $m1_3 = $_POST['m1_3'];

 //        $m1_4 = $_POST['m1_4'];

 //        $m1_5 = $_POST['m1_5'];

 //        $gv_1 = $_POST['gv_1'];

 //        $gv_2 = $_POST['gv_2'];

 //        $gv_3 = $_POST['gv_3'];

 //        $gv_4 = $_POST['gv_4'];

 //        $gv_5 = $_POST['gv_5'];

 //        $tubes_dish_1 = $_POST['tubes_dish_1'];

 //        $tubes_dish_2 = $_POST['tubes_dish_2'];

 //        $tubes_dish_3 = $_POST['tubes_dish_3'];

 //        $tubes_dish_4 = $_POST['tubes_dish_4'];

 //        $tubes_dish_5 = $_POST['tubes_dish_5'];

 //        $eggs_transferred_1 = $_POST['eggs_transferred_1'];

 //        $eggs_transferred_2 = $_POST['eggs_transferred_2'];

 //        $eggs_transferred_3 = $_POST['eggs_transferred_3'];

 //        $eggs_transferred_4 = $_POST['eggs_transferred_4'];

 //        $eggs_transferred_5 = $_POST['eggs_transferred_5'];

 //        $freezing_date_1 = $_POST['freezing_date_1'];

 //        $freezing_date_2 = $_POST['freezing_date_2'];

 //        $freezing_date_3 = $_POST['freezing_date_3'];

 //        $freezing_date_4 = $_POST['freezing_date_4'];

 //        $freezing_date_5 = $_POST['freezing_date_5'];

 //        $freezing_media_1 = $_POST['freezing_media_1'];

 //        $freezing_media_2 = $_POST['freezing_media_2'];

 //        $freezing_media_3 = $_POST['freezing_media_3'];

 //        $freezing_media_4 = $_POST['freezing_media_4'];

 //        $freezing_media_5 = $_POST['freezing_media_5'];

 //        $freezing_container_1 = $_POST['freezing_container_1'];

 //        $freezing_container_2 = $_POST['freezing_container_2'];

 //        $freezing_container_3 = $_POST['freezing_container_3'];

 //        $freezing_container_4 = $_POST['freezing_container_4'];

 //        $freezing_container_5 = $_POST['freezing_container_5'];

 //        $freezing_straw_1 = $_POST['freezing_straw_1'];

 //        $freezing_straw_2 = $_POST['freezing_straw_2'];

 //        $freezing_straw_3 = $_POST['freezing_straw_3'];

 //        $freezing_straw_4 = $_POST['freezing_straw_4'];

 //        $freezing_straw_5 = $_POST['freezing_straw_5'];

 //        $freezing_color_1 = $_POST['freezing_color_1'];

 //        $freezing_color_2 = $_POST['freezing_color_2'];

 //        $freezing_color_3 = $_POST['freezing_color_3'];

 //        $freezing_color_4 = $_POST['freezing_color_4'];

 //        $freezing_color_5 = $_POST['freezing_color_5'];

 //        $freezing_oocytes_1 = $_POST['freezing_oocytes_1'];

 //        $freezing_oocytes_2 = $_POST['freezing_oocytes_2'];

 //        $freezing_oocytes_3 = $_POST['freezing_oocytes_3'];

 //        $freezing_oocytes_4 = $_POST['freezing_oocytes_4'];

 //        $freezing_oocytes_5 = $_POST['freezing_oocytes_5'];

 //        $storage_renewal_date_1 = $_POST['storage_renewal_date_1'];

 //        $storage_renewal_date_2 = $_POST['storage_renewal_date_2'];

 //        $storage_renewal_date_3 = $_POST['storage_renewal_date_3'];

 //        $storage_renewal_date_4 = $_POST['storage_renewal_date_4'];

 //        $storage_renewal_date_5 = $_POST['storage_renewal_date_5'];

 //        $thawing_date_1 = $_POST['thawing_date_1'];

 //        $thawing_date_2 = $_POST['thawing_date_2'];

 //        $thawing_date_3 = $_POST['thawing_date_3'];

 //        $thawing_date_4 = $_POST['thawing_date_4'];

 //        $thawing_date_5 = $_POST['thawing_date_5'];

 //        $thawing_purpose_1 = $_POST['thawing_purpose_1'];

 //        $thawing_purpose_2 = $_POST['thawing_purpose_2'];

 //        $thawing_purpose_3 = $_POST['thawing_purpose_3'];

 //        $thawing_purpose_4 = $_POST['thawing_purpose_4'];

 //        $thawing_purpose_5 = $_POST['thawing_purpose_5'];

 //        $thawing_egg_thawed_1 = $_POST['thawing_egg_thawed_1'];

 //        $thawing_egg_thawed_2 = $_POST['thawing_egg_thawed_2'];

 //        $thawing_egg_thawed_3 = $_POST['thawing_egg_thawed_3'];

 //        $thawing_egg_thawed_4 = $_POST['thawing_egg_thawed_4'];

 //        $thawing_egg_thawed_5 = $_POST['thawing_egg_thawed_5'];

 //        $thawing_egg_recovered_1 = $_POST['thawing_egg_recovered_1'];

 //        $thawing_egg_recovered_2 = $_POST['thawing_egg_recovered_2'];

 //        $thawing_egg_recovered_3 = $_POST['thawing_egg_recovered_3'];

 //        $thawing_egg_recovered_4 = $_POST['thawing_egg_recovered_4'];

 //        $thawing_egg_recovered_5 = $_POST['thawing_egg_recovered_5'];

 //        $thawing_path_1 = $_POST['thawing_path_1'];

 //        $thawing_path_2 = $_POST['thawing_path_2'];

 //        $thawing_path_3 = $_POST['thawing_path_3'];

 //        $thawing_path_4 = $_POST['thawing_path_4'];

 //        $thawing_path_5 = $_POST['thawing_path_5'];

 //        $discarding_date_1 = $_POST['discarding_date_1'];

 //        $discarding_date_2 = $_POST['discarding_date_2'];

 //        $discarding_date_3 = $_POST['discarding_date_3'];

 //        $discarding_date_4 = $_POST['discarding_date_4'];

 //        $discarding_date_5 = $_POST['discarding_date_5'];

 //        $discarding_purpose_1 = $_POST['discarding_purpose_1'];

 //        $discarding_purpose_2 = $_POST['discarding_purpose_2'];

 //        $discarding_purpose_3 = $_POST['discarding_purpose_3'];

 //        $discarding_purpose_4 = $_POST['discarding_purpose_4'];

 //        $discarding_purpose_5 = $_POST['discarding_purpose_5'];

 //        $remarks_1 = $_POST['remarks_1'];

 //        $remarks_2 = $_POST['remarks_2'];

 //        $remarks_3 = $_POST['remarks_3'];

 //        $remarks_4 = $_POST['remarks_4'];

 //        $remarks_5 = $_POST['remarks_5'];

 //        $embryologist_witnessed_1 = $_POST['embryologist_witnessed_1'];

 //        $embryologist_witnessed_2 = $_POST['embryologist_witnessed_2'];

 //        $embryologist_witnessed_3 = $_POST['embryologist_witnessed_3'];

 //        $embryologist_witnessed_4 = $_POST['embryologist_witnessed_4'];

 //        $embryologist_witnessed_5 = $_POST['embryologist_witnessed_5'];

 //        $doctors_witnessed_1 = $_POST['doctors_witnessed_1'];

 //        $doctors_witnessed_2 = $_POST['doctors_witnessed_2'];

 //        $doctors_witnessed_3 = $_POST['doctors_witnessed_3'];

 //        $doctors_witnessed_4 = $_POST['doctors_witnessed_4'];

 //        $doctors_witnessed_5 = $_POST['doctors_witnessed_5'];

 //        $date_6 = $_POST['date_6'];

 //        $coc_retreived_6 = $_POST['coc_retreived_6'];

 //        $oocytes_retreived_no_6 = $_POST['oocytes_retreived_no_6'];

 //        $oocytes_retreived_photo_6 = $_POST['oocytes_retreived_photo_6'];

 //        $m2_6 = $_POST['m2_6'];

 //        $m1_6 = $_POST['m1_6'];

 //        $gv_6 = $_POST['gv_6'];

 //        $tubes_dish_6 = $_POST['tubes_dish_6'];

 //        $eggs_transferred_6 = $_POST['eggs_transferred_6'];

 //        $freezing_date_6 = $_POST['freezing_date_6'];

 //        $freezing_media_6 = $_POST['freezing_media_6'];

 //        $freezing_container_6 = $_POST['freezing_container_6'];

 //        $freezing_straw_6 = $_POST['freezing_straw_6'];

 //        $freezing_color_6 = $_POST['freezing_color_6'];

 //        $freezing_oocytes_6 = $_POST['freezing_oocytes_6'];

 //        $storage_renewal_date_6 = $_POST['storage_renewal_date_6'];

 //        $thawing_date_6 = $_POST['thawing_date_6'];

 //        $thawing_purpose_6 = $_POST['thawing_purpose_6'];

 //        $thawing_egg_thawed_6 = $_POST['thawing_egg_thawed_6'];

 //        $thawing_egg_recovered_6 = $_POST['thawing_egg_recovered_6'];

 //        $thawing_path_6 = $_POST['thawing_path_6'];

 //        $discarding_date_6 = $_POST['discarding_date_6'];

 //        $discarding_purpose_6 = $_POST['discarding_purpose_6'];

 //        $remarks_6 = $_POST['remarks_6'];

 //        $embryologist_witnessed_6 = $_POST['embryologist_witnessed_6'];

 //        $doctors_witnessed_6 = $_POST['doctors_witnessed_6'];

 //        $date_7 = $_POST['date_7'];

 //        $coc_retreived_7 = $_POST['coc_retreived_7'];

 //        $oocytes_retreived_no_7 = $_POST['oocytes_retreived_no_7'];

 //        $oocytes_retreived_photo_7 = $_POST['oocytes_retreived_photo_7'];

 //        $m2_7 = $_POST['m2_7'];

 //        $m1_7 = $_POST['m1_7'];

 //        $gv_7 = $_POST['gv_7'];

 //        $tubes_dish_7 = $_POST['tubes_dish_7'];

 //        $eggs_transferred_7 = $_POST['eggs_transferred_7'];

 //        $freezing_date_7 = $_POST['freezing_date_7'];

 //        $freezing_media_7 = $_POST['freezing_media_7'];

 //        $freezing_container_7 = $_POST['freezing_container_7'];

 //        $freezing_straw_7 = $_POST['freezing_straw_7'];

 //        $freezing_color_7 = $_POST['freezing_color_7'];

 //        $freezing_oocytes_7 = $_POST['freezing_oocytes_7'];

 //        $storage_renewal_date_7 = $_POST['storage_renewal_date_7'];

 //        $thawing_date_7 = $_POST['thawing_date_7'];

 //        $thawing_purpose_7 = $_POST['thawing_purpose_7'];

 //        $thawing_egg_thawed_7 = $_POST['thawing_egg_thawed_7'];

 //        $thawing_egg_recovered_7 = $_POST['thawing_egg_recovered_7'];

 //        $thawing_path_7 = $_POST['thawing_path_7'];

 //        $discarding_date_7 = $_POST['discarding_date_7'];

 //        $discarding_purpose_7 = $_POST['discarding_purpose_7'];

 //        $remarks_7 = $_POST['remarks_7'];

 //        $embryologist_witnessed_7 = $_POST['embryologist_witnessed_7'];

 //        $doctors_witnessed_7 = $_POST['doctors_witnessed_7'];

 //        $date_8 = $_POST['date_8'];

 //        $coc_retreived_8 = $_POST['coc_retreived_8'];

 //        $oocytes_retreived_no_8 = $_POST['oocytes_retreived_no_8'];

 //        $oocytes_retreived_photo_8 = $_POST['oocytes_retreived_photo_8'];

 //        $m2_8 = $_POST['m2_8'];

 //        $m1_8 = $_POST['m1_8'];

 //        $gv_8 = $_POST['gv_8'];

 //        $tubes_dish_8 = $_POST['tubes_dish_8'];

 //        $eggs_transferred_8 = $_POST['eggs_transferred_8'];

 //        $freezing_date_8 = $_POST['freezing_date_8'];

 //        $freezing_media_8 = $_POST['freezing_media_8'];

 //        $freezing_container_8 = $_POST['freezing_container_8'];

 //        $freezing_straw_8 = $_POST['freezing_straw_8'];

 //        $freezing_color_8 = $_POST['freezing_color_8'];

 //        $freezing_oocytes_8 = $_POST['freezing_oocytes_8'];

 //        $storage_renewal_date_8 = $_POST['storage_renewal_date_8'];

 //        $thawing_date_8 = $_POST['thawing_date_8'];

 //        $thawing_purpose_8 = $_POST['thawing_purpose_8'];

 //        $thawing_egg_thawed_8 = $_POST['thawing_egg_thawed_8'];

 //        $thawing_egg_recovered_8 = $_POST['thawing_egg_recovered_8'];

 //        $thawing_path_8 = $_POST['thawing_path_8'];

 //        $discarding_date_8 = $_POST['discarding_date_8'];

 //        $discarding_purpose_8 = $_POST['discarding_purpose_8'];

 //        $remarks_8 = $_POST['remarks_8'];

 //        $embryologist_witnessed_8 = $_POST['embryologist_witnessed_8'];

 //        $doctors_witnessed_8 = $_POST['doctors_witnessed_8'];

 //        $date_9 = $_POST['date_9'];

 //        $coc_retreived_9 = $_POST['coc_retreived_9'];

 //        $oocytes_retreived_no_9 = $_POST['oocytes_retreived_no_9'];

 //        $oocytes_retreived_photo_9 = $_POST['oocytes_retreived_photo_9'];

 //        $m2_9 = $_POST['m2_9'];

 //        $m1_9 = $_POST['m1_9'];

 //        $gv_9 = $_POST['gv_9'];

 //        $tubes_dish_9 = $_POST['tubes_dish_9'];

 //        $eggs_transferred_9 = $_POST['eggs_transferred_9'];

 //        $freezing_date_9 = $_POST['freezing_date_9'];

 //        $freezing_media_9 = $_POST['freezing_media_9'];

 //        $freezing_container_9 = $_POST['freezing_container_9'];

 //        $freezing_straw_9 = $_POST['freezing_straw_9'];

 //        $freezing_color_9 = $_POST['freezing_color_9'];

 //        $freezing_oocytes_9 = $_POST['freezing_oocytes_9'];

 //        $storage_renewal_date_9 = $_POST['storage_renewal_date_9'];

 //        $thawing_date_9 = $_POST['thawing_date_9'];

 //        $thawing_purpose_9 = $_POST['thawing_purpose_9'];

 //        $thawing_egg_thawed_9 = $_POST['thawing_egg_thawed_9'];

 //        $thawing_egg_recovered_9 = $_POST['thawing_egg_recovered_9'];

 //        $thawing_path_9 = $_POST['thawing_path_9'];

 //        $discarding_date_9 = $_POST['discarding_date_9'];

 //        $discarding_purpose_9 = $_POST['discarding_purpose_9'];

 //        $remarks_9 = $_POST['remarks_9'];

 //        $embryologist_witnessed_9 = $_POST['embryologist_witnessed_9'];

 //        $doctors_witnessed_9 = $_POST['doctors_witnessed_9'];

 //        $date_10 = $_POST['date_10'];

 //        $coc_retreived_10 = $_POST['coc_retreived_10'];

 //        $oocytes_retreived_no_10 = $_POST['oocytes_retreived_no_10'];

 //        $oocytes_retreived_photo_10 = $_POST['oocytes_retreived_photo_10'];

 //        $m2_10 = $_POST['m2_10'];

 //        $m1_10 = $_POST['m1_10'];

 //        $gv_10 = $_POST['gv_10'];

 //        $tubes_dish_10 = $_POST['tubes_dish_10'];

 //        $eggs_transferred_10 = $_POST['eggs_transferred_10'];

 //        $freezing_date_10 = $_POST['freezing_date_10'];

 //        $freezing_media_10 = $_POST['freezing_media_10'];

 //        $freezing_container_10 = $_POST['freezing_container_10'];

 //        $freezing_straw_10 = $_POST['freezing_straw_10'];

 //        $freezing_color_10 = $_POST['freezing_color_10'];

 //        $freezing_oocytes_10 = $_POST['freezing_oocytes_10'];

 //        $storage_renewal_date_10 = $_POST['storage_renewal_date_10'];

 //        $thawing_date_10 = $_POST['thawing_date_10'];

 //        $thawing_purpose_10 = $_POST['thawing_purpose_10'];

 //        $thawing_egg_thawed_10 = $_POST['thawing_egg_thawed_10'];

 //        $thawing_egg_recovered_10 = $_POST['thawing_egg_recovered_10'];

 //        $thawing_path_10 = $_POST['thawing_path_10'];

 //        $discarding_date_10 = $_POST['discarding_date_10'];

 //        $discarding_purpose_10 = $_POST['discarding_purpose_10'];

 //        $remarks_10 = $_POST['remarks_10'];

 //        $embryologist_witnessed_10 = $_POST['embryologist_witnessed_10'];

 //        $doctors_witnessed_10 = $_POST['doctors_witnessed_10'];

 //        $date_11 = $_POST['date_11'];

 //        $coc_retreived_11 = $_POST['coc_retreived_11'];

 //        $oocytes_retreived_no_11 = $_POST['oocytes_retreived_no_11'];

 //        $oocytes_retreived_photo_11 = $_POST['oocytes_retreived_photo_11'];

 //        $m2_11 = $_POST['m2_11'];

 //        $m1_11 = $_POST['m1_11'];

 //        $gv_11 = $_POST['gv_11'];

 //        $tubes_dish_11 = $_POST['tubes_dish_11'];

 //        $eggs_transferred_11 = $_POST['eggs_transferred_11'];

 //        $freezing_date_11 = $_POST['freezing_date_11'];

 //        $freezing_media_11 = $_POST['freezing_media_11'];

 //        $freezing_container_11 = $_POST['freezing_container_11'];

 //        $freezing_straw_11 = $_POST['freezing_straw_11'];

 //        $freezing_color_11 = $_POST['freezing_color_11'];

 //        $freezing_oocytes_11 = $_POST['freezing_oocytes_11'];

 //        $storage_renewal_date_11 = $_POST['storage_renewal_date_11'];

 //        $thawing_date_11 = $_POST['thawing_date_11'];

 //        $thawing_purpose_11 = $_POST['thawing_purpose_11'];

 //        $thawing_egg_thawed_11 = $_POST['thawing_egg_thawed_11'];

 //        $thawing_egg_recovered_11 = $_POST['thawing_egg_recovered_11'];

 //        $thawing_path_11 = $_POST['thawing_path_11'];

 //        $discarding_date_11 = $_POST['discarding_date_11'];

 //        $discarding_purpose_11 = $_POST['discarding_purpose_11'];

 //        $remarks_11 = $_POST['remarks_11'];

 //        $embryologist_witnessed_11 = $_POST['embryologist_witnessed_11'];

 //        $doctors_witnessed_11 = $_POST['doctors_witnessed_11'];

 //        $date_12 = $_POST['date_12'];

 //        $coc_retreived_12 = $_POST['coc_retreived_12'];

 //        $oocytes_retreived_no_12 = $_POST['oocytes_retreived_no_12'];

 //        $oocytes_retreived_photo_12 = $_POST['oocytes_retreived_photo_12'];

 //        $m2_12 = $_POST['m2_12'];

 //        $m1_12 = $_POST['m1_12'];

 //        $gv_12 = $_POST['gv_12'];

 //        $tubes_dish_12 = $_POST['tubes_dish_12'];

 //        $eggs_transferred_12 = $_POST['eggs_transferred_12'];

 //        $freezing_date_12 = $_POST['freezing_date_12'];

 //        $freezing_media_12 = $_POST['freezing_media_12'];

 //        $freezing_container_12 = $_POST['freezing_container_12'];

 //        $freezing_straw_12 = $_POST['freezing_straw_12'];

 //        $freezing_color_12 = $_POST['freezing_color_12'];

 //        $freezing_oocytes_12 = $_POST['freezing_oocytes_12'];

 //        $storage_renewal_date_12 = $_POST['storage_renewal_date_12'];

 //        $thawing_date_12 = $_POST['thawing_date_12'];

 //        $thawing_purpose_12 = $_POST['thawing_purpose_12'];

 //        $thawing_egg_thawed_12 = $_POST['thawing_egg_thawed_12'];

 //        $thawing_egg_recovered_12 = $_POST['thawing_egg_recovered_12'];

 //        $thawing_path_12 = $_POST['thawing_path_12'];

 //        $discarding_date_12 = $_POST['discarding_date_12'];

 //        $discarding_purpose_12 = $_POST['discarding_purpose_12'];

 //        $remarks_12 = $_POST['remarks_12'];

 //        $embryologist_witnessed_12 = $_POST['embryologist_witnessed_12'];

 //        $doctors_witnessed_12 = $_POST['doctors_witnessed_12'];

 //        $date_13 = $_POST['date_13'];

 //        $coc_retreived_13 = $_POST['coc_retreived_13'];

 //        $oocytes_retreived_no_13 = $_POST['oocytes_retreived_no_13'];

 //        $oocytes_retreived_photo_13 = $_POST['oocytes_retreived_photo_13'];

 //        $m2_13 = $_POST['m2_13'];

 //        $m1_13 = $_POST['m1_13'];

 //        $gv_13 = $_POST['gv_13'];

 //        $tubes_dish_13 = $_POST['tubes_dish_13'];

 //        $eggs_transferred_13 = $_POST['eggs_transferred_13'];

 //        $freezing_date_13 = $_POST['freezing_date_13'];

 //        $freezing_media_13 = $_POST['freezing_media_13'];

 //        $freezing_container_13 = $_POST['freezing_container_13'];

 //        $freezing_straw_13 = $_POST['freezing_straw_13'];

 //        $freezing_color_13 = $_POST['freezing_color_13'];

 //        $freezing_oocytes_13 = $_POST['freezing_oocytes_13'];

 //        $storage_renewal_date_13 = $_POST['storage_renewal_date_13'];

 //        $thawing_date_13 = $_POST['thawing_date_13'];

 //        $thawing_purpose_13 = $_POST['thawing_purpose_13'];

 //        $thawing_egg_thawed_13 = $_POST['thawing_egg_thawed_13'];

 //        $thawing_egg_recovered_13 = $_POST['thawing_egg_recovered_13'];

 //        $thawing_path_13 = $_POST['thawing_path_13'];

 //        $discarding_date_13 = $_POST['discarding_date_13'];

 //        $discarding_purpose_13 = $_POST['discarding_purpose_13'];

 //        $remarks_13 = $_POST['remarks_13'];

 //        $embryologist_witnessed_13 = $_POST['embryologist_witnessed_13'];

 //        $doctors_witnessed_13 = $_POST['doctors_witnessed_13'];

 //        $date_14 = $_POST['date_14'];

 //        $coc_retreived_14 = $_POST['coc_retreived_14'];

 //        $oocytes_retreived_no_14 = $_POST['oocytes_retreived_no_14'];

 //        $oocytes_retreived_photo_14 = $_POST['oocytes_retreived_photo_14'];

 //        $m2_14 = $_POST['m2_14'];

 //        $m1_14 = $_POST['m1_14'];

 //        $gv_14 = $_POST['gv_14'];

 //        $tubes_dish_14 = $_POST['tubes_dish_14'];

 //        $eggs_transferred_14 = $_POST['eggs_transferred_14'];

 //        $freezing_date_14 = $_POST['freezing_date_14'];

 //        $freezing_media_14 = $_POST['freezing_media_14'];

 //        $freezing_container_14 = $_POST['freezing_container_14'];

 //        $freezing_straw_14 = $_POST['freezing_straw_14'];

 //        $freezing_color_14 = $_POST['freezing_color_14'];

 //        $freezing_oocytes_14 = $_POST['freezing_oocytes_14'];

 //        $storage_renewal_date_14 = $_POST['storage_renewal_date_14'];

 //        $thawing_date_14 = $_POST['thawing_date_14'];

 //        $thawing_purpose_14 = $_POST['thawing_purpose_14'];

 //        $thawing_egg_thawed_14 = $_POST['thawing_egg_thawed_14'];

 //        $thawing_egg_recovered_14 = $_POST['thawing_egg_recovered_14'];

 //        $thawing_path_14 = $_POST['thawing_path_14'];

 //        $discarding_date_14 = $_POST['discarding_date_14'];

 //        $discarding_purpose_14 = $_POST['discarding_purpose_14'];

 //        $remarks_14 = $_POST['remarks_14'];

 //        $embryologist_witnessed_14 = $_POST['embryologist_witnessed_14'];

 //        $doctors_witnessed_14 = $_POST['doctors_witnessed_14'];

 //        $date_15 = $_POST['date_15'];

 //        $coc_retreived_15 = $_POST['coc_retreived_15'];

 //        $oocytes_retreived_no_15 = $_POST['oocytes_retreived_no_15'];

 //        $oocytes_retreived_photo_15 = $_POST['oocytes_retreived_photo_15'];

 //        $m2_15 = $_POST['m2_15'];

 //        $m1_15 = $_POST['m1_15'];

 //        $gv_15 = $_POST['gv_15'];

 //        $tubes_dish_15 = $_POST['tubes_dish_15'];

 //        $eggs_transferred_15 = $_POST['eggs_transferred_15'];

 //        $freezing_date_15 = $_POST['freezing_date_15'];

 //        $freezing_media_15 = $_POST['freezing_media_15'];

 //        $freezing_container_15 = $_POST['freezing_container_15'];

 //        $freezing_straw_15 = $_POST['freezing_straw_15'];

 //        $freezing_color_15 = $_POST['freezing_color_15'];

 //        $freezing_oocytes_15 = $_POST['freezing_oocytes_15'];

 //        $storage_renewal_date_15 = $_POST['storage_renewal_date_15'];

 //        $thawing_date_15 = $_POST['thawing_date_15'];

 //        $thawing_purpose_15 = $_POST['thawing_purpose_15'];

 //        $thawing_egg_thawed_15 = $_POST['thawing_egg_thawed_15'];

 //        $thawing_egg_recovered_15 = $_POST['thawing_egg_recovered_15'];

 //        $thawing_path_15 = $_POST['thawing_path_15'];

 //        $discarding_date_15 = $_POST['discarding_date_15'];

 //        $discarding_purpose_15 = $_POST['discarding_purpose_15'];

 //        $remarks_15 = $_POST['remarks_15'];

 //        $embryologist_witnessed_15 = $_POST['embryologist_witnessed_15'];

 //        $doctors_witnessed_15 = $_POST['doctors_witnessed_15'];

 //        $date_16 = $_POST['date_16'];

 //        $coc_retreived_16 = $_POST['coc_retreived_16'];

 //        $oocytes_retreived_no_16 = $_POST['oocytes_retreived_no_16'];

 //        $oocytes_retreived_photo_16 = $_POST['oocytes_retreived_photo_16'];

 //        $m2_16 = $_POST['m2_16'];

 //        $m1_16 = $_POST['m1_16'];

 //        $gv_16 = $_POST['gv_16'];

 //        $tubes_dish_16 = $_POST['tubes_dish_16'];

 //        $eggs_transferred_16 = $_POST['eggs_transferred_16'];

 //        $freezing_date_16 = $_POST['freezing_date_16'];

 //        $freezing_media_16 = $_POST['freezing_media_16'];

 //        $freezing_container_16 = $_POST['freezing_container_16'];

 //        $freezing_straw_16 = $_POST['freezing_straw_16'];

 //        $freezing_color_16 = $_POST['freezing_color_16'];

 //        $freezing_oocytes_16 = $_POST['freezing_oocytes_16'];

 //        $storage_renewal_date_16 = $_POST['storage_renewal_date_16'];

 //        $thawing_date_16 = $_POST['thawing_date_16'];

 //        $thawing_purpose_16 = $_POST['thawing_purpose_16'];

 //        $thawing_egg_thawed_16 = $_POST['thawing_egg_thawed_16'];

 //        $thawing_egg_recovered_16 = $_POST['thawing_egg_recovered_16'];

 //        $thawing_path_16 = $_POST['thawing_path_16'];

 //        $discarding_date_16 = $_POST['discarding_date_16'];

 //        $discarding_purpose_16 = $_POST['discarding_purpose_16'];

 //        $remarks_16 = $_POST['remarks_16'];

 //        $embryologist_witnessed_16 = $_POST['embryologist_witnessed_16'];

 //        $doctors_witnessed_16 = $_POST['doctors_witnessed_16'];

 //        $date_17 = $_POST['date_17'];

 //        $coc_retreived_17 = $_POST['coc_retreived_17'];

 //        $oocytes_retreived_no_17 = $_POST['oocytes_retreived_no_17'];

 //        $oocytes_retreived_photo_17 = $_POST['oocytes_retreived_photo_17'];

 //        $m2_17 = $_POST['m2_17'];

 //        $m1_17 = $_POST['m1_17'];

 //        $gv_17 = $_POST['gv_17'];

 //        $tubes_dish_17 = $_POST['tubes_dish_17'];

 //        $eggs_transferred_17 = $_POST['eggs_transferred_17'];

 //        $freezing_date_17 = $_POST['freezing_date_17'];

 //        $freezing_media_17 = $_POST['freezing_media_17'];

 //        $freezing_container_17 = $_POST['freezing_container_17'];

 //        $freezing_straw_17 = $_POST['freezing_straw_17'];

 //        $freezing_color_17 = $_POST['freezing_color_17'];

 //        $freezing_oocytes_17 = $_POST['freezing_oocytes_17'];

 //        $storage_renewal_date_17 = $_POST['storage_renewal_date_17'];

 //        $thawing_date_17 = $_POST['thawing_date_17'];

 //        $thawing_purpose_17 = $_POST['thawing_purpose_17'];

 //        $thawing_egg_thawed_17 = $_POST['thawing_egg_thawed_17'];

 //        $thawing_egg_recovered_17 = $_POST['thawing_egg_recovered_17'];

 //        $thawing_path_17 = $_POST['thawing_path_17'];

 //        $discarding_date_17 = $_POST['discarding_date_17'];

 //        $discarding_purpose_17 = $_POST['discarding_purpose_17'];

 //        $remarks_17 = $_POST['remarks_17'];

 //        $embryologist_witnessed_17 = $_POST['embryologist_witnessed_17'];

 //        $doctors_witnessed_17 = $_POST['doctors_witnessed_17'];

 //        $date_18 = $_POST['date_18'];

 //        $coc_retreived_18 = $_POST['coc_retreived_18'];

 //        $oocytes_retreived_no_18 = $_POST['oocytes_retreived_no_18'];

 //        $oocytes_retreived_photo_18 = $_POST['oocytes_retreived_photo_18'];

 //        $m2_18 = $_POST['m2_18'];

 //        $m1_18 = $_POST['m1_18'];

 //        $gv_18 = $_POST['gv_18'];

 //        $tubes_dish_18 = $_POST['tubes_dish_18'];

 //        $eggs_transferred_18 = $_POST['eggs_transferred_18'];

 //        $freezing_date_18 = $_POST['freezing_date_18'];

 //        $freezing_media_18 = $_POST['freezing_media_18'];

 //        $freezing_container_18 = $_POST['freezing_container_18'];

 //        $freezing_straw_18 = $_POST['freezing_straw_18'];

 //        $freezing_color_18 = $_POST['freezing_color_18'];

 //        $freezing_oocytes_18 = $_POST['freezing_oocytes_18'];

 //        $storage_renewal_date_18 = $_POST['storage_renewal_date_18'];

 //        $thawing_date_18 = $_POST['thawing_date_18'];

 //        $thawing_purpose_18 = $_POST['thawing_purpose_18'];

 //        $thawing_egg_thawed_18 = $_POST['thawing_egg_thawed_18'];

 //        $thawing_egg_recovered_18 = $_POST['thawing_egg_recovered_18'];

 //        $thawing_path_18 = $_POST['thawing_path_18'];

 //        $discarding_date_18 = $_POST['discarding_date_18'];

 //        $discarding_purpose_18 = $_POST['discarding_purpose_18'];

 //        $remarks_18 = $_POST['remarks_18'];

 //        $embryologist_witnessed_18 = $_POST['embryologist_witnessed_18'];

 //        $doctors_witnessed_18 = $_POST['doctors_witnessed_18'];

 //        $date_19 = $_POST['date_19'];

 //        $coc_retreived_19 = $_POST['coc_retreived_19'];

 //        $oocytes_retreived_no_19 = $_POST['oocytes_retreived_no_19'];

 //        $oocytes_retreived_photo_19 = $_POST['oocytes_retreived_photo_19'];

 //        $m2_19 = $_POST['m2_19'];

 //        $m1_19 = $_POST['m1_19'];

 //        $gv_19 = $_POST['gv_19'];

 //        $tubes_dish_19 = $_POST['tubes_dish_19'];

 //        $eggs_transferred_19 = $_POST['eggs_transferred_19'];

 //        $freezing_date_19 = $_POST['freezing_date_19'];

 //        $freezing_media_19 = $_POST['freezing_media_19'];

 //        $freezing_container_19 = $_POST['freezing_container_19'];

 //        $freezing_straw_19 = $_POST['freezing_straw_19'];

 //        $freezing_color_19 = $_POST['freezing_color_19'];

 //        $freezing_oocytes_19 = $_POST['freezing_oocytes_19'];

 //        $storage_renewal_date_19 = $_POST['storage_renewal_date_19'];

 //        $thawing_date_19 = $_POST['thawing_date_19'];

 //        $thawing_purpose_19 = $_POST['thawing_purpose_19'];

 //        $thawing_egg_thawed_19 = $_POST['thawing_egg_thawed_19'];

 //        $thawing_egg_recovered_19 = $_POST['thawing_egg_recovered_19'];

 //        $thawing_path_19 = $_POST['thawing_path_19'];

 //        $discarding_date_19 = $_POST['discarding_date_19'];

 //        $discarding_purpose_19 = $_POST['discarding_purpose_19'];

 //        $remarks_19 = $_POST['remarks_19'];

 //        $embryologist_witnessed_19 = $_POST['embryologist_witnessed_19'];

 //        $doctors_witnessed_19 = $_POST['doctors_witnessed_19'];

 //        $date_20 = $_POST['date_20'];

 //        $coc_retreived_20 = $_POST['coc_retreived_20'];

 //        $oocytes_retreived_no_20 = $_POST['oocytes_retreived_no_20'];

 //        $oocytes_retreived_photo_20 = $_POST['oocytes_retreived_photo_20'];

 //        $m2_20 = $_POST['m2_20'];

 //        $m1_20 = $_POST['m1_20'];

 //        $gv_20 = $_POST['gv_20'];

 //        $tubes_dish_20 = $_POST['tubes_dish_20'];

 //        $eggs_transferred_20 = $_POST['eggs_transferred_20'];

 //        $freezing_date_20 = $_POST['freezing_date_20'];

 //        $freezing_media_20 = $_POST['freezing_media_20'];

 //        $freezing_container_20 = $_POST['freezing_container_20'];

 //        $freezing_straw_20 = $_POST['freezing_straw_20'];

 //        $freezing_color_20 = $_POST['freezing_color_20'];

 //        $freezing_oocytes_20 = $_POST['freezing_oocytes_20'];

 //        $storage_renewal_date_20 = $_POST['storage_renewal_date_20'];

 //        $thawing_date_20 = $_POST['thawing_date_20'];

 //        $thawing_purpose_20 = $_POST['thawing_purpose_20'];

 //        $thawing_egg_thawed_20 = $_POST['thawing_egg_thawed_20'];

 //        $thawing_egg_recovered_20 = $_POST['thawing_egg_recovered_20'];

 //        $thawing_path_20 = $_POST['thawing_path_20'];

 //        $discarding_date_20 = $_POST['discarding_date_20'];

 //        $discarding_purpose_20 = $_POST['discarding_purpose_20'];

 //        $remarks_20 = $_POST['remarks_20'];

 //        $embryologist_witnessed_20 = $_POST['embryologist_witnessed_20'];

 //        $doctors_witnessed_20 = $_POST['doctors_witnessed_20'];

 //        $date_21 = $_POST['date_21'];

 //        $coc_retreived_21 = $_POST['coc_retreived_21'];

 //        $oocytes_retreived_no_21 = $_POST['oocytes_retreived_no_21'];

 //        $oocytes_retreived_photo_21 = $_POST['oocytes_retreived_photo_21'];

 //        $m2_21 = $_POST['m2_21'];

 //        $m1_21 = $_POST['m1_21'];

 //        $gv_21 = $_POST['gv_21'];

 //        $tubes_dish_21 = $_POST['tubes_dish_21'];

 //        $eggs_transferred_21 = $_POST['eggs_transferred_21'];

 //        $freezing_date_21 = $_POST['freezing_date_21'];

 //        $freezing_media_21 = $_POST['freezing_media_21'];

 //        $freezing_container_21 = $_POST['freezing_container_21'];

 //        $freezing_straw_21 = $_POST['freezing_straw_21'];

 //        $freezing_color_21 = $_POST['freezing_color_21'];

 //        $freezing_oocytes_21 = $_POST['freezing_oocytes_21'];

 //        $storage_renewal_date_21 = $_POST['storage_renewal_date_21'];

 //        $thawing_date_21 = $_POST['thawing_date_21'];

 //        $thawing_purpose_21 = $_POST['thawing_purpose_21'];

 //        $thawing_egg_thawed_21 = $_POST['thawing_egg_thawed_21'];

 //        $thawing_egg_recovered_21 = $_POST['thawing_egg_recovered_21'];

 //        $thawing_path_21 = $_POST['thawing_path_21'];

 //        $discarding_date_21 = $_POST['discarding_date_21'];

 //        $discarding_purpose_21 = $_POST['discarding_purpose_21'];

 //        $remarks_21 = $_POST['remarks_21'];

 //        $embryologist_witnessed_21 = $_POST['embryologist_witnessed_21'];

 //        $doctors_witnessed_21 = $_POST['doctors_witnessed_21'];

 //        $date_22 = $_POST['date_22'];

 //        $coc_retreived_22 = $_POST['coc_retreived_22'];

 //        $oocytes_retreived_no_22 = $_POST['oocytes_retreived_no_22'];

 //        $oocytes_retreived_photo_22 = $_POST['oocytes_retreived_photo_22'];

 //        $m2_22 = $_POST['m2_22'];

 //        $m1_22 = $_POST['m1_22'];

 //        $gv_22 = $_POST['gv_22'];

 //        $tubes_dish_22 = $_POST['tubes_dish_22'];

 //        $eggs_transferred_22 = $_POST['eggs_transferred_22'];

 //        $freezing_date_22 = $_POST['freezing_date_22'];

 //        $freezing_media_22 = $_POST['freezing_media_22'];

 //        $freezing_container_22 = $_POST['freezing_container_22'];

 //        $freezing_straw_22 = $_POST['freezing_straw_22'];

 //        $freezing_color_22 = $_POST['freezing_color_22'];

 //        $freezing_oocytes_22 = $_POST['freezing_oocytes_22'];

 //        $storage_renewal_date_22 = $_POST['storage_renewal_date_22'];

 //        $thawing_date_22 = $_POST['thawing_date_22'];

 //        $thawing_purpose_22 = $_POST['thawing_purpose_22'];

 //        $thawing_egg_thawed_22 = $_POST['thawing_egg_thawed_22'];

 //        $thawing_egg_recovered_22 = $_POST['thawing_egg_recovered_22'];

 //        $thawing_path_22 = $_POST['thawing_path_22'];

 //        $discarding_date_22 = $_POST['discarding_date_22'];

 //        $discarding_purpose_22 = $_POST['discarding_purpose_22'];

 //        $remarks_22 = $_POST['remarks_22'];

 //        $embryologist_witnessed_22 = $_POST['embryologist_witnessed_22'];

 //        $doctors_witnessed_22 = $_POST['doctors_witnessed_22'];

 //        $date_23 = $_POST['date_23'];

 //        $coc_retreived_23 = $_POST['coc_retreived_23'];

 //        $oocytes_retreived_no_23 = $_POST['oocytes_retreived_no_23'];

 //        $oocytes_retreived_photo_23 = $_POST['oocytes_retreived_photo_23'];

 //        $m2_23 = $_POST['m2_23'];

 //        $m1_23 = $_POST['m1_23'];

 //        $gv_23 = $_POST['gv_23'];

 //        $tubes_dish_23 = $_POST['tubes_dish_23'];

 //        $eggs_transferred_23 = $_POST['eggs_transferred_23'];

 //        $freezing_date_23 = $_POST['freezing_date_23'];

 //        $freezing_media_23 = $_POST['freezing_media_23'];

 //        $freezing_container_23 = $_POST['freezing_container_23'];

 //        $freezing_straw_23 = $_POST['freezing_straw_23'];

 //        $freezing_color_23 = $_POST['freezing_color_23'];

 //        $freezing_oocytes_23 = $_POST['freezing_oocytes_23'];

 //        $storage_renewal_date_23 = $_POST['storage_renewal_date_23'];

 //        $thawing_date_23 = $_POST['thawing_date_23'];

 //        $thawing_purpose_23 = $_POST['thawing_purpose_23'];

 //        $thawing_egg_thawed_23 = $_POST['thawing_egg_thawed_23'];

 //        $thawing_egg_recovered_23 = $_POST['thawing_egg_recovered_23'];

 //        $thawing_path_23 = $_POST['thawing_path_23'];

 //        $discarding_date_23 = $_POST['discarding_date_23'];

 //        $discarding_purpose_23 = $_POST['discarding_purpose_23'];

 //        $remarks_23 = $_POST['remarks_23'];

 //        $embryologist_witnessed_23 = $_POST['embryologist_witnessed_23'];

 //        $doctors_witnessed_23 = $_POST['doctors_witnessed_23'];

 //        $date_24 = $_POST['date_24'];

 //        $coc_retreived_24 = $_POST['coc_retreived_24'];

 //        $oocytes_retreived_no_24 = $_POST['oocytes_retreived_no_24'];

 //        $oocytes_retreived_photo_24 = $_POST['oocytes_retreived_photo_24'];

 //        $m2_24 = $_POST['m2_24'];

 //        $m1_24 = $_POST['m1_24'];

 //        $gv_24 = $_POST['gv_24'];

 //        $tubes_dish_24 = $_POST['tubes_dish_24'];

 //        $eggs_transferred_24 = $_POST['eggs_transferred_24'];

 //        $freezing_date_24 = $_POST['freezing_date_24'];

 //        $freezing_media_24 = $_POST['freezing_media_24'];

 //        $freezing_container_24 = $_POST['freezing_container_24'];

 //        $freezing_straw_24 = $_POST['freezing_straw_24'];

 //        $freezing_color_24 = $_POST['freezing_color_24'];

 //        $freezing_oocytes_24 = $_POST['freezing_oocytes_24'];

 //        $storage_renewal_date_24 = $_POST['storage_renewal_date_24'];

 //        $thawing_date_24 = $_POST['thawing_date_24'];

 //        $thawing_purpose_24 = $_POST['thawing_purpose_24'];

 //        $thawing_egg_thawed_24 = $_POST['thawing_egg_thawed_24'];

 //        $thawing_egg_recovered_24 = $_POST['thawing_egg_recovered_24'];

 //        $thawing_path_24 = $_POST['thawing_path_24'];

 //        $discarding_date_24 = $_POST['discarding_date_24'];

 //        $discarding_purpose_24 = $_POST['discarding_purpose_24'];

 //        $remarks_24 = $_POST['remarks_24'];

 //        $embryologist_witnessed_24 = $_POST['embryologist_witnessed_24'];

 //        $doctors_witnessed_24 = $_POST['doctors_witnessed_24'];

 //        $date_25 = $_POST['date_25'];

 //        $coc_retreived_25 = $_POST['coc_retreived_25'];

 //        $oocytes_retreived_no_25 = $_POST['oocytes_retreived_no_25'];

 //        $oocytes_retreived_photo_25 = $_POST['oocytes_retreived_photo_25'];

 //        $m2_25 = $_POST['m2_25'];

 //        $m1_25 = $_POST['m1_25'];

 //        $gv_25 = $_POST['gv_25'];

 //        $tubes_dish_25 = $_POST['tubes_dish_25'];

 //        $eggs_transferred_25 = $_POST['eggs_transferred_25'];

 //        $freezing_date_25 = $_POST['freezing_date_25'];

 //        $freezing_media_25 = $_POST['freezing_media_25'];

 //        $freezing_container_25 = $_POST['freezing_container_25'];

 //        $freezing_straw_25 = $_POST['freezing_straw_25'];

 //        $freezing_color_25 = $_POST['freezing_color_25'];

 //        $freezing_oocytes_25 = $_POST['freezing_oocytes_25'];

 //        $storage_renewal_date_25 = $_POST['storage_renewal_date_25'];

 //        $thawing_date_25 = $_POST['thawing_date_25'];

 //        $thawing_purpose_25 = $_POST['thawing_purpose_25'];

 //        $thawing_egg_thawed_25 = $_POST['thawing_egg_thawed_25'];

 //        $thawing_egg_recovered_25 = $_POST['thawing_egg_recovered_25'];

 //        $thawing_path_25 = $_POST['thawing_path_25'];

 //        $discarding_date_25 = $_POST['discarding_date_25'];

 //        $discarding_purpose_25 = $_POST['discarding_purpose_25'];

 //        $remarks_25 = $_POST['remarks_25'];

 //        $embryologist_witnessed_25 = $_POST['embryologist_witnessed_25'];

 //        $doctors_witnessed_25 = $_POST['doctors_witnessed_25'];



	// 	// connect to mysql database using mysqli

		

	// 	// mysql query to insert data

	//$query = "INSERT INTO `opu`(`patient_id`, `receipt_number`, `status`,`partners_name`,`art_bank_reg_no`,`form_id`,`donor_d`,`upload`,`needle_used`,`completion_time`,`trigger_time`,`procdure_time`,`date_1`,`date_2`,`date_3`,`date_4`,`date_5`,`coc_retreived_1`,`coc_retreived_2`,`coc_retreived_3`,`coc_retreived_4`,`coc_retreived_5`,`oocytes_retreived_no_1`,`oocytes_retreived_no_2`,`oocytes_retreived_no_3`,`oocytes_retreived_no_4`,`oocytes_retreived_no_5`,`oocytes_retreived_photo_1`,`oocytes_retreived_photo_2`,`oocytes_retreived_photo_3`,`oocytes_retreived_photo_4`,`oocytes_retreived_photo_5`,`m2_1`,`m2_2`,`m2_3`,`m2_4`,`m2_5`,`m1_1`,`m1_2`,`m1_3`,`m1_4`,`m1_5`,`gv_1`,`gv_2`,`gv_3`,`gv_4`,`gv_5`,`tubes_dish_1`,`tubes_dish_2`,`tubes_dish_3`,`tubes_dish_4`,`tubes_dish_5`,`eggs_transferred_1`,`eggs_transferred_2`,`eggs_transferred_3`,`eggs_transferred_4`,`eggs_transferred_5`,`freezing_date_1`,`freezing_date_2`,`freezing_date_3`,`freezing_date_4`,`freezing_date_5`,`freezing_media_1`,`freezing_media_2`,`freezing_media_3`,`freezing_media_4`,`freezing_media_5`,`freezing_container_1`,`freezing_container_2`,`freezing_container_3`,`freezing_container_4`,`freezing_container_5`,`freezing_straw_1`,`freezing_straw_2`,`freezing_straw_3`,`freezing_straw_4`,`freezing_straw_5`,`freezing_color_1`,`freezing_color_2`,`freezing_color_3`,`freezing_color_4`,`freezing_color_5`,`freezing_oocytes_1`,`freezing_oocytes_2`,`freezing_oocytes_3`,`freezing_oocytes_4`,`freezing_oocytes_5`,`storage_renewal_date_1`,`storage_renewal_date_2`,`storage_renewal_date_3`,`storage_renewal_date_4`,`storage_renewal_date_5`,`thawing_date_1`,`thawing_date_2`,`thawing_date_3`,`thawing_date_4`,`thawing_date_5`,`thawing_purpose_1`,`thawing_purpose_2`,`thawing_purpose_3`,`thawing_purpose_4`,`thawing_purpose_5`,`thawing_egg_thawed_1`,`thawing_egg_thawed_2`,`thawing_egg_thawed_3`,`thawing_egg_thawed_4`,`thawing_egg_thawed_5`,`thawing_egg_recovered_1`,`thawing_egg_recovered_2`,`thawing_egg_recovered_3`,`thawing_egg_recovered_4`,`thawing_egg_recovered_5`,`thawing_path_1`,`thawing_path_2`,`thawing_path_3`,`thawing_path_4`,`thawing_path_5`,`discarding_date_1`,`discarding_date_2`,`discarding_date_3`,`discarding_date_4`,`discarding_date_5`,`discarding_purpose_1`,`discarding_purpose_2`,`discarding_purpose_3`,`discarding_purpose_4`,`discarding_purpose_5`,`remarks_1`,`remarks_2`,`remarks_3`,`remarks_4`,`remarks_5`,`embryologist_witnessed_1`,`embryologist_witnessed_2`,`embryologist_witnessed_3`,`embryologist_witnessed_4`,`embryologist_witnessed_5`,`doctors_witnessed_1`,`doctors_witnessed_2`,`doctors_witnessed_3`,`doctors_witnessed_4`,`doctors_witnessed_5`,`date_6`,`coc_retreived_6`,`oocytes_retreived_no_6`,`oocytes_retreived_photo_6`,`m2_6`,`m1_6`,`gv_6`,`tubes_dish_6`,`eggs_transferred_6`,`freezing_date_6`,`freezing_media_6`,`freezing_container_6`,`freezing_straw_6`,`freezing_color_6`,`freezing_oocytes_6`,`storage_renewal_date_6`,`thawing_date_6`,`thawing_purpose_6`,`thawing_egg_thawed_6`,`thawing_egg_recovered_6`,`thawing_path_6`,`discarding_date_6`,`discarding_purpose_6`,`remarks_6`,`embryologist_witnessed_6`,`doctors_witnessed_6`,`date_7`,`coc_retreived_7`,`oocytes_retreived_no_7`,`oocytes_retreived_photo_7`,`m2_7`,`m1_7`,`gv_7`,`tubes_dish_7`,`eggs_transferred_7`,`freezing_date_7`,`freezing_media_7`,`freezing_container_7`,`freezing_straw_7`,`freezing_color_7`,`freezing_oocytes_7`,`storage_renewal_date_7`,`thawing_date_7`,`thawing_purpose_7`,`thawing_egg_thawed_7`,`thawing_egg_recovered_7`,`thawing_path_7`,`discarding_date_7`,`discarding_purpose_7`,`remarks_7`,`embryologist_witnessed_7`,`doctors_witnessed_7`,`date_8`,`coc_retreived_8`,`oocytes_retreived_no_8`,`oocytes_retreived_photo_8`,`m2_8`,`m1_8`,`gv_8`,`tubes_dish_8`,`eggs_transferred_8`,`freezing_date_8`,`freezing_media_8`,`freezing_container_8`,`freezing_straw_8`,`freezing_color_8`,`freezing_oocytes_8`,`storage_renewal_date_8`,`thawing_date_8`,`thawing_purpose_8`,`thawing_egg_thawed_8`,`thawing_egg_recovered_8`,`thawing_path_8`,`discarding_date_8`,`discarding_purpose_8`,`remarks_8`,`embryologist_witnessed_8`,`doctors_witnessed_8`,`date_9`,`coc_retreived_9`,`oocytes_retreived_no_9`,`oocytes_retreived_photo_9`,`m2_9`,`m1_9`,`gv_9`,`tubes_dish_9`,`eggs_transferred_9`,`freezing_date_9`,`freezing_media_9`,`freezing_container_9`,`freezing_straw_9`,`freezing_color_9`,`freezing_oocytes_9`,`storage_renewal_date_9`,`thawing_date_9`,`thawing_purpose_9`,`thawing_egg_thawed_9`,`thawing_egg_recovered_9`,`thawing_path_9`,`discarding_date_9`,`discarding_purpose_9`,`remarks_9`,`embryologist_witnessed_9`,`doctors_witnessed_9`,`date_10`,`coc_retreived_10`,`oocytes_retreived_no_10`,`oocytes_retreived_photo_10`,`m2_10`,`m1_10`,`gv_10`,`tubes_dish_10`,`eggs_transferred_10`,`freezing_date_10`,`freezing_media_10`,`freezing_container_10`,`freezing_straw_10`,`freezing_color_10`,`freezing_oocytes_10`,`storage_renewal_date_10`,`thawing_date_10`,`thawing_purpose_10`,`thawing_egg_thawed_10`,`thawing_egg_recovered_10`,`thawing_path_10`,`discarding_date_10`,`discarding_purpose_10`,`remarks_10`,`embryologist_witnessed_10`,`doctors_witnessed_10`,`date_11`,`coc_retreived_11`,`oocytes_retreived_no_11`,`oocytes_retreived_photo_11`,`m2_11`,`m1_11`,`gv_11`,`tubes_dish_11`,`eggs_transferred_11`,`freezing_date_11`,`freezing_media_11`,`freezing_container_11`,`freezing_straw_11`,`freezing_color_11`,`freezing_oocytes_11`,`storage_renewal_date_11`,`thawing_date_11`,`thawing_purpose_11`,`thawing_egg_thawed_11`,`thawing_egg_recovered_11`,`thawing_path_11`,`discarding_date_11`,`discarding_purpose_11`,`remarks_11`,`embryologist_witnessed_11`,`doctors_witnessed_11`,`date_12`,`coc_retreived_12`,`oocytes_retreived_no_12`,`oocytes_retreived_photo_12`,`m2_12`,`m1_12`,`gv_12`,`tubes_dish_12`,`eggs_transferred_12`,`freezing_date_12`,`freezing_media_12`,`freezing_container_12`,`freezing_straw_12`,`freezing_color_12`,`freezing_oocytes_12`,`storage_renewal_date_12`,`thawing_date_12`,`thawing_purpose_12`,`thawing_egg_thawed_12`,`thawing_egg_recovered_12`,`thawing_path_12`,`discarding_date_12`,`discarding_purpose_12`,`remarks_12`,`embryologist_witnessed_12`,`doctors_witnessed_12`,`date_13`,`coc_retreived_13`,`oocytes_retreived_no_13`,`oocytes_retreived_photo_13`,`m2_13`,`m1_13`,`gv_13`,`tubes_dish_13`,`eggs_transferred_13`,`freezing_date_13`,`freezing_media_13`,`freezing_container_13`,`freezing_straw_13`,`freezing_color_13`,`freezing_oocytes_13`,`storage_renewal_date_13`,`thawing_date_13`,`thawing_purpose_13`,`thawing_egg_thawed_13`,`thawing_egg_recovered_13`,`thawing_path_13`,`discarding_date_13`,`discarding_purpose_13`,`remarks_13`,`embryologist_witnessed_13`,`doctors_witnessed_13`,`date_14`,`coc_retreived_14`,`oocytes_retreived_no_14`,`oocytes_retreived_photo_14`,`m2_14`,`m1_14`,`gv_14`,`tubes_dish_14`,`eggs_transferred_14`,`freezing_date_14`,`freezing_media_14`,`freezing_container_14`,`freezing_straw_14`,`freezing_color_14`,`freezing_oocytes_14`,`storage_renewal_date_14`,`thawing_date_14`,`thawing_purpose_14`,`thawing_egg_thawed_14`,`thawing_egg_recovered_14`,`thawing_path_14`,`discarding_date_14`,`discarding_purpose_14`,`remarks_14`,`embryologist_witnessed_14`,`doctors_witnessed_14`,`date_15`,`coc_retreived_15`,`oocytes_retreived_no_15`,`oocytes_retreived_photo_15`,`m2_15`,`m1_15`,`gv_15`,`tubes_dish_15`,`eggs_transferred_15`,`freezing_date_15`,`freezing_media_15`,`freezing_container_15`,`freezing_straw_15`,`freezing_color_15`,`freezing_oocytes_15`,`storage_renewal_date_15`,`thawing_date_15`,`thawing_purpose_15`,`thawing_egg_thawed_15`,`thawing_egg_recovered_15`,`thawing_path_15`,`discarding_date_15`,`discarding_purpose_15`,`remarks_15`,`embryologist_witnessed_15`,`doctors_witnessed_15`,`date_16`,`coc_retreived_16`,`oocytes_retreived_no_16`,`oocytes_retreived_photo_16`,`m2_16`,`m1_16`,`gv_16`,`tubes_dish_16`,`eggs_transferred_16`,`freezing_date_16`,`freezing_media_16`,`freezing_container_16`,`freezing_straw_16`,`freezing_color_16`,`freezing_oocytes_16`,`storage_renewal_date_16`,`thawing_date_16`,`thawing_purpose_16`,`thawing_egg_thawed_16`,`thawing_egg_recovered_16`,`thawing_path_16`,`discarding_date_16`,`discarding_purpose_16`,`remarks_16`,`embryologist_witnessed_16`,`doctors_witnessed_16`,`date_17`,`coc_retreived_17`,`oocytes_retreived_no_17`,`oocytes_retreived_photo_17`,`m2_17`,`m1_17`,`gv_17`,`tubes_dish_17`,`eggs_transferred_17`,`freezing_date_17`,`freezing_media_17`,`freezing_container_17`,`freezing_straw_17`,`freezing_color_17`,`freezing_oocytes_17`,`storage_renewal_date_17`,`thawing_date_17`,`thawing_purpose_17`,`thawing_egg_thawed_17`,`thawing_egg_recovered_17`,`thawing_path_17`,`discarding_date_17`,`discarding_purpose_17`,`remarks_17`,`embryologist_witnessed_17`,`doctors_witnessed_17`,`date_18`,`coc_retreived_18`,`oocytes_retreived_no_18`,`oocytes_retreived_photo_18`,`m2_18`,`m1_18`,`gv_18`,`tubes_dish_18`,`eggs_transferred_18`,`freezing_date_18`,`freezing_media_18`,`freezing_container_18`,`freezing_straw_18`,`freezing_color_18`,`freezing_oocytes_18`,`storage_renewal_date_18`,`thawing_date_18`,`thawing_purpose_18`,`thawing_egg_thawed_18`,`thawing_egg_recovered_18`,`thawing_path_18`,`discarding_date_18`,`discarding_purpose_18`,`remarks_18`,`embryologist_witnessed_18`,`doctors_witnessed_18`,`date_19`,`coc_retreived_19`,`oocytes_retreived_no_19`,`oocytes_retreived_photo_19`,`m2_19`,`m1_19`,`gv_19`,`tubes_dish_19`,`eggs_transferred_19`,`freezing_date_19`,`freezing_media_19`,`freezing_container_19`,`freezing_straw_19`,`freezing_color_19`,`freezing_oocytes_19`,`storage_renewal_date_19`,`thawing_date_19`,`thawing_purpose_19`,`thawing_egg_thawed_19`,`thawing_egg_recovered_19`,`thawing_path_19`,`discarding_date_19`,`discarding_purpose_19`,`remarks_19`,`embryologist_witnessed_19`,`doctors_witnessed_19`,`date_20`,`coc_retreived_20`,`oocytes_retreived_no_20`,`oocytes_retreived_photo_20`,`m2_20`,`m1_20`,`gv_20`,`tubes_dish_20`,`eggs_transferred_20`,`freezing_date_20`,`freezing_media_20`,`freezing_container_20`,`freezing_straw_20`,`freezing_color_20`,`freezing_oocytes_20`,`storage_renewal_date_20`,`thawing_date_20`,`thawing_purpose_20`,`thawing_egg_thawed_20`,`thawing_egg_recovered_20`,`thawing_path_20`,`discarding_date_20`,`discarding_purpose_20`,`remarks_20`,`embryologist_witnessed_20`,`doctors_witnessed_20`,`date_21`,`coc_retreived_21`,`oocytes_retreived_no_21`,`oocytes_retreived_photo_21`,`m2_21`,`m1_21`,`gv_21`,`tubes_dish_21`,`eggs_transferred_21`,`freezing_date_21`,`freezing_media_21`,`freezing_container_21`,`freezing_straw_21`,`freezing_color_21`,`freezing_oocytes_21`,`storage_renewal_date_21`,`thawing_date_21`,`thawing_purpose_21`,`thawing_egg_thawed_21`,`thawing_egg_recovered_21`,`thawing_path_21`,`discarding_date_21`,`discarding_purpose_21`,`remarks_21`,`embryologist_witnessed_21`,`doctors_witnessed_21`,`date_22`,`coc_retreived_22`,`oocytes_retreived_no_22`,`oocytes_retreived_photo_22`,`m2_22`,`m1_22`,`gv_22`,`tubes_dish_22`,`eggs_transferred_22`,`freezing_date_22`,`freezing_media_22`,`freezing_container_22`,`freezing_straw_22`,`freezing_color_22`,`freezing_oocytes_22`,`storage_renewal_date_22`,`thawing_date_22`,`thawing_purpose_22`,`thawing_egg_thawed_22`,`thawing_egg_recovered_22`,`thawing_path_22`,`discarding_date_22`,`discarding_purpose_22`,`remarks_22`,`embryologist_witnessed_22`,`doctors_witnessed_22`,`date_23`,`coc_retreived_23`,`oocytes_retreived_no_23`,`oocytes_retreived_photo_23`,`m2_23`,`m1_23`,`gv_23`,`tubes_dish_23`,`eggs_transferred_23`,`freezing_date_23`,`freezing_media_23`,`freezing_container_23`,`freezing_straw_23`,`freezing_color_23`,`freezing_oocytes_23`,`storage_renewal_date_23`,`thawing_date_23`,`thawing_purpose_23`,`thawing_egg_thawed_23`,`thawing_egg_recovered_23`,`thawing_path_23`,`discarding_date_23`,`discarding_purpose_23`,`remarks_23`,`embryologist_witnessed_23`,`doctors_witnessed_23`,`date_24`,`coc_retreived_24`,`oocytes_retreived_no_24`,`oocytes_retreived_photo_24`,`m2_24`,`m1_24`,`gv_24`,`tubes_dish_24`,`eggs_transferred_24`,`freezing_date_24`,`freezing_media_24`,`freezing_container_24`,`freezing_straw_24`,`freezing_color_24`,`freezing_oocytes_24`,`storage_renewal_date_24`,`thawing_date_24`,`thawing_purpose_24`,`thawing_egg_thawed_24`,`thawing_egg_recovered_24`,`thawing_path_24`,`discarding_date_24`,`discarding_purpose_24`,`remarks_24`,`embryologist_witnessed_24`,`doctors_witnessed_24`,`date_25`,`coc_retreived_25`,`oocytes_retreived_no_25`,`oocytes_retreived_photo_25`,`m2_25`,`m1_25`,`gv_25`,`tubes_dish_25`,`eggs_transferred_25`,`freezing_date_25`,`freezing_media_25`,`freezing_container_25`,`freezing_straw_25`,`freezing_color_25`,`freezing_oocytes_25`,`storage_renewal_date_25`,`thawing_date_25`,`thawing_purpose_25`,`thawing_egg_thawed_25`,`thawing_egg_recovered_25`,`thawing_path_25`,`discarding_date_25`,`discarding_purpose_25`,`remarks_25`,`embryologist_witnessed_25`,`doctors_witnessed_25`) VALUES ('$patient_id','$receipt_number','$status','$partners_name','$art_bank_reg_no','$form_id','$donor_d','$upload','$needle_used','$completion_time','$trigger_time','$procdure_time','$date_1','$date_2','$date_3','$date_4','$date_5','$coc_retreived_1','$coc_retreived_2','$coc_retreived_3','$coc_retreived_4','$coc_retreived_5','$oocytes_retreived_no_1','$oocytes_retreived_no_2','$oocytes_retreived_no_3','$oocytes_retreived_no_4','$oocytes_retreived_no_5','$oocytes_retreived_photo_1','$oocytes_retreived_photo_2','$oocytes_retreived_photo_3','$oocytes_retreived_photo_4','$oocytes_retreived_photo_5','$m2_1','$m2_2','$m2_3','$m2_4','$m2_5','$m1_1','$m1_2','$m1_3','$m1_4','$m1_5','$gv_1','$gv_2','$gv_3','$gv_4','$gv_5','$tubes_dish_1','$tubes_dish_2','$tubes_dish_3','$tubes_dish_4','$tubes_dish_5','$eggs_transferred_1','$eggs_transferred_2','$eggs_transferred_3','$eggs_transferred_4','$eggs_transferred_5','$freezing_date_1','$freezing_date_2','$freezing_date_3','$freezing_date_4','$freezing_date_5','$freezing_media_1','$freezing_media_2','$freezing_media_3','$freezing_media_4','$freezing_media_5','$freezing_container_1','$freezing_container_2','$freezing_container_3','$freezing_container_4','$freezing_container_5','$freezing_straw_1','$freezing_straw_2','$freezing_straw_3','$freezing_straw_4','$freezing_straw_5','$freezing_color_1','$freezing_color_2','$freezing_color_3','$freezing_color_4','$freezing_color_5','$freezing_oocytes_1','$freezing_oocytes_2','$freezing_oocytes_3','$freezing_oocytes_4','$freezing_oocytes_5','$storage_renewal_date_1','$storage_renewal_date_2','$storage_renewal_date_3','$storage_renewal_date_4','$storage_renewal_date_5','$thawing_date_1','$thawing_date_2','$thawing_date_3','$thawing_date_4','$thawing_date_5','$thawing_purpose_1','$thawing_purpose_2','$thawing_purpose_3','$thawing_purpose_4','$thawing_purpose_5','$thawing_egg_thawed_1','$thawing_egg_thawed_2','$thawing_egg_thawed_3','$thawing_egg_thawed_4','$thawing_egg_thawed_5','$thawing_egg_recovered_1','$thawing_egg_recovered_2','$thawing_egg_recovered_3','$thawing_egg_recovered_4','$thawing_egg_recovered_5','$thawing_path_1','$thawing_path_2','$thawing_path_3','$thawing_path_4','$thawing_path_5','$discarding_date_1','$discarding_date_2','$discarding_date_3','$discarding_date_4','$discarding_date_5','$discarding_purpose_1','$discarding_purpose_2','$discarding_purpose_3','$discarding_purpose_4','$discarding_purpose_5','$remarks_1','$remarks_2','$remarks_3','$remarks_4','$remarks_5','$embryologist_witnessed_1','$embryologist_witnessed_2','$embryologist_witnessed_3','$embryologist_witnessed_4','$embryologist_witnessed_5','$doctors_witnessed_1','$doctors_witnessed_2','$doctors_witnessed_3','$doctors_witnessed_4','$doctors_witnessed_5','$date_6','$coc_retreived_6','$oocytes_retreived_no_6','$oocytes_retreived_photo_6','$m2_6','$m1_6','$gv_6','$tubes_dish_6','$eggs_transferred_6','$freezing_date_6','$freezing_media_6','$freezing_container_6','$freezing_straw_6','$freezing_color_6','$freezing_oocytes_6','$storage_renewal_date_6','$thawing_date_6','$thawing_purpose_6','$thawing_egg_thawed_6','$thawing_egg_recovered_6','$thawing_path_6','$discarding_date_6','$discarding_purpose_6','$remarks_6','$embryologist_witnessed_6','$doctors_witnessed_6','$date_7','$coc_retreived_7','$oocytes_retreived_no_7','$oocytes_retreived_photo_7','$m2_7','$m1_7','$gv_7','$tubes_dish_7','$eggs_transferred_7','$freezing_date_7','$freezing_media_7','$freezing_container_7','$freezing_straw_7','$freezing_color_7','$freezing_oocytes_7','$storage_renewal_date_7','$thawing_date_7','$thawing_purpose_7','$thawing_egg_thawed_7','$thawing_egg_recovered_7','$thawing_path_7','$discarding_date_7','$discarding_purpose_7','$remarks_7','$embryologist_witnessed_7','$doctors_witnessed_7','$date_8','$coc_retreived_8','$oocytes_retreived_no_8','$oocytes_retreived_photo_8','$m2_8','$m1_8','$gv_8','$tubes_dish_8','$eggs_transferred_8','$freezing_date_8','$freezing_media_8','$freezing_container_8','$freezing_straw_8','$freezing_color_8','$freezing_oocytes_8','$storage_renewal_date_8','$thawing_date_8','$thawing_purpose_8','$thawing_egg_thawed_8','$thawing_egg_recovered_8','$thawing_path_8','$discarding_date_8','$discarding_purpose_8','$remarks_8','$embryologist_witnessed_8','$doctors_witnessed_8','$date_9','$coc_retreived_9','$oocytes_retreived_no_9','$oocytes_retreived_photo_9','$m2_9','$m1_9','$gv_9','$tubes_dish_9','$eggs_transferred_9','$freezing_date_9','$freezing_media_9','$freezing_container_9','$freezing_straw_9','$freezing_color_9','$freezing_oocytes_9','$storage_renewal_date_9','$thawing_date_9','$thawing_purpose_9','$thawing_egg_thawed_9','$thawing_egg_recovered_9','$thawing_path_9','$discarding_date_9','$discarding_purpose_9','$remarks_9','$embryologist_witnessed_9','$doctors_witnessed_9','$date_10','$coc_retreived_10','$oocytes_retreived_no_10','$oocytes_retreived_photo_10','$m2_10','$m1_10','$gv_10','$tubes_dish_10','$eggs_transferred_10','$freezing_date_10','$freezing_media_10','$freezing_container_10','$freezing_straw_10','$freezing_color_10','$freezing_oocytes_10','$storage_renewal_date_10','$thawing_date_10','$thawing_purpose_10','$thawing_egg_thawed_10','$thawing_egg_recovered_10','$thawing_path_10','$discarding_date_10','$discarding_purpose_10','$remarks_10','$embryologist_witnessed_10','$doctors_witnessed_10','$date_11','$coc_retreived_11','$oocytes_retreived_no_11','$oocytes_retreived_photo_11','$m2_11','$m1_11','$gv_11','$tubes_dish_11','$eggs_transferred_11','$freezing_date_11','$freezing_media_11','$freezing_container_11','$freezing_straw_11','$freezing_color_11','$freezing_oocytes_11','$storage_renewal_date_11','$thawing_date_11','$thawing_purpose_11','$thawing_egg_thawed_11','$thawing_egg_recovered_11','$thawing_path_11','$discarding_date_11','$discarding_purpose_11','$remarks_11','$embryologist_witnessed_11','$doctors_witnessed_11','$date_12','$coc_retreived_12','$oocytes_retreived_no_12','$oocytes_retreived_photo_12','$m2_12','$m1_12','$gv_12','$tubes_dish_12','$eggs_transferred_12','$freezing_date_12','$freezing_media_12','$freezing_container_12','$freezing_straw_12','$freezing_color_12','$freezing_oocytes_12','$storage_renewal_date_12','$thawing_date_12','$thawing_purpose_12','$thawing_egg_thawed_12','$thawing_egg_recovered_12','$thawing_path_12','$discarding_date_12','$discarding_purpose_12','$remarks_12','$embryologist_witnessed_12','$doctors_witnessed_12','$date_13','$coc_retreived_13','$oocytes_retreived_no_13','$oocytes_retreived_photo_13','$m2_13','$m1_13','$gv_13','$tubes_dish_13','$eggs_transferred_13','$freezing_date_13','$freezing_media_13','$freezing_container_13','$freezing_straw_13','$freezing_color_13','$freezing_oocytes_13','$storage_renewal_date_13','$thawing_date_13','$thawing_purpose_13','$thawing_egg_thawed_13','$thawing_egg_recovered_13','$thawing_path_13','$discarding_date_13','$discarding_purpose_13','$remarks_13','$embryologist_witnessed_13','$doctors_witnessed_13','$date_14','$coc_retreived_14','$oocytes_retreived_no_14','$oocytes_retreived_photo_14','$m2_14','$m1_14','$gv_14','$tubes_dish_14','$eggs_transferred_14','$freezing_date_14','$freezing_media_14','$freezing_container_14','$freezing_straw_14','$freezing_color_14','$freezing_oocytes_14','$storage_renewal_date_14','$thawing_date_14','$thawing_purpose_14','$thawing_egg_thawed_14','$thawing_egg_recovered_14','$thawing_path_14','$discarding_date_14','$discarding_purpose_14','$remarks_14','$embryologist_witnessed_14','$doctors_witnessed_14','$date_15','$coc_retreived_15','$oocytes_retreived_no_15','$oocytes_retreived_photo_15','$m2_15','$m1_15','$gv_15','$tubes_dish_15','$eggs_transferred_15','$freezing_date_15','$freezing_media_15','$freezing_container_15','$freezing_straw_15','$freezing_color_15','$freezing_oocytes_15','$storage_renewal_date_15','$thawing_date_15','$thawing_purpose_15','$thawing_egg_thawed_15','$thawing_egg_recovered_15','$thawing_path_15','$discarding_date_15','$discarding_purpose_15','$remarks_15','$embryologist_witnessed_15','$doctors_witnessed_15','$date_16','$coc_retreived_16','$oocytes_retreived_no_16','$oocytes_retreived_photo_16','$m2_16','$m1_16','$gv_16','$tubes_dish_16','$eggs_transferred_16','$freezing_date_16','$freezing_media_16','$freezing_container_16','$freezing_straw_16','$freezing_color_16','$freezing_oocytes_16','$storage_renewal_date_16','$thawing_date_16','$thawing_purpose_16','$thawing_egg_thawed_16','$thawing_egg_recovered_16','$thawing_path_16','$discarding_date_16','$discarding_purpose_16','$remarks_16','$embryologist_witnessed_16','$doctors_witnessed_16','$date_17','$coc_retreived_17','$oocytes_retreived_no_17','$oocytes_retreived_photo_17','$m2_17','$m1_17','$gv_17','$tubes_dish_17','$eggs_transferred_17','$freezing_date_17','$freezing_media_17','$freezing_container_17','$freezing_straw_17','$freezing_color_17','$freezing_oocytes_17','$storage_renewal_date_17','$thawing_date_17','$thawing_purpose_17','$thawing_egg_thawed_17','$thawing_egg_recovered_17','$thawing_path_17','$discarding_date_17','$discarding_purpose_17','$remarks_17','$embryologist_witnessed_17','$doctors_witnessed_17','$date_18','$coc_retreived_18','$oocytes_retreived_no_18','$oocytes_retreived_photo_18','$m2_18','$m1_18','$gv_18','$tubes_dish_18','$eggs_transferred_18','$freezing_date_18','$freezing_media_18','$freezing_container_18','$freezing_straw_18','$freezing_color_18','$freezing_oocytes_18','$storage_renewal_date_18','$thawing_date_18','$thawing_purpose_18','$thawing_egg_thawed_18','$thawing_egg_recovered_18','$thawing_path_18','$discarding_date_18','$discarding_purpose_18','$remarks_18','$embryologist_witnessed_18','$doctors_witnessed_18','$date_19','$coc_retreived_19','$oocytes_retreived_no_19','$oocytes_retreived_photo_19','$m2_19','$m1_19','$gv_19','$tubes_dish_19','$eggs_transferred_19','$freezing_date_19','$freezing_media_19','$freezing_container_19','$freezing_straw_19','$freezing_color_19','$freezing_oocytes_19','$storage_renewal_date_19','$thawing_date_19','$thawing_purpose_19','$thawing_egg_thawed_19','$thawing_egg_recovered_19','$thawing_path_19','$discarding_date_19','$discarding_purpose_19','$remarks_19','$embryologist_witnessed_19','$doctors_witnessed_19','$date_20','$coc_retreived_20','$oocytes_retreived_no_20','$oocytes_retreived_photo_20','$m2_20','$m1_20','$gv_20','$tubes_dish_20','$eggs_transferred_20','$freezing_date_20','$freezing_media_20','$freezing_container_20','$freezing_straw_20','$freezing_color_20','$freezing_oocytes_20','$storage_renewal_date_20','$thawing_date_20','$thawing_purpose_20','$thawing_egg_thawed_20','$thawing_egg_recovered_20','$thawing_path_20','$discarding_date_20','$discarding_purpose_20','$remarks_20','$embryologist_witnessed_20','$doctors_witnessed_20','$date_21','$coc_retreived_21','$oocytes_retreived_no_21','$oocytes_retreived_photo_21','$m2_21','$m1_21','$gv_21','$tubes_dish_21','$eggs_transferred_21','$freezing_date_21','$freezing_media_21','$freezing_container_21','$freezing_straw_21','$freezing_color_21','$freezing_oocytes_21','$storage_renewal_date_21','$thawing_date_21','$thawing_purpose_21','$thawing_egg_thawed_21','$thawing_egg_recovered_21','$thawing_path_21','$discarding_date_21','$discarding_purpose_21','$remarks_21','$embryologist_witnessed_21','$doctors_witnessed_21','$date_22','$coc_retreived_22','$oocytes_retreived_no_22','$oocytes_retreived_photo_22','$m2_22','$m1_22','$gv_22','$tubes_dish_22','$eggs_transferred_22','$freezing_date_22','$freezing_media_22','$freezing_container_22','$freezing_straw_22','$freezing_color_22','$freezing_oocytes_22','$storage_renewal_date_22','$thawing_date_22','$thawing_purpose_22','$thawing_egg_thawed_22','$thawing_egg_recovered_22','$thawing_path_22','$discarding_date_22','$discarding_purpose_22','$remarks_22','$embryologist_witnessed_22','$doctors_witnessed_22','$date_23','$coc_retreived_23','$oocytes_retreived_no_23','$oocytes_retreived_photo_23','$m2_23','$m1_23','$gv_23','$tubes_dish_23','$eggs_transferred_23','$freezing_date_23','$freezing_media_23','$freezing_container_23','$freezing_straw_23','$freezing_color_23','$freezing_oocytes_23','$storage_renewal_date_23','$thawing_date_23','$thawing_purpose_23','$thawing_egg_thawed_23','$thawing_egg_recovered_23','$thawing_path_23','$discarding_date_23','$discarding_purpose_23','$remarks_23','$embryologist_witnessed_23','$doctors_witnessed_23','$date_24','$coc_retreived_24','$oocytes_retreived_no_24','$oocytes_retreived_photo_24','$m2_24','$m1_24','$gv_24','$tubes_dish_24','$eggs_transferred_24','$freezing_date_24','$freezing_media_24','$freezing_container_24','$freezing_straw_24','$freezing_color_24','$freezing_oocytes_24','$storage_renewal_date_24','$thawing_date_24','$thawing_purpose_24','$thawing_egg_thawed_24','$thawing_egg_recovered_24','$thawing_path_24','$discarding_date_24','$discarding_purpose_24','$remarks_24','$embryologist_witnessed_24','$doctors_witnessed_24','$date_25','$coc_retreived_25','$oocytes_retreived_no_25','$oocytes_retreived_photo_25','$m2_25','$m1_25','$gv_25','$tubes_dish_25','$eggs_transferred_25','$freezing_date_25','$freezing_media_25','$freezing_container_25','$freezing_straw_25','$freezing_color_25','$freezing_oocytes_25','$storage_renewal_date_25','$thawing_date_25','$thawing_purpose_25','$thawing_egg_thawed_25','$thawing_egg_recovered_25','$thawing_path_25','$discarding_date_25','$discarding_purpose_25','$remarks_25','$embryologist_witnessed_25','$doctors_witnessed_25')";



	//     $result = run_form_query($query);



 //        if($result){

 //          header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));

	// 				die();

 //        }else{

 //          header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));

	// 				die();

 //        }

 //  	}

?>-->



<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">

    

<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">

<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">

<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">



    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">

                <input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">

                <input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">

                <input type="hidden" value="pending" name="status"> 

                <div class="container red-field form mt-5 mb-5">

                    <table class="table-bordered" width="100%">

        				<tr>

        				    <td colspan="2">

                			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&

                			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 

                			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])

                			            ){?>

                			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>

                			    <?php } ?>

                			</td>

        				</tr>

        			</table>

                    <table class="table table-bordered table-hover mt-2 table-sm red-field tableMg">

                        <thead></thead>

                        <table class="table table-bordered table-hover mt-2 table-sm red-field tableMg">

                            <thead></thead>

                        </table>

                        <ul class="d-flex mb-1 mt-2 list-unstyled">

                            <div class="table-responsive">

                                <table style="text-align: center; background-color: #e7e6e6;" class="table table-bordered table-hover table-sm">

                                    <thead>

                                        <tr><th colspan="8" style="color: red;"><h2>OPU (OVUM PICKUP) DETAILS</h2></th></tr>

                                    </thead>

                                    <thead>

                                        <tr>

                                            <th colspan="4" style="color: red;"><h2>SELF CYCLE  (S)</h2></th>

                                            <th colspan="4"><h2>DONOR CYCLE (D)</h2></th>

                                        </tr>

                                    </thead>

                                    <thead>

                                        <tr>

                                            <th colspan="2" style="color: red;"><strong>Partners name</strong></th>

                                            <th colspan="2"><input type="text" maxlength="2000" class="form" value="<?php echo isset($select_result['partners_name'])?$select_result['partners_name']:""; ?>" name="partners_name"></th>

                                            <th colspan="2"><strong>ART bank reg no</strong></th>

                                            <th colspan="2"><input type="text" maxlength="2000" class="form" value="<?php echo isset($select_result['art_bank_reg_no'])?$select_result['art_bank_reg_no']:""; ?>" name="art_bank_reg_no"></th>

                                        </tr>

                                    </thead>

                                    <thead>

                                        <tr>

                                            <th colspan="2" style="color: red;"><strong>ID</strong></th>

                                            <th colspan="2"><input type="text" maxlength="2000" class="form" value="<?php echo isset($select_result['form_id'])?$select_result['form_id']:""; ?>" name="form_id"></th>

                                            <th colspan="2"><strong>Donor ID</strong></th>

                                            <th colspan="2"><input type="text" maxlength="2000" class="form" value="<?php echo isset($select_result['donor_d'])?$select_result['donor_d']:""; ?>" name="donor_d"></th>

                                        </tr>

                                    </thead>

                                    <thead>

                                        <tr>

                                            <td>Time of Procedure (start):</td>

                                            <td><input type="time" value="<?php echo isset($select_result['procdure_time'])?$select_result['procdure_time']:""; ?>" name="procdure_time"></td>

                                            <td>Time of trigger</td>

                                            <td><input type="time" value="<?php echo isset($select_result['trigger_time'])?$select_result['trigger_time']:""; ?>" name="trigger_time"></td>

                                            <td>Time of completion:</td>

                                            <td><input type="time" value="<?php echo isset($select_result['completion_time'])?$select_result['completion_time']:""; ?>" name="completion_time"></td>

                                            <td>Needle used:</td>

                                            <td>

                                                <input type="radio"  name="needle_used" value="Single" <?php if(isset($select_result['needle_used']) && $select_result['needle_used'] == "Single"){echo 'checked="checked"'; }?> > Single

                                                <input type="radio"  name="needle_used" value="Double" <?php if(isset($select_result['needle_used']) && $select_result['needle_used'] == "Double"){echo 'checked="checked"'; }?> > Double

                                            </td>

                                        </tr>

                                    </thead>

                                </table>

                            </div>

                        </ul>

                        <div class='table-responsive'>

                            <table class="table table-bordered table-hover mt-2 table-sm">

                                <colgroup>

                                    <col style="background: #e7e6e6;">

                                    <col style="background: #b4c6e7;">

                                    <col span="2" style="background: #ffe598;">

                                    <col style="background: #f4b083;">

                                    <col style="background: #a8d08d;">

                                    <col style="background: #9cc2e5;">

                                    <col style="background: #d0cece;">

                                    <col style="background: #5b9bd5;">

                                    <col span="6" style="background: #a8d08d;">

                                    <col style="background: #ffc000;">

                                    <col span="5" style="background: #c55a11;">

                                    <col span="2" style="background: #ffc000;">

                                    <?php

                                        for($i=1;$i<=3;$i++){

                                            echo '<col>';

                                        }

                                    ?>

                                </colgroup>

                                <tr>

                                    <td rowspan="2">DATE</td>

                                    <td rowspan="2" style="color: green;">No.COC (Cumulus oocyte complex) Retreived</td>

                                    <td colspan="2" style="color: #20B0E2;">oocytes retreived</td>

                                    <td rowspan="2" style="color: #20B0E2; padding:30px!important;">M2</td>

                                    <td rowspan="2" style="color: #20B0E2; padding:30px!important;">M1</td>

                                    <td rowspan="2" style="color: #20B0E2; padding:30px!important;">GV</td>

                                    <td rowspan="2">Tubes+dish check by</td>

                                    <td rowspan="2">Eggs transferred by</td>

                                    <td colspan="6" style="color: red;">FREEZING</td>

                                    <td rowspan="2" style="color: red;">Storage renewal date</td>

                                    <td colspan="5" style="color: red;">THAWING</td>

                                    <td colspan="2" style="color: red;">DISCARDING</td>

                                    <td rowspan="2">REMARKS</td>

                                    <td rowspan="2">WITNESSED BY EMBRYOLOGIST</td>

                                    <td rowspan="2">WITNESSED BY DOCTORS</td>

                                </tr>

                                <tr>

                                    <td style="color: #20B0E2;">NO</td>

                                    <td style="color: #20B0E2;">UPLOAD PHOTO</td>

                                    <td style="color: red;">Date</td>

                                    <td>Media</td>

                                    <td>Container no</td>

                                    <td>no.of straw</td>

                                    <td>colour</td>

                                    <td style="color: red;">NO.OF OOCYTES</td>

                                    <td style="color: red;">Date</td>

                                    <td>Purpose</td>

                                    <td style="color: red;">No. Egg thawed</td>

                                    <td style="color: red;">No. Egg Recovered</td>

                                    <td>THAWING PATH</td>

                                    <td style="color: red;">DATE</td>

                                    <td>PURPOSE</td>

                                </tr>

                                <tr>

                                    <td><input type="date" value="<?php echo isset($select_result['date_1'])?$select_result['date_1']:""; ?>" class="form" name="date_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['coc_retreived_1'])?$select_result['coc_retreived_1']:""; ?>" min="0" class="form" name="coc_retreived_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['oocytes_retreived_no_1'])?$select_result['oocytes_retreived_no_1']:""; ?>" min="0" max="2000" class="form" name="oocytes_retreived_no_1"></td>

                                    <td><input type="file" class="form" name="oocytes_retreived_photo_1">

                                    <a target="_blank" href="<?php echo !empty($select_result['oocytes_retreived_photo_1'])?$select_result['oocytes_retreived_photo_1']:"javascript:void(0)"; ?>">Download</a></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m2_1'])?$select_result['m2_1']:""; ?>" min="0" max="2000" class="form" name="m2_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m1_1'])?$select_result['m1_1']:""; ?>" min="0" max="2000" class="form" name="m1_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['gv_1'])?$select_result['gv_1']:""; ?>" min="0" max="2000" class="form" name="gv_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['tubes_dish_1'])?$select_result['tubes_dish_1']:""; ?>" maxlength="2000" class="form" name="tubes_dish_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['eggs_transferred_1'])?$select_result['eggs_transferred_1']:""; ?>" maxlength="2000" class="form" name="eggs_transferred_1"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['freezing_date_1'])?$select_result['freezing_date_1']:""; ?>" class="form" name="freezing_date_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_media_1'])?$select_result['freezing_media_1']:""; ?>" maxlength="2000" class="form" name="freezing_media_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_container_1'])?$select_result['freezing_container_1']:""; ?>" maxlength="2000" class="form" name="freezing_container_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_straw_1'])?$select_result['freezing_straw_1']:""; ?>" min="0" max="2000" class="form" name="freezing_straw_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_color_1'])?$select_result['freezing_color_1']:""; ?>" maxlength="2000" class="form" name="freezing_color_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_oocytes_1'])?$select_result['freezing_oocytes_1']:""; ?>" min="0" max="2000" class="form" name="freezing_oocytes_1"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['storage_renewal_date_1'])?$select_result['storage_renewal_date_1']:""; ?>" class="form" name="storage_renewal_date_1"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['thawing_date_1'])?$select_result['thawing_date_1']:""; ?>" class="form" name="thawing_date_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_purpose_1'])?$select_result['thawing_purpose_1']:""; ?>" maxlength="2000" class="form" name="thawing_purpose_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_thawed_1'])?$select_result['thawing_egg_thawed_1']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_thawed_1"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_recovered_1'])?$select_result['thawing_egg_recovered_1']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_recovered_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_path_1'])?$select_result['thawing_path_1']:""; ?>" maxlength="2000" class="form" name="thawing_path_1"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['discarding_date_1'])?$select_result['discarding_date_1']:""; ?>" class="form" name="discarding_date_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['discarding_purpose_1'])?$select_result['discarding_purpose_1']:""; ?>" maxlength="2000" class="form" name="discarding_purpose_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['remarks_1'])?$select_result['remarks_1']:""; ?>" maxlength="2000" class="form" name="remarks_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['embryologist_witnessed_1'])?$select_result['embryologist_witnessed_1']:""; ?>" maxlength="2000" class="form" name="embryologist_witnessed_1"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['doctors_witnessed_1'])?$select_result['doctors_witnessed_1']:""; ?>" maxlength="2000" class="form" name="doctors_witnessed_1"></td>

                                </tr>

                                <tr>

                                    <td><input type="date" value="<?php echo isset($select_result['date_2'])?$select_result['date_2']:""; ?>" class="form" name="date_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['coc_retreived_2'])?$select_result['coc_retreived_2']:""; ?>" min="0" class="form" name="coc_retreived_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['oocytes_retreived_no_2'])?$select_result['oocytes_retreived_no_2']:""; ?>" min="0" max="2000" class="form" name="oocytes_retreived_no_2"></td>

                                    <td><input type="file"  class="form" name="oocytes_retreived_photo_2">

                                    <a target="_blank" href="<?php echo !empty($select_result['oocytes_retreived_photo_2'])?$select_result['oocytes_retreived_photo_2']:"javascript:void(0)"; ?>">Download</a></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m2_2'])?$select_result['m2_2']:""; ?>" min="0" max="2000" class="form" name="m2_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m1_2'])?$select_result['m1_2']:""; ?>" min="0" max="2000" class="form" name="m1_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['gv_2'])?$select_result['gv_2']:""; ?>" min="0" max="2000" class="form" name="gv_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['tubes_dish_2'])?$select_result['tubes_dish_2']:""; ?>" maxlength="2000" class="form" name="tubes_dish_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['eggs_transferred_2'])?$select_result['eggs_transferred_2']:""; ?>" maxlength="2000" class="form" name="eggs_transferred_2"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['freezing_date_2'])?$select_result['freezing_date_2']:""; ?>" class="form" name="freezing_date_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_media_2'])?$select_result['freezing_media_2']:""; ?>" maxlength="2000" class="form" name="freezing_media_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_container_2'])?$select_result['freezing_container_2']:""; ?>" maxlength="2000" class="form" name="freezing_container_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_straw_2'])?$select_result['freezing_straw_2']:""; ?>" min="0" max="2000" class="form" name="freezing_straw_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_color_2'])?$select_result['freezing_color_2']:""; ?>" maxlength="2000" class="form" name="freezing_color_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_oocytes_2'])?$select_result['freezing_oocytes_2']:""; ?>" min="0" max="2000" class="form" name="freezing_oocytes_2"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['storage_renewal_date_2'])?$select_result['storage_renewal_date_2']:""; ?>" class="form" name="storage_renewal_date_2"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['thawing_date_2'])?$select_result['thawing_date_2']:""; ?>" class="form" name="thawing_date_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_purpose_2'])?$select_result['thawing_purpose_2']:""; ?>" maxlength="2000" class="form" name="thawing_purpose_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_thawed_2'])?$select_result['thawing_egg_thawed_2']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_thawed_2"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_recovered_2'])?$select_result['thawing_egg_recovered_2']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_recovered_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_path_2'])?$select_result['thawing_path_2']:""; ?>" maxlength="2000" class="form" name="thawing_path_2"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['discarding_date_2'])?$select_result['discarding_date_2']:""; ?>" class="form" name="discarding_date_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['discarding_purpose_2'])?$select_result['discarding_purpose_2']:""; ?>" maxlength="2000" class="form" name="discarding_purpose_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['remarks_2'])?$select_result['remarks_2']:""; ?>" maxlength="2000" class="form" name="remarks_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['embryologist_witnessed_2'])?$select_result['embryologist_witnessed_2']:""; ?>" maxlength="2000" class="form" name="embryologist_witnessed_2"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['doctors_witnessed_2'])?$select_result['doctors_witnessed_2']:""; ?>" maxlength="2000" class="form" name="doctors_witnessed_2"></td>

                                </tr>

                                <tr>

                                    <td><input type="date" value="<?php echo isset($select_result['date_3'])?$select_result['date_3']:""; ?>" class="form" name="date_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['coc_retreived_3'])?$select_result['coc_retreived_3']:""; ?>" min="0" class="form" name="coc_retreived_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['oocytes_retreived_no_3'])?$select_result['oocytes_retreived_no_3']:""; ?>" min="0" max="2000" class="form" name="oocytes_retreived_no_3"></td>

                                    <td><input type="file" class="form" name="oocytes_retreived_photo_3">

                                    <a target="_blank" href="<?php echo !empty($select_result['oocytes_retreived_photo_3'])?$select_result['oocytes_retreived_photo_3']:"javascript:void(0)"; ?>">Download</a></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m2_3'])?$select_result['m2_3']:""; ?>" min="0" max="2000" class="form" name="m2_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m1_3'])?$select_result['m1_3']:""; ?>" min="0" max="2000" class="form" name="m1_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['gv_3'])?$select_result['gv_3']:""; ?>" min="0" max="2000" class="form" name="gv_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['tubes_dish_3'])?$select_result['tubes_dish_3']:""; ?>" maxlength="2000" class="form" name="tubes_dish_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['eggs_transferred_3'])?$select_result['eggs_transferred_3']:""; ?>" maxlength="2000" class="form" name="eggs_transferred_3"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['freezing_date_3'])?$select_result['freezing_date_3']:""; ?>" class="form" name="freezing_date_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_media_3'])?$select_result['freezing_media_3']:""; ?>" maxlength="2000" class="form" name="freezing_media_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_container_3'])?$select_result['freezing_container_3']:""; ?>" maxlength="2000" class="form" name="freezing_container_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_straw_3'])?$select_result['freezing_straw_3']:""; ?>" min="0" max="2000" class="form" name="freezing_straw_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_color_3'])?$select_result['freezing_color_3']:""; ?>" maxlength="2000" class="form" name="freezing_color_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_oocytes_3'])?$select_result['freezing_oocytes_3']:""; ?>" min="0" max="2000" class="form" name="freezing_oocytes_3"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['storage_renewal_date_3'])?$select_result['storage_renewal_date_3']:""; ?>" class="form" name="storage_renewal_date_3"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['thawing_date_3'])?$select_result['thawing_date_3']:""; ?>" class="form" name="thawing_date_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_purpose_3'])?$select_result['thawing_purpose_3']:""; ?>" maxlength="2000" class="form" name="thawing_purpose_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_thawed_3'])?$select_result['thawing_egg_thawed_3']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_thawed_3"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_recovered_3'])?$select_result['thawing_egg_recovered_3']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_recovered_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_path_3'])?$select_result['thawing_path_3']:""; ?>" maxlength="2000" class="form" name="thawing_path_3"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['discarding_date_3'])?$select_result['discarding_date_3']:""; ?>" class="form" name="discarding_date_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['discarding_purpose_3'])?$select_result['discarding_purpose_3']:""; ?>" maxlength="2000" class="form" name="discarding_purpose_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['remarks_3'])?$select_result['remarks_3']:""; ?>" maxlength="2000" class="form" name="remarks_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['embryologist_witnessed_3'])?$select_result['embryologist_witnessed_3']:""; ?>" maxlength="2000" class="form" name="embryologist_witnessed_3"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['doctors_witnessed_3'])?$select_result['doctors_witnessed_3']:""; ?>" maxlength="2000" class="form" name="doctors_witnessed_3"></td>

                                </tr>

                                <tr>

                                    <td><input type="date" value="<?php echo isset($select_result['date_4'])?$select_result['date_4']:""; ?>" class="form" name="date_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['coc_retreived_4'])?$select_result['coc_retreived_4']:""; ?>" min="0" class="form" name="coc_retreived_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['oocytes_retreived_no_4'])?$select_result['oocytes_retreived_no_4']:""; ?>" min="0" max="2000" class="form" name="oocytes_retreived_no_4"></td>

                                    <td><input type="file"  class="form" name="oocytes_retreived_photo_4">

                                    <a target="_blank" href="<?php echo !empty($select_result['oocytes_retreived_photo_4'])?$select_result['oocytes_retreived_photo_4']:"javascript:void(0)"; ?>">Download</a></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m2_4'])?$select_result['m2_4']:""; ?>" min="0" max="2000" class="form" name="m2_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m1_4'])?$select_result['m1_4']:""; ?>" min="0" max="2000" class="form" name="m1_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['gv_4'])?$select_result['gv_4']:""; ?>" min="0" max="2000" class="form" name="gv_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['tubes_dish_4'])?$select_result['tubes_dish_4']:""; ?>" maxlength="2000" class="form" name="tubes_dish_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['eggs_transferred_4'])?$select_result['eggs_transferred_4']:""; ?>" maxlength="2000" class="form" name="eggs_transferred_4"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['freezing_date_4'])?$select_result['freezing_date_4']:""; ?>" class="form" name="freezing_date_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_media_4'])?$select_result['freezing_media_4']:""; ?>" maxlength="2000" class="form" name="freezing_media_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_container_4'])?$select_result['freezing_container_4']:""; ?>" maxlength="2000" class="form" name="freezing_container_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_straw_4'])?$select_result['freezing_straw_4']:""; ?>" min="0" max="2000" class="form" name="freezing_straw_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_color_4'])?$select_result['freezing_color_4']:""; ?>" maxlength="2000" class="form" name="freezing_color_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_oocytes_4'])?$select_result['freezing_oocytes_4']:""; ?>" min="0" max="2000" class="form" name="freezing_oocytes_4"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['storage_renewal_date_4'])?$select_result['storage_renewal_date_4']:""; ?>" class="form" name="storage_renewal_date_4"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['thawing_date_4'])?$select_result['thawing_date_4']:""; ?>" class="form" name="thawing_date_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_purpose_4'])?$select_result['thawing_purpose_4']:""; ?>" maxlength="2000" class="form" name="thawing_purpose_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_thawed_4'])?$select_result['thawing_egg_thawed_4']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_thawed_4"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_recovered_4'])?$select_result['thawing_egg_recovered_4']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_recovered_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_path_4'])?$select_result['thawing_path_4']:""; ?>" maxlength="2000" class="form" name="thawing_path_4"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['discarding_date_4'])?$select_result['discarding_date_4']:""; ?>" class="form" name="discarding_date_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['discarding_purpose_4'])?$select_result['discarding_purpose_4']:""; ?>" maxlength="2000" class="form" name="discarding_purpose_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['remarks_4'])?$select_result['remarks_4']:""; ?>" maxlength="2000" class="form" name="remarks_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['embryologist_witnessed_4'])?$select_result['embryologist_witnessed_4']:""; ?>" maxlength="2000" class="form" name="embryologist_witnessed_4"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['doctors_witnessed_4'])?$select_result['doctors_witnessed_4']:""; ?>" maxlength="2000" class="form" name="doctors_witnessed_4"></td>

                                </tr>

                                <tr>

                                    <td><input type="date" value="<?php echo isset($select_result['date_5'])?$select_result['date_5']:""; ?>" class="form" name="date_5"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['coc_retreived_5"'])?$select_result['coc_retreived_5"']:""; ?>" class="form" name="coc_retreived_5"></td5>

                                    <td><input type="number" value="<?php echo isset($select_result['oocytes_retreived_no_5"'])?$select_result['oocytes_retreived_no_5"']:""; ?>" class="form" name="oocytes_retreived_no_5"></td5>

                                    <td><input type="file"  class="form" name="oocytes_retreived_photo_5">

                                    <a target="_blank" href="<?php echo !empty($select_result['oocytes_retreived_photo_5'])?$select_result['oocytes_retreived_photo_5']:"javascript:void(0)"; ?>">Download</a></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m2_5'])?$select_result['m2_5']:""; ?>" min="0" max="2000" class="form" name="m2_5"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['m1_5'])?$select_result['m1_5']:""; ?>" min="0" max="2000" class="form" name="m1_5"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['gv_5'])?$select_result['gv_5']:""; ?>" min="0" max="2000" class="form" name="gv_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['tubes_dish_5'])?$select_result['tubes_dish_5']:""; ?>" maxlength="2000" class="form" name="tubes_dish_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['eggs_transferred_5'])?$select_result['eggs_transferred_5']:""; ?>" maxlength="2000" class="form" name="eggs_transferred_5"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['freezing_date_5'])?$select_result['freezing_date_5']:""; ?>" class="form" name="freezing_date_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_media_5'])?$select_result['freezing_media_5']:""; ?>" maxlength="2000" class="form" name="freezing_media_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_container_5'])?$select_result['freezing_container_5']:""; ?>" maxlength="2000" class="form" name="freezing_container_5"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_straw_5'])?$select_result['freezing_straw_5']:""; ?>" min="0" max="2000" class="form" name="freezing_straw_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['freezing_color_5'])?$select_result['freezing_color_5']:""; ?>" maxlength="2000" class="form" name="freezing_color_5"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['freezing_oocytes_5'])?$select_result['freezing_oocytes_5']:""; ?>" min="0" max="2000" class="form" name="freezing_oocytes_5"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['storage_renewal_date_5'])?$select_result['storage_renewal_date_5']:""; ?>" class="form" name="storage_renewal_date_5"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['thawing_date_5'])?$select_result['thawing_date_5']:""; ?>" class="form" name="thawing_date_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_purpose_5'])?$select_result['thawing_purpose_5']:""; ?>" maxlength="2000" class="form" name="thawing_purpose_5"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_thawed_5'])?$select_result['thawing_egg_thawed_5']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_thawed_5"></td>

                                    <td><input type="number" value="<?php echo isset($select_result['thawing_egg_recovered_5'])?$select_result['thawing_egg_recovered_5']:""; ?>" min="0" max="2000" class="form" name="thawing_egg_recovered_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['thawing_path_5'])?$select_result['thawing_path_5']:""; ?>" maxlength="2000" class="form" name="thawing_path_5"></td>

                                    <td><input type="date" value="<?php echo isset($select_result['discarding_date_5'])?$select_result['discarding_date_5']:""; ?>" class="form" name="discarding_date_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['discarding_purpose_5'])?$select_result['discarding_purpose_5']:""; ?>" maxlength="2000" class="form" name="discarding_purpose_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['remarks_5'])?$select_result['remarks_5']:""; ?>" maxlength="2000" class="form" name="remarks_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['embryologist_witnessed_5'])?$select_result['embryologist_witnessed_5']:""; ?>" maxlength="2000" class="form" name="embryologist_witnessed_5"></td>

                                    <td><input type="text" value="<?php echo isset($select_result['doctors_witnessed_5'])?$select_result['doctors_witnessed_5']:""; ?>" maxlength="2000" class="form" name="doctors_witnessed_5"></td>

                                </tr>

                                <?php

                                    for($i=6;$i<=25;$i++){

                                        echo '<tr>';

                                            $value1="";

                                            if(isset($select_result['date_'.$i])) {$value1 = $select_result['date_'.$i]; }

                                            $value2="";

                                            if(isset($select_result['coc_retreived_'.$i])) {$value2 = $select_result['coc_retreived_'.$i]; }

                                            $value3="";

                                            if(isset($select_result['oocytes_retreived_no_'.$i])) {$value3 = $select_result['oocytes_retreived_no_'.$i]; }

                                            $value4="";

                                            if(isset($select_result['oocytes_retreived_photo_'.$i])) {$value4 = $select_result['oocytes_retreived_photo_'.$i]; }

                                            $value5="";

                                            if(isset($select_result['m2_'.$i])) {$value5 = $select_result['m2_'.$i]; }

                                            $value6="";

                                            if(isset($select_result['m1_'.$i])) {$value6 = $select_result['m1_'.$i]; }

                                            $value7="";

                                            if(isset($select_result['gv_'.$i])) {$value7 = $select_result['gv_'.$i]; }

                                            $value8="";

                                            if(isset($select_result['tubes_dish_'.$i])) {$value8 = $select_result['tubes_dish_'.$i]; }

                                            $value9="";

                                            if(isset($select_result['eggs_transferred_'.$i])) {$value9 = $select_result['eggs_transferred_'.$i]; }

                                            $value10="";

                                            if(isset($select_result['freezing_date_'.$i])) {$value10 = $select_result['freezing_date_'.$i]; }

                                            $value11="";

                                            if(isset($select_result['freezing_media_'.$i])) {$value11 = $select_result['freezing_media_'.$i]; }

                                            $value12="";

                                            if(isset($select_result['freezing_container_'.$i])) {$value12 = $select_result['freezing_container_'.$i]; }

                                            $value13="";

                                            if(isset($select_result['freezing_straw_'.$i])) {$value13 = $select_result['freezing_straw_'.$i]; }

                                            $value14="";

                                            if(isset($select_result['freezing_color_'.$i])) {$value14 = $select_result['freezing_color_'.$i]; }

                                            $value15="";

                                            if(isset($select_result['freezing_oocytes_'.$i])) {$value15 = $select_result['freezing_oocytes_'.$i]; }

                                            $value16="";

                                            if(isset($select_result['storage_renewal_date_'.$i])) {$value16 = $select_result['storage_renewal_date_'.$i]; }

                                            $value17="";

                                            if(isset($select_result['thawing_date_'.$i])) {$value17 = $select_result['thawing_date_'.$i]; }

                                            $value18="";

                                            if(isset($select_result['thawing_purpose_'.$i])) {$value18 = $select_result['thawing_purpose_'.$i]; }

                                            $value19="";

                                            if(isset($select_result['thawing_egg_thawed_'.$i])) {$value19 = $select_result['thawing_egg_thawed_'.$i]; }

                                            $value20="";

                                            if(isset($select_result['thawing_egg_recovered_'.$i])) {$value20 = $select_result['thawing_egg_recovered_'.$i]; }

                                            $value21="";

                                            if(isset($select_result['thawing_path_'.$i])) {$value21 = $select_result['thawing_path_'.$i]; }

                                            $value22="";

                                            if(isset($select_result['discarding_date_'.$i])) {$value22 = $select_result['discarding_date_'.$i]; }

                                            $value23="";

                                            if(isset($select_result['discarding_purpose_'.$i])) {$value23 = $select_result['discarding_purpose_'.$i]; }

                                            $value24="";

                                            if(isset($select_result['remarks_'.$i])) {$value24 = $select_result['remarks_'.$i]; }

                                            $value25="";

                                            if(isset($select_result['embryologist_witnessed_'.$i])) {$value25 = $select_result['embryologist_witnessed_'.$i]; }

                                            $value26="";

                                            if(isset($select_result['doctors_witnessed_'.$i])) {$value26 = $select_result['doctors_witnessed_'.$i]; }



                                            $file_value="javascript:void(0);";

                                            if(!empty($select_result['oocytes_retreived_photo_'.$i])){

                                                $file_value=$select_result['oocytes_retreived_photo_'.$i];

                                            }



                                            echo '<td><input type="date" value="'.$value1.'" class="form" name="date_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value2.'" class="form" name="coc_retreived_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value3.'" class="form" name="oocytes_retreived_no_'.$i.'"></td>';

                                            echo '<td><input type="file" class="form" name="oocytes_retreived_photo_'.$i.'"><a target="_blank" href="'.$file_value.'">Download</a></td>';

                                            echo '<td><input type="number" value="'.$value5.'" min="0" max="2000" class="form" name="m2_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value6.'" min="0" max="2000" class="form" name="m1_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value7.'" min="0" max="2000" class="form" name="gv_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value8.'" maxlength="2000" class="form" name="tubes_dish_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value9.'" maxlength="2000" class="form" name="eggs_transferred_'.$i.'"></td>';

                                            echo '<td><input type="date" value="'.$value10.'" class="form" name="freezing_date_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value11.'" maxlength="2000" class="form" name="freezing_media_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value12.'" maxlength="2000" class="form" name="freezing_container_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value13.'" min="0" max="2000" class="form" name="freezing_straw_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value14.'" maxlength="2000" class="form" name="freezing_color_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value15.'" min="0" max="2000" class="form" name="freezing_oocytes_'.$i.'"></td>';

                                            echo '<td><input type="date" value="'.$value16.'" class="form" name="storage_renewal_date_'.$i.'"></td>';

                                            echo '<td><input type="date" value="'.$value17.'" class="form" name="thawing_date_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value18.'" maxlength="2000" class="form" name="thawing_purpose_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value19.'" min="0" max="2000" class="form" name="thawing_egg_thawed_'.$i.'"></td>';

                                            echo '<td><input type="number" value="'.$value20.'" min="0" max="2000" class="form" name="thawing_egg_recovered_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value21.'" maxlength="2000" class="form" name="thawing_path_'.$i.'"></td>';

                                            echo '<td><input type="date" value="'.$value22.'" class="form" name="discarding_date_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value23.'" maxlength="2000" class="form" name="discarding_purpose_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value24.'" maxlength="2000" class="form" name="remarks_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value25.'" maxlength="2000" class="form" name="embryologist_witnessed_'.$i.'"></td>';

                                            echo '<td><input type="text" value="'.$value26.'" maxlength="2000" class="form" name="doctors_witnessed_'.$i.'"></td>';

                                        echo '</tr>';

                                    }

                                ?>

                            </table>

                        </div>

                        <p class="mt-2">

                            <span>UPLOAD PHOTO</span>

                            <input type = "file" id="file" name="upload" multiple change = "onFileChange"/>

                            <a target="_blank" href="<?php echo !empty($select_result['upload'])?$select_result['upload']:"javascript:void(0)"; ?>">Download</a>

                        </p>

                    <!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->

                    <input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">

                    </table>

                </div>

            </form>