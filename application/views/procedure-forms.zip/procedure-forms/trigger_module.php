<?php
    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        //var_dump($_POST);die;
		if(!empty($_FILES['upload']['tmp_name'])){
			$dest_path = $this->config->item('upload_path');
			$destination = $dest_path.'procedure-forms-uploads/';
			$NewImageName = rand(4,10000)."-".$_FILES['upload']['name'];
			$transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
			move_uploaded_file($_FILES['upload']['tmp_name'], $destination.$NewImageName);
			$_POST['upload'] = $transaction_img;
		}
        
        $select_query = "SELECT * FROM `trigger_module` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `trigger_module` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE trigger_module SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `trigger_module` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
    $select_result = run_select_query($select_query);
	
	// php code to Insert data into mysql database from input text
	// if(isset($_POST['submit'])){
	// 	$patient_id = $_POST['patient_id'];
    //     $receipt_number = $_POST['receipt_number'];
	// 	$status = $_POST['status'];
	// 	// get values form input text and number
	// 	$dates = $_POST['dates'];
	// 	$times = $_POST['times'];
	// 	$ht = $_POST['ht'];
	// 	$wt = $_POST['wt'];
	// 	$consent = $_POST['consent'];
	// 	$id_checked = $_POST['id_checked'];
	// 	$bp = $_POST['bp'];
	// 	$pulse = $_POST['pulse'];
	// 	$resp = $_POST['resp'];
	// 	$voided = $_POST['voided'];
	// 	$allergies = $_POST['allergies'];
	// 	$contacts = $_POST['contacts'];
	// 	$denture = $_POST['denture'];
	// 	$dental_bridge = $_POST['dental_bridge'];
	// 	$escort = $_POST['escort'];
	// 	$last_meal = $_POST['last_meal'];
	// 	$indication = $_POST['indication'];
	// 	$resp2 = $_POST['resp2'];
	// 	$cvs = $_POST['cvs'];
	// 	$cns = $_POST['cns'];
	// 	$emset2 = $_POST['emset2'];
	// 	$others = $_POST['others'];
	// 	$doctor_signature = $_POST['doctor_signature'];
	// 	$doctor_name = $_POST['doctor_name'];
	// 	$time2 = $_POST['time2'];
	// 	$date2 = $_POST['date2'];
	// 	$oocytes_retrieved = $_POST['oocytes_retrieved'];
	// 	$anesthetist = $_POST['anesthetist'];
	// 	$embryologist = $_POST['embryologist'];
	// 	$doctor = $_POST['doctor'];
	// 	$nurse = $_POST['nurse'];
	// 	$last_inj_fsh = $_POST['last_inj_fsh'];
	// 	$last_cetrotide = $_POST['last_cetrotide'];
	// 	$inj_lupride = $_POST['inj_lupride'];
	// 	$inj_hcg = $_POST['inj_hcg'];
	// 	$ovum_pick_up_on = $_POST['ovum_pick_up_on'];
	// 	$ovum_pick_up_at = $_POST['ovum_pick_up_at'];
	// 	$admit = $_POST['admit'];
	// 	$no_food_liquids = $_POST['no_food_liquids'];
	// 	$no_food_liquids1 = $_POST['no_food_liquids1'];
	// 	$last_inj_fsh_at = $_POST['last_inj_fsh_at'];
	// 	$last_cetrotide_at = $_POST['last_cetrotide_at'];
	// 	$inj_lupride_at = $_POST['inj_lupride_at'];
	// 	$inj_hcg_at = $_POST['inj_hcg_at'];
	// 	$admit_on = $_POST['admit_on'];
	// 	$admit_at = $_POST['admit_at'];
	// 	$produce_fresh_sperm = $_POST['produce_fresh_sperm'];
	// 	$glasses = $_POST['glasses'];
	// 	$prescriptions_other = $_POST['prescriptions_other'];
	// 	$comments = $_POST['comments'];
	// 	$npo_x_2hrs = $_POST['npo_x_2hrs'];
	// 	$sips_of_fluid = $_POST['sips_of_fluid'];
	// 	$fluid = $_POST['fluid'];
	// 	$paracetamol = $_POST['paracetamol'];
	// 	$justin_suppository = $_POST['justin_suppository'];
	// 	$monitor_pulse = $_POST['monitor_pulse'];
	// 	$monitor_bleeding = $_POST['monitor_bleeding'];
	// 	$remove_vaginal_pack = $_POST['remove_vaginal_pack'];
	// 	$medication = $_POST['medication'];
	// 	$dosage = $_POST['dosage'];
	// 	$route = $_POST['route'];
	// 	$frequency = $_POST['frequency'];
	// 	$timings = $_POST['timings'];
	// 	$when_to_start = $_POST['when_to_start'];
	// 	$days = $_POST['days'];

	// 	// connect to mysql database using mysqli
		
		
	// 	// mysql query to insert data
	// 	$query = "INSERT INTO `trigger_module`(`patient_id`, `receipt_number`, `status`,`dates`,`times`,`ht`,`wt`,`consent`,`id_checked`,`bp`,`pulse`,`resp`,`voided`,`allergies`,`contacts`,`denture`,`dental_bridge`,`escort`,`last_meal`,`indication`,`resp2`,`cvs`,`cns`,`emset2`,`others`,`doctor_signature`,`doctor_name`,`time2`,`date2`,`oocytes_retrieved`,`anesthetist`,`embryologist`,`doctor`,`nurse`,`last_inj_fsh`,`last_cetrotide`,`inj_lupride`,`inj_hcg`,`ovum_pick_up_on`,`ovum_pick_up_at`,`admit`,`no_food_liquids`,`no_food_liquids1`,`last_inj_fsh_at`,`last_cetrotide_at`,`inj_lupride_at`,`inj_hcg_at`,`admit_on`,`admit_at`,`produce_fresh_sperm`,`glasses`,`prescriptions_other`,`comments`,`npo_x_2hrs`,`sips_of_fluid`,`fluid`,`paracetamol`,`justin_suppository`,`monitor_pulse`,`monitor_bleeding`,`remove_vaginal_pack`,`medication`,`dosage`,`route`,`frequency`,`timings`,`when_to_start`,`days`) VALUES ('$patient_id','$receipt_number','$status','$dates','$times','$ht','$wt','$consent','$id_checked','$bp','$pulse','$resp','$voided','$allergies','$contacts','$denture','$dental_bridge','$escort','$last_meal','$indication','$resp','$cvs','$cns','$emset2','$others','$doctor_signature','$doctor_name','$time2','$date2','$oocytes_retrieved','$anesthetist','$embryologist','$doctor','$nurse','$last_inj_fsh','$last_cetrotide','$inj_lupride','$inj_hcg','$ovum_pick_up_on','$ovum_pick_up_at','$admit','$no_food_liquids','$no_food_liquids1','$last_inj_fsh_at','$last_cetrotide_at','$inj_lupride_at','$inj_hcg_at','$admit_on','$admit_at','$produce_fresh_sperm','$glasses','$prescriptions_other','$comments','$npo_x_2hrs','$sips_of_fluid','$fluid','$paracetamol','$justin_suppository','$monitor_pulse','$monitor_bleeding','$remove_vaginal_pack','$medication','$dosage','$route','$frequency','$timings','$when_to_start','$days')";
		
	// 	$result = run_form_query($query);

    //     if($result){
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
	// 				die();
    //     }else{
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
	// 				die();
    //     }
	// }
?>

<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
	<input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
	<input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
	<input type="hidden" value="pending" name="status"> 
	<table class="table-bordered" width="100%">
				<tr>
					<td colspan="2">
        			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
        			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
        			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
        			            ){?>
        			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
        			    <?php } ?>
        			</td>
				</tr>
			</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td>INSTRUCTIONS PRIOR TO EGG COLLECTION</td>
		</tr>
		<tr>
			<td>• LAST INJ.OF FSH/GMH @<input  type="text" value="<?php echo isset($select_result['last_inj_fsh_at'])?$select_result['last_inj_fsh_at']:""; ?>"     maxlength="20" name="last_inj_fsh_at" >	on <input  type="date" value="<?php echo isset($select_result['last_inj_fsh'])?$select_result['last_inj_fsh']:""; ?>"     name="last_inj_fsh" ></td>
		</tr>
		<tr>
			<td>• TAKE LAST CETROTIDE @<input  type="text" value="<?php echo isset($select_result['last_cetrotide_at'])?$select_result['last_cetrotide_at']:""; ?>"     maxlength="20" name="last_cetrotide_at" >	on <input  type="date" value="<?php echo isset($select_result['last_cetrotide'])?$select_result['last_cetrotide']:""; ?>"     name="last_cetrotide" ></td>
		</tr>
		<tr>
			<td>• TAKE INJ.LUPRIDE @ <input  type="text" value="<?php echo isset($select_result['inj_lupride_at'])?$select_result['inj_lupride_at']:""; ?>"     maxlength="20" name="inj_lupride_at" > on <input  type="date" value="<?php echo isset($select_result['inj_lupride'])?$select_result['inj_lupride']:""; ?>"     name="inj_lupride" ></td>
		</tr>
		<tr>
			<td>• Take Inj. HCG @ <input  type="text" value="<?php echo isset($select_result['inj_hcg_at'])?$select_result['inj_hcg_at']:""; ?>"     maxlength="20" name="inj_hcg_at" > on <input  type="date" value="<?php echo isset($select_result['inj_hcg'])?$select_result['inj_hcg']:""; ?>"     name="inj_hcg" ></td>
		</tr>
		<tr>
			<td>• Ovum pick up on <input  type="date" value="<?php echo isset($select_result['ovum_pick_up_on'])?$select_result['ovum_pick_up_on']:""; ?>"     name="ovum_pick_up_on" > @ <input  type="text" value="<?php echo isset($select_result['ovum_pick_up_at'])?$select_result['ovum_pick_up_at']:""; ?>"     maxlength="20" name="ovum_pick_up_at" ></td>
		</tr>
		<tr>
			<td>• Admit @ <input  type="text" value="<?php echo isset($select_result['admit'])?$select_result['admit']:""; ?>"     maxlength="20" name="admit" > in day care on <input  type="date" value="<?php echo isset($select_result['admit_on'])?$select_result['admit_on']:""; ?>"     name="admit_on" > At <input  type="text" value="<?php echo isset($select_result['admit_at'])?$select_result['admit_at']:""; ?>"     name="admit_at" maxlength="20" ></td>
		</tr>
		<tr>
			<td>• No food /liquids (nil per mouth) 08 hrs before ovum pick up from <input  type="text" value="<?php echo isset($select_result['no_food_liquids'])?$select_result['no_food_liquids']:""; ?>"     maxlength="20" name="no_food_liquids" > hrs on <input  type="date" value="<?php echo isset($select_result['no_food_liquids1'])?$select_result['no_food_liquids1']:""; ?>"     name="no_food_liquids1" >.</td>
		</tr>
		<tr>
			<td>• Male partner to produce fresh sperm sample on the day of egg collection AT IVF CENTRE (Time to be confirmed on the day).<input  type="text" value="<?php echo isset($select_result['produce_fresh_sperm'])?$select_result['produce_fresh_sperm']:""; ?>"     maxlength="20" name="produce_fresh_sperm" ></td>
		</tr>
		<tr>
			<td><h4>GENERAL INSTRUCTIONS PRIOR TO EGG COLLECTION (OVUM PICKUP)</h4></td>
		</tr>
		<tr>
			<td>1.Stop Tablet Ecosprin/Aspirin/Baby aspirin 48 hrs prior to procedure</td>
		</tr>
		<tr>
			<td>2.Continue thyroid/antihypertensive/progynova medication with sips of water in the morning of pick up.</td>
		</tr>
		<tr>
			<td>3.If you are taking oral medications for diabetes please see anesthetist three days before procedure for instructions /medications /insulin.</td>
		</tr>
		<tr>
			<td>4.Pre anesthetic check up will be done</td>
		</tr>
		<tr>
			<td>5.You should arrange for a responsible adult to accompany you home from the day stay unit following egg collection. and to remain with you overnight. You should not be left alone in home for 24 hrs. following the procedures We can not perform egg collection if you fail to arrange an escort. You will need to rest at home all day following the procedures, but you should feel well enough to resume normal activities the day after.</td>
		</tr>
		<tr>
			<td>6.Please leave valuables and jewelry at home. Please remove nail paint and make up prior to the procedure. It is important that you do not wear any strong perfumes before the procedure.</td>
		</tr>
		<tr>
			<td>7.Please remove vaginal hair (by normal waxing/shaving/trimming ) at home before you come for ovum pick up</td>
		</tr>
		<tr>
			<td>8.You will be kept in for approximately 2 hours after your operation to allow a full recovery. Your escort should be available to take you home.</td>
		</tr>
		<tr>
			<td>9.Please remember to inform us of any medication (other than ivf drugs) that you take regularly- i.e. inhalers, blood pressure tablets. You should bring all medication with you to the fertility unit on the day of egg collection.</td>
		</tr>
		<tr>
			<td>10. Do not take alcohol for 24 hours prior to your egg collection. Please refrain from smoking for as long as possible before the procedure.</td>
		</tr>
		<tr>
			<td>11.We look forward to seeing you and will do everything to ensure a safe and comfortable stay.</td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td><b>OVUM PICK UP/Pre Fresh cycle self ET</b></td>
			<td>
				Date<br>
				<input  type="date" value="<?php echo isset($select_result['dates'])?$select_result['dates']:""; ?>"     name="dates" class="form-control" >
			</td>
			<td>
				Time<br>
				<input  type="time" value="<?php echo isset($select_result['times'])?$select_result['times']:""; ?>"     name="times" class="form-control" >
			</td>
			<td>
				Indication<br>
				<input  type="text" value="<?php echo isset($select_result['indication'])?$select_result['indication']:""; ?>"     maxlength="50" name="indication" class="form-control" >
			</td>
			<td>
				Allergies<br>
				<input  type="text" value="<?php echo isset($select_result['allergies'])?$select_result['allergies']:""; ?>"     maxlength="50" name="allergies" class="form-control" >
			</td>
			<td>
				Consent<br>
				<label><input type="radio"  name="consent"   value="Yes"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="consent"   value="No"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['consent']) && $select_result['consent'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>
				ID <br>
				<label><input type="radio"  name="id_checked"   value="Yes"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="id_checked"   value="No"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['id_checked']) && $select_result['id_checked'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
		</tr>
		<tr>
			<td>PRE ASSESSMENT</td>
			<td>
				BP<br>
				<input  type="text" value="<?php echo isset($select_result['bp'])?$select_result['bp']:""; ?>"     maxlength="20" name="bp" class="form-control" >
			</td>
			<td>
				Pulse<br>
				<label><input type="radio"  name="pulse"   value="Yes"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="pulse"   value="No"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['pulse']) && $select_result['pulse'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>
				Resp<br>
				<label><input type="radio"  name="resp"   value="Yes"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="resp"   value="No"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp']) && $select_result['resp'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>
				Voided<br>
				<label><input type="radio"  name="voided"   value="Yes"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="voided"   value="No"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['voided']) && $select_result['voided'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>
				Ht (Cms)<br>
				<input  type="number" value="<?php echo isset($select_result['ht'])?$select_result['ht']:""; ?>"     min="0" name="ht" class="form-control" >
			</td>
			<td>
				Wt (Kg)<br>
				<input  type="number" value="<?php echo isset($select_result['wt'])?$select_result['wt']:""; ?>"     min="0" name="wt" class="form-control" >
			</td>
		</tr>
		<tr>
			<td style="color: black;">
				Glasses<br>
				<label><input type="radio"  name="glasses"   value="Yes"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="glasses"   value="No"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['glasses']) && $select_result['glasses'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td style="color: black;">
				Contacts<br>
				<label><input type="radio"  name="contacts"   value="Yes"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="contacts"   value="No"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['contacts']) && $select_result['contacts'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td style="color: black;">
				Denture<br>
				<label><input type="radio"  name="denture"   value="Yes"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="denture"   value="No"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['denture']) && $select_result['denture'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td style="color: black;" colspan="2">
				Dental bridge<br>
				<label><input type="radio"  name="dental_bridge"   value="Yes"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="dental_bridge"   value="No"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td style="color: black;">
				Valuables with escort<br>
				<label><input type="radio"  name="escort"   value="Yes"  <?php if(isset($select_result['escort']) && $select_result['escort'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="escort"   value="No"  <?php if(isset($select_result['escort']) && $select_result['escort'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['escort']) && $select_result['escort'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td style="color: black;">
				Last meal<br>
				<input  type="time" value="<?php echo isset($select_result['last_meal'])?$select_result['last_meal']:""; ?>"     name="last_meal" class="form-control" >
			</td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td colspan="8"><b>Prescriptions given</b></td>
		</tr>
		<tr>
			<td colspan="8">
				Injection Monocef 1 gm iv AST<br>
				Injection Pantoprazole 40 mg i.m. stat<br>
				Injection emset 8 mg iv stat<br>
				Other: <input  type="text" value="<?php echo isset($select_result['prescriptions_other'])?$select_result['prescriptions_other']:""; ?>"     maxlength="100" name="prescriptions_other" class="form-control" >
			</td>
		</tr>
		<tr>
			<td>Nurse</td>
			<td><input  type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>"     maxlength="20" name="nurse" class="form-control" ></td>
			<td>Doctor</td>
			<td><input  type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>"     maxlength="20" name="doctor" class="form-control" ></td>
			<td>Embryologist</td>
			<td><input  type="text" value="<?php echo isset($select_result['embryologist'])?$select_result['embryologist']:""; ?>"     maxlength="20" name="embryologist" class="form-control" ></td>
			<td>Anesthetist</td>
			<td><input  type="text" value="<?php echo isset($select_result['anesthetist'])?$select_result['anesthetist']:""; ?>"     maxlength="20" name="anesthetist" class="form-control" ></td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td style="padding: 0;" width="20%">
				<table width="100%">
					<tr><td colspan="2"><b>PRE ASSESSMENT</b></td></tr>
					<tr>
						<td colspan="2">
							No sexual intercourse for 72 hrs<br>
							No active infection<br>
							No aspirin or NSAID a week before
						</td>
					</tr>
					<tr><td colspan="2"><b>Physical Examination</b></td></tr>
					<tr>
						<td>Resp</td>
						<td><input  type="text" value="<?php echo isset($select_result['resp2'])?$select_result['resp2']:""; ?>"     maxlength="20" name="resp2"></td>
					</tr>
					<tr>
						<td>CVS</td>
						<td><input  type="text" value="<?php echo isset($select_result['cvs'])?$select_result['cvs']:""; ?>"     maxlength="20" name="cvs"></td>
					</tr>
					<tr>
						<td>CNS</td>
						<td><input  type="text" value="<?php echo isset($select_result['cns'])?$select_result['cns']:""; ?>"     maxlength="20" name="cns"></td>
					</tr>
					<tr>
						<td>Abdominal</td>
						<td><input  type="text" value="<?php echo isset($select_result['emset2'])?$select_result['emset2']:""; ?>"     maxlength="20" name="emset2"></td>
					</tr>
					<tr>
						<td>Others</td>
						<td><input  type="text" value="<?php echo isset($select_result['others'])?$select_result['others']:""; ?>"     maxlength="100" name="others"></td>
					</tr>
				</table>
			</td>
			<td>
				<p>Written informed consent taken . All vitals  under normal range. The anesthetist examined the patient and given general anesthesia .Patient put in lithotomy position ,under all sterile conditions, the vulva and vagina were cleansed by normal saline and draped. A transducer probe cover with jelly inside is put on the vaginal ultrasound probe,ultrasound guide attached to the probe ,it is introduced transvaginally  ,a baseline transvaginal ultrasound performed to see endometrium and ovaries. Following baseline scan , follicles were aspirated from both right and left ovaries . Follicular fluid aspirated and given to embryologist . <input  type="text" value="<?php echo isset($select_result['oocytes_retrieved'])?$select_result['oocytes_retrieved']:""; ?>"     maxlength="20" name="oocytes_retrieved" > oocytes retrieved.</p>
				<p>No complications seen. Bleeding was mild/moderate .Hemostasis achieved.Patient tolerated the procedure well and was transferred to the recovery room in satisfactory condition.</p>
				<p>Comments <input  type="text" value="<?php echo isset($select_result['comments'])?$select_result['comments']:""; ?>"     maxlength="20" name="comments"></p>
			</td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr><td colspan="2"><b>Intra Operative orders</b></td></tr>
		<tr>
			<td>
				<label><input type="radio"  name="npo_x_2hrs"   value="Yes"  <?php if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="npo_x_2hrs"   value="No"  <?php if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['npo_x_2hrs']) && $select_result['npo_x_2hrs'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>NPO X 2HRS</td>
		</tr>
		<tr>
			<td>
				<label><input type="radio"  name="sips_of_fluid"   value="Yes"  <?php if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="sips_of_fluid"   value="No"  <?php if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['sips_of_fluid']) && $select_result['sips_of_fluid'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>Sips of fluid after 2 hrs fld by soft diet</td>
		</tr>
		<tr>
			<td>
				<label><input type="radio"  name="fluid"   value="Yes"  <?php if(isset($select_result['fluid']) && $select_result['fluid'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="fluid"   value="No"  <?php if(isset($select_result['fluid']) && $select_result['fluid'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['fluid']) && $select_result['fluid'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>i.v. fluid R.L or NS 500 ml@ 125 ml/hr</td>
		</tr>
		<tr>
			<td>
				<label><input type="radio"  name="paracetamol"   value="Yes"  <?php if(isset($select_result['paracetamol']) && $select_result['paracetamol'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="paracetamol"   value="No"  <?php if(isset($select_result['paracetamol']) && $select_result['paracetamol'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['paracetamol']) && $select_result['paracetamol'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>i.v. paracetamol 100 ml (SOS)@8-10 drops/min</td>
		</tr>
		<tr>
			<td>
				<label><input type="radio"  name="justin_suppository"   value="Yes"  <?php if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="justin_suppository"   value="No"  <?php if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['justin_suppository']) && $select_result['justin_suppository'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>Justin suppository per rectally</td>
		</tr>
		<tr>
			<td>
				<label><input type="radio"  name="monitor_pulse"   value="Yes"  <?php if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="monitor_pulse"   value="No"  <?php if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['monitor_pulse']) && $select_result['monitor_pulse'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>Monitor pulse/BP/Spo2 continuously</td>
		</tr>
		<tr>
			<td>
				<label><input type="radio"  name="monitor_bleeding"   value="Yes"  <?php if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="monitor_bleeding"   value="No"  <?php if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['monitor_bleeding']) && $select_result['monitor_bleeding'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>Monitor bleeding p/v every half hour</td>
		</tr>
		<tr>
			<td>
				<label><input type="radio"  name="remove_vaginal_pack"   value="Yes"  <?php if(isset($select_result['remove_vaginal_pack']) && $select_result['remove_vaginal_pack'] == "Yes"){echo 'checked="checked"'; }?>  > Yes</label>
				<label><input type="radio"  name="remove_vaginal_pack"   value="No"  <?php if(isset($select_result['remove_vaginal_pack']) && $select_result['remove_vaginal_pack'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['remove_vaginal_pack']) && $select_result['remove_vaginal_pack'] != "Yes"){echo 'checked="checked"';}?>  > No</label>
			</td>
			<td>Remove vaginal pack if any</td>
		</tr>
		<tr>
			<td colspan="2">
				<b><u>POST OPERATIVE ORDERS</u></b>
			</td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td>Check applicable</td>
			<td>Medication</td>
			<td>Dosage</td>
			<td>Route</td>
			<td>Frequency</td>
			<td>Timings</td>
			<td>When to start</td>
			<td>Days</td>
		</tr>
		<tr>
			<td></td>
			<td><input class="form-control"  type="text" value="<?php echo isset($select_result['medication'])?$select_result['medication']:""; ?>"     name="medication"></td>
			<td><input class="form-control"  type="text" value="<?php echo isset($select_result['dosage'])?$select_result['dosage']:""; ?>"     name="dosage"></td>
			<td>
				<select class="form-control" name="route">
					<option value="">Select Any One</option>
					<option <?php if(isset($select_result['route']) && $select_result['route'] == "PO"){echo 'selected="selected"'; }?>   value="PO">PO</option>
					<option <?php if(isset($select_result['route']) && $select_result['route'] == "IM"){echo 'selected="selected"'; }?>   value="IM">IM</option>
					<option <?php if(isset($select_result['route']) && $select_result['route'] == "SC"){echo 'selected="selected"'; }?>   value="SC">SC</option>
					<option <?php if(isset($select_result['route']) && $select_result['route'] == "VAGINA-LY"){echo 'selected="selected"'; }?>   value="VAGINA-LY">VAGINA-LY</option>
					<option <?php if(isset($select_result['route']) && $select_result['route'] == "IV"){echo 'selected="selected"'; }?>   value="IV">IV</option>
					<option <?php if(isset($select_result['route']) && $select_result['route'] == "LOCAL"){echo 'selected="selected"'; }?>   value="LOCAL">LOCAL</option>
					<option <?php if(isset($select_result['route']) && $select_result['route'] == "NASALY"){echo 'selected="selected"'; }?>   value="NASALY">NASALY</option>
				</select>
			</td>
			<td>
				<select class="form-control" name="frequency">
					<option value="">Select Any One</option>
					<option <?php if(isset($select_result['frequency']) && $select_result['frequency'] == "OD"){echo 'selected="selected"'; }?>   value="OD">OD</option>
					<option <?php if(isset($select_result['frequency']) && $select_result['frequency'] == "BD"){echo 'selected="selected"'; }?>   value="BD">BD</option>
					<option <?php if(isset($select_result['frequency']) && $select_result['frequency'] == "TDS"){echo 'selected="selected"'; }?>   value="TDS">TDS</option>
					<option <?php if(isset($select_result['frequency']) && $select_result['frequency'] == "QID"){echo 'selected="selected"'; }?>   value="QID">QID</option>
					<option <?php if(isset($select_result['frequency']) && $select_result['frequency'] == "SOS"){echo 'selected="selected"'; }?>   value="SOS">SOS</option>
					<option <?php if(isset($select_result['frequency']) && $select_result['frequency'] == "HS"){echo 'selected="selected"'; }?>   value="HS">HS</option>
				</select>
			</td>
			<td>
				<select class="form-control" name="timings">
					<option value="">Select Any One</option>
					<option <?php if(isset($select_result['timings']) && $select_result['timings'] == "EMPTY STOMACH"){echo 'selected="selected"'; }?>   value="EMPTY STOMACH">EMPTY STOMACH</option>
					<option <?php if(isset($select_result['timings']) && $select_result['timings'] == "BEFORE MEAL"){echo 'selected="selected"'; }?>   value="BEFORE MEAL">BEFORE MEAL</option>
					<option <?php if(isset($select_result['timings']) && $select_result['timings'] == "AFTER MEAL"){echo 'selected="selected"'; }?>   value="AFTER MEAL">AFTER MEAL</option>
				</select>
			</td>
			<td><input class="form-control"  type="text" value="<?php echo isset($select_result['when_to_start'])?$select_result['when_to_start']:""; ?>"     maxlength="20" name="when_to_start"></td>
			<td><input class="form-control"  type="number" value="<?php echo isset($select_result['days'])?$select_result['days']:""; ?>"     min="0" name="days"></td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td>
				<p>• Continue thyroid /antihypertensive/ diabetes medications as have been taking previously</p>
				<p>• To report in emergency of the hospital immediately if patient has abdominal pain/ vaginal bleeding/ fever/excessive cough /giddiness /vomiting</p>
			</td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td>DATE</td>
			<td><input  type="date" value="<?php echo isset($select_result['date2'])?$select_result['date2']:""; ?>"     name="date2" class="form-control" ></td>
			<td>TIME</td>
			<td><input  type="time" value="<?php echo isset($select_result['time2'])?$select_result['time2']:""; ?>"     name="time2" class="form-control" ></td>
			<td>Doctor Name</td>
			<td><input  type="text" value="<?php echo isset($select_result['doctor_name'])?$select_result['doctor_name']:""; ?>"     name="doctor_name" class="form-control" ></td>
			<td>Doctor Signature</td>
			<td><input  type="text" value="<?php echo isset($select_result['doctor_signature'])?$select_result['doctor_signature']:""; ?>"     name="doctor_signature" class="form-control" ></td>
		</tr>
	</table>
	<!-- /.card-body -->
	<div class="card-footer">
		<!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
		<input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
	</div>
</form>