<?php

if(isset($_POST['submit'])){
  unset($_POST['submit']);

  $select_query = "SELECT * FROM `testicular_prp` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
  $select_result = run_select_query($select_query); 
  if(empty($select_result)){
      // mysql query to insert data
      $query = "INSERT INTO `testicular_prp` SET ";
      $sqlArr = array();
      foreach( $_POST as $key=> $value )
      {
        $sqlArr[] = " $key = '".addslashes($value)."'";
      }		
      $query .= implode(',' , $sqlArr);
  }else{
      // mysql query to update data
      $query = "UPDATE testicular_prp SET ";
      foreach( $_POST as $key=> $value )
      {
        $sqlArr[] = " $key = '".$value."'"	;
      }
      $query .= implode(',' , $sqlArr);
      $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
  }
  $result = run_form_query($query);        

    if($result){
      header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
				die();
    }else{
      header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
				die();
    }
}
$select_query = "SELECT * FROM `testicular_prp` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
$select_result = run_select_query($select_query);   

	// php code to Insert data into mysql database from input text
	// if(isset($_POST['submit'])){
  //   $patient_id = $_POST['patient_id'];
  //       $receipt_number = $_POST['receipt_number'];
	// 	$status = $_POST['status'];
	// 	// get values form input text and number
	// 	$date = $_POST['date'];
	// 	$time = $_POST['time'];
	// 	$indication = $_POST['indication'];
	// 	$allergy = $_POST['allergy'];
	// 	$consent = $_POST['consent'];
	// 	$id_ = $_POST['id_'];
	// 	$bp = $_POST['bp'];
	// 	$pulse = $_POST['pulse'];
	// 	$resp = $_POST['resp'];
	// 	$voided = $_POST['voided'];
	// 	$ht = $_POST['ht'];
	// 	$wt = $_POST['wt'];
	// 	$contacts = $_POST['contacts'];
	// 	$denture = $_POST['denture'];
	// 	$dental_bridge = $_POST['dental_bridge'];
	// 	$valuables_with_escort = $_POST['valuables_with_escort'];
	// 	$last_meal = $_POST['last_meal'];
	// 	$Resp2 = $_POST['Resp2'];
	// 	$CVS = $_POST['CVS'];
	// 	$CNS = $_POST['CNS'];
	// 	$abdominal = $_POST['abdominal'];
	// 	$others = $_POST['others'];
  //   $doctor_signature = $_POST['doctor_signature'];
	//   $doctor = $_POST['doctor'];
	//   $nurse = $_POST['nurse'];    
  //   $glasses = $_POST['glasses'];
  //   $prescriptions_other = $_POST['prescriptions_other'];
  //   $exercise_daily = $_POST['exercise_daily'];
  //   $avoid_hot_sauna = $_POST['avoid_hot_sauna'];
  //   $diet = $_POST['diet'];
  //   $avoid_tea_coffee = $_POST['avoid_tea_coffee'];
  //   $drink_plenty = $_POST['drink_plenty'];
  //   $walnut_intake = $_POST['walnut_intake'];
  //   $tab_levoflox = $_POST['tab_levoflox'];
  //   $cap_pantoprazole = $_POST['cap_pantoprazole'];
  //   $tab_crocin = $_POST['tab_crocin'];
  //   $cap_lycopene = $_POST['cap_lycopene'];
  //   $arginine_sachet = $_POST['arginine_sachet'];
  //   $cap_evion = $_POST['cap_evion'];
  //   $cap_vit = $_POST['cap_vit'];
  //   $cap_ubqhr = $_POST['cap_ubqhr'];
  //   $medications_as_advised = $_POST['medications_as_advised'];
  //   $report = $_POST['report'];

	// 	// connect to mysql database using mysqli
		

	// 	// mysql query to insert data
	// 	$query = "INSERT INTO `testicular_prp`(`patient_id`, `receipt_number`, `status`,`date`,`time`,`indication`,`allergy`,`consent`,`id_`,`bp`,`pulse`,`resp`,`voided`,`ht`,`wt`,`contacts`,`denture`,`dental_bridge`,`valuables_with_escort`,`last_meal`,`Resp2`,`CVS`,`CNS`,`abdominal`,`others`,`doctor_signature`,`doctor`,`nurse`,`glasses`,`prescriptions_other`,`exercise_daily`,`avoid_hot_sauna`,`diet`,`avoid_tea_coffee`,`drink_plenty`,`walnut_intake`,`tab_levoflox`,`cap_pantoprazole`,`tab_crocin`,`cap_lycopene`,`arginine_sachet`,`cap_evion`,`cap_vit`,`cap_ubqhr`,`medications_as_advised`,`report`) VALUES ('$patient_id','$receipt_number','$status','$date','$time','$indication','$allergy','$consent','$id_','$bp','$pulse','$resp','$voided','$ht','$wt','$contacts','$denture','$dental_bridge','$valuables_with_escort','$last_meal','$Resp2','$CVS','$CNS','$abdominal','$others','$doctor_signature','$doctor','$nurse','$glasses','$prescriptions_other','$exercise_daily','$avoid_hot_sauna','$diet','$avoid_tea_coffee','$drink_plenty','$walnut_intake','$tab_levoflox','$cap_pantoprazole','$tab_crocin','$cap_lycopene','$arginine_sachet','$cap_evion','$cap_vit','$cap_ubqhr','$medications_as_advised','$report')";
	
	// 	$result = run_form_query($query);

  //       if($result){
  //         header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
	// 				die();
  //       }else{
  //         header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
	// 				die();
  //       }
	// }
?>

<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
        <input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
        <input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
        <input type="hidden" value="pending" name="status"> 
          <div class="container red-field form mt-5 mb-5">
              <ul class="d-flex mb-1 mt-2 list-unstyled">
                <div class = "table-responsive">
                    <table class="table-bordered" width="100%">
            			<tr>
            				
            				<td colspan="2">
                			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
                			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
                			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
                			            ){?>
                			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
                			    <?php } ?>
                			</td>
            			</tr>
            		</table>
                  <table class="table table-bordered table-hover table-sm">
                    <thead>
                      <tr style="color: red;">
                        <th><strong>TESTICULAR PRP</strong></th>
                        <td>Date <input class="form-control"  type="date" value="<?php echo isset($select_result['date'])?$select_result['date']:""; ?>"    placeholder="enter a date" name="date"></td>
                        <td>Time <input class="form-control"  type="time" value="<?php echo isset($select_result['time'])?$select_result['time']:""; ?>"    id="appt" name="time"></td>
                        <td>Indication <input class="form-control" maxlength="50"  type="text" value="<?php echo isset($select_result['indication'])?$select_result['indication']:""; ?>"    name="indication"></td>
                        <td>Allergies <input class="form-control" maxlength="50"  type="text" value="<?php echo isset($select_result['allergy'])?$select_result['allergy']:""; ?>"    name="allergy"></td>
                        <td>
                          Consent<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "Yes"){echo 'checked="checked"'; }?>   name="consent"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['consent']) && $select_result['consent'] != "Yes"){echo 'checked="checked"';}?>  name="consent"> No</label>
                        </td>
                        <td>
                          ID <br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "Yes"){echo 'checked="checked"'; }?>   name="id_checked"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['id_checked']) && $select_result['id_checked'] != "Yes"){echo 'checked="checked"';}?>  name="id_checked"> No</label>
                        </td>
                      </tr>
                      <tr style="color: red;">
                        <th><strong>PRE ASSESSMENT</strong></th>
                        <td>BP <input class="form-control" maxlength="20"  type="text" value="<?php echo isset($select_result['bp'])?$select_result['bp']:""; ?>"    name="bp"></td>
                        <td>
                          Pulse<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "Yes"){echo 'checked="checked"'; }?>   name="pulse"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['pulse']) && $select_result['pulse'] != "Yes"){echo 'checked="checked"';}?>  name="pulse"> No</label>
                        </td>
                        <td>
                          RESP<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "Yes"){echo 'checked="checked"'; }?>   name="resp"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp']) && $select_result['resp'] != "Yes"){echo 'checked="checked"';}?>  name="resp"> No</label>
                        </td>
                        <td>
                          Voided<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "Yes"){echo 'checked="checked"'; }?>   name="voided"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['voided']) && $select_result['voided'] != "Yes"){echo 'checked="checked"';}?>  name="voided"> No</label>
                        </td>
                        <td>HT (Cms)<input class="form-control"  type="number" value="<?php echo isset($select_result['ht'])?$select_result['ht']:""; ?>"    min="0" name="ht"></td>
                        <td>WT (Kg)<input class="form-control"  type="number" value="<?php echo isset($select_result['wt'])?$select_result['wt']:""; ?>"    min="0" name="wt"></td>
                      </tr>
                      <tr>
                        <td>
                          Glasses<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "Yes"){echo 'checked="checked"'; }?>   name="glasses"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['glasses']) && $select_result['glasses'] != "Yes"){echo 'checked="checked"';}?>  name="glasses"> No</label>
                        </td>
                        <td>
                          Contacts<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "Yes"){echo 'checked="checked"'; }?>   name="contacts"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['contacts']) && $select_result['contacts'] != "Yes"){echo 'checked="checked"';}?>  name="contacts"> No</label>
                        </td>
                        <td>
                          Denture<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "Yes"){echo 'checked="checked"'; }?>   name="denture"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['denture']) && $select_result['denture'] != "Yes"){echo 'checked="checked"';}?>  name="denture"> No</label>
                        </td>
                        <td colspan="2">
                          Dental Bridge<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "Yes"){echo 'checked="checked"'; }?>   name="dental_bridge"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] != "Yes"){echo 'checked="checked"';}?>  name="dental_bridge"> No</label>
                        </td>
                        <td>
                          Valuables with escort<br>
                          <label><input type="radio"   value="Yes"  <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "Yes"){echo 'checked="checked"'; }?>   name="valuables_with_escort"> Yes</label>
                          <label><input type="radio"    value="No"  <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] != "Yes"){echo 'checked="checked"';}?>  name="valuables_with_escort"> No</label>
                        </td>
                        <td>Last meal <input class="form-control"  type="time" value="<?php echo isset($select_result['last_meal'])?$select_result['last_meal']:""; ?>"    name="last_meal"></td>
                      </tr>
                    </thead>
                  </table>
                </div>
              </ul>
          <div class = "table-responsive">
          <table class="table table-bordered table-hover  table-sm red-field tableMg">
              <thead>
                  <tr>
                      <th>
                        Prescriptions given
                      </th>
                  </tr>
                  <tr>
                    <td>
                      Lignocaine jelly applied locally<br>
                      Other <input class="form-control"  type="text" value="<?php echo isset($select_result['prescriptions_other'])?$select_result['prescriptions_other']:""; ?>"    maxlength="100" name="prescriptions_other">
                    </td>
                  </tr>
              </thead>
          </table>
          <table class="table table-bordered table-hover table-sm red-field tableMg">
            <thead>
              <tr>
                <th>NURSE <input  type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>"    maxlength="20" name="nurse"></th>
                <th>DOCTOR <input  type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>"    maxlength="20" name="doctor"></th>
              </tr>
            </thead>
            <thead>
              <tr>
                <td style="padding: 0; width:30%;">
                  <table width="100%">
                    <tr><td colspan="2">Physical Examination</td></tr>
                    <tr>
                      <td>Resp</td>
                      <td><input  type="text" value="<?php echo isset($select_result['Resp2'])?$select_result['Resp2']:""; ?>"    maxlength="20" name="Resp2"></td>
                    </tr>
                    <tr>
                      <td>CVS</td>
                      <td><input  type="text" value="<?php echo isset($select_result['CVS'])?$select_result['CVS']:""; ?>"    maxlength="20" name="CVS"></td>
                    </tr>
                    <tr>
                      <td>CNS</td>
                      <td><input  type="text" value="<?php echo isset($select_result['CNS'])?$select_result['CNS']:""; ?>"    maxlength="20" name="CNS"></td>
                    </tr>
                    <tr>
                      <td>Abdominal</td>
                      <td><input  type="text" value="<?php echo isset($select_result['abdominal'])?$select_result['abdominal']:""; ?>"    maxlength="20" name="abdominal"></td>
                    </tr>
                    <tr>
                      <td>Others</td>
                      <td><input  type="text" value="<?php echo isset($select_result['others'])?$select_result['others']:""; ?>"    maxlength="100" name="others"></td>
                    </tr>
                  </table>
                      </td>
                      <td>
                        <p>
                          Written informed consent taken. All vitals  under normal range.  15 ml of venous blood was drawn from  Arthrex  Double syringe system ,  centrifuged by ACP centrifuge system for 10 min.  Patient put in supine position ,under all sterile conditions, the scrotum was cleansed by betadine and draped.The area around the spermatic cord was locally anesthetized by injecting 5 ml of 2% lidocaine.The PRP was injected beneath the tunica albuginea in the testicular tissue ,3 ml in each testes,under ultrasound guidance,  using a 23 G needle with a 20 ml syringe attached to it. No complications seen. Patient stood the procedure well.Till20 mins patient made to lie down.
                        </p>
                      </td>
                  </tr>
              </thead>
              <thead>
                <tr>
                  <td colspan="2"><b>Post Procedure Orders</b></td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['exercise_daily']) && $select_result['exercise_daily'] == "Yes"){echo 'checked="checked"'; }?>   name="exercise_daily"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['exercise_daily']) && $select_result['exercise_daily'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['exercise_daily']) && $select_result['exercise_daily'] != "Yes"){echo 'checked="checked"';}?>  name="exercise_daily"> No</label>
                  </td>
                  <td>Regular exercise daily for one hour</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['avoid_hot_sauna']) && $select_result['avoid_hot_sauna'] == "Yes"){echo 'checked="checked"'; }?>   name="avoid_hot_sauna"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['avoid_hot_sauna']) && $select_result['avoid_hot_sauna'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['avoid_hot_sauna']) && $select_result['avoid_hot_sauna'] != "Yes"){echo 'checked="checked"';}?>  name="avoid_hot_sauna"> No</label>
                  </td>
                  <td>Avoid hot sauna bath</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['diet']) && $select_result['diet'] == "Yes"){echo 'checked="checked"'; }?>   name="diet"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['diet']) && $select_result['diet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['diet']) && $select_result['diet'] != "Yes"){echo 'checked="checked"';}?>  name="diet"> No</label>
                  </td>
                  <td>Diet low in carbohydrate ,  green leafy vegetables , beans,pulses ,high protein diet</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['avoid_tea_coffee']) && $select_result['avoid_tea_coffee'] == "Yes"){echo 'checked="checked"'; }?>   name="avoid_tea_coffee"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['avoid_tea_coffee']) && $select_result['avoid_tea_coffee'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['avoid_tea_coffee']) && $select_result['avoid_tea_coffee'] != "Yes"){echo 'checked="checked"';}?>  name="avoid_tea_coffee"> No</label>
                  </td>
                  <td>Avoid/limit intake of tea and coffee</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['drink_plenty']) && $select_result['drink_plenty'] == "Yes"){echo 'checked="checked"'; }?>   name="drink_plenty"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['drink_plenty']) && $select_result['drink_plenty'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['drink_plenty']) && $select_result['drink_plenty'] != "Yes"){echo 'checked="checked"';}?>  name="drink_plenty"> No</label>
                  </td>
                  <td>Drink plenty of fluids</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['walnut_intake']) && $select_result['walnut_intake'] == "Yes"){echo 'checked="checked"'; }?>   name="walnut_intake"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['walnut_intake']) && $select_result['walnut_intake'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['walnut_intake']) && $select_result['walnut_intake'] != "Yes"){echo 'checked="checked"';}?>  name="walnut_intake"> No</label>
                  </td>
                  <td>4 Walnut intake daily</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['tab_levoflox']) && $select_result['tab_levoflox'] == "Yes"){echo 'checked="checked"'; }?>   name="tab_levoflox"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['tab_levoflox']) && $select_result['tab_levoflox'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_levoflox']) && $select_result['tab_levoflox'] != "Yes"){echo 'checked="checked"';}?>  name="tab_levoflox"> No</label>
                  </td>
                  <td>Tab.Levoflox 500 mg once daily  after meals for  5 days</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "Yes"){echo 'checked="checked"'; }?>   name="cap_pantoprazole"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_pantoprazole']) && $select_result['cap_pantoprazole'] != "Yes"){echo 'checked="checked"';}?>  name="cap_pantoprazole"> No</label>
                  </td>
                  <td>Cap Pantoprazole 40 mg once daily in empty stomach for 5 days</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "Yes"){echo 'checked="checked"'; }?>   name="tab_crocin"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] != "Yes"){echo 'checked="checked"';}?>  name="tab_crocin"> No</label>
                  </td>
                  <td>Tab Crocin 500 mg thrice daily eight hourly after meals for 2 days</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['cap_lycopene']) && $select_result['cap_lycopene'] == "Yes"){echo 'checked="checked"'; }?>   name="cap_lycopene"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['cap_lycopene']) && $select_result['cap_lycopene'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_lycopene']) && $select_result['cap_lycopene'] != "Yes"){echo 'checked="checked"';}?>  name="cap_lycopene"> No</label>
                  </td>
                  <td>Cap Lycopene once daily for 72 days after meals</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['arginine_sachet']) && $select_result['arginine_sachet'] == "Yes"){echo 'checked="checked"'; }?>   name="arginine_sachet"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['arginine_sachet']) && $select_result['arginine_sachet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['arginine_sachet']) && $select_result['arginine_sachet'] != "Yes"){echo 'checked="checked"';}?>  name="arginine_sachet"> No</label>
                  </td>
                  <td>L-Arginine sachet twice daily for 72 days after meals</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['cap_evion']) && $select_result['cap_evion'] == "Yes"){echo 'checked="checked"'; }?>   name="cap_evion"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['cap_evion']) && $select_result['cap_evion'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_evion']) && $select_result['cap_evion'] != "Yes"){echo 'checked="checked"';}?>  name="cap_evion"> No</label>
                  </td>
                  <td>Cap Evion 400 mg once daily for 72 days after meals</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['cap_vit']) && $select_result['cap_vit'] == "Yes"){echo 'checked="checked"'; }?>   name="cap_vit"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['cap_vit']) && $select_result['cap_vit'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_vit']) && $select_result['cap_vit'] != "Yes"){echo 'checked="checked"';}?>  name="cap_vit"> No</label>
                  </td>
                  <td>Cap Vit D3 60000 IU once weekly for 72 days after meals</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['cap_ubqhr']) && $select_result['cap_ubqhr'] == "Yes"){echo 'checked="checked"'; }?>   name="cap_ubqhr"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['cap_ubqhr']) && $select_result['cap_ubqhr'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['cap_ubqhr']) && $select_result['cap_ubqhr'] != "Yes"){echo 'checked="checked"';}?>  name="cap_ubqhr"> No</label>
                  </td>
                  <td>Cap UBQHR once daily for 72 days</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['medications_as_advised']) && $select_result['medications_as_advised'] == "Yes"){echo 'checked="checked"'; }?>   name="medications_as_advised"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['medications_as_advised']) && $select_result['medications_as_advised'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['medications_as_advised']) && $select_result['medications_as_advised'] != "Yes"){echo 'checked="checked"';}?>  name="medications_as_advised"> No</label>
                  </td>
                  <td>Continue thyroid/antihypertensive/diabetes /other medical disorder medications as advised</td>
                </tr>
                <tr>
                  <td>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['report']) && $select_result['report'] == "Yes"){echo 'checked="checked"'; }?>   name="report"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['report']) && $select_result['report'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['report']) && $select_result['report'] != "Yes"){echo 'checked="checked"';}?>  name="report"> No</label>
                  </td>
                  <td>To report if giddiness /nausea/vomiting/bleeding/pain/fever /purulent discharge/swelling immediately</td>
                </tr>
              </thead>
          </table>
          <table class="table table-bordered table-hover table-sm red-field tableMg">
            <thead>
                  <tr>
                      <th><p>Doctors signature <input name="doctor_signature"  type="text" value="<?php echo isset($select_result['doctor_signature'])?$select_result['doctor_signature']:""; ?>"   ></p></th>
                  </tr>
            </thead>  
          </table>
          </div>
          <!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
          <input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
      </form>