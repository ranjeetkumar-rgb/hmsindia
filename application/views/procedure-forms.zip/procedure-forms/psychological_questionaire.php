<?php
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
                
        $select_query = "SELECT * FROM `psychological_questionaire` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `psychological_questionaire` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }		
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE psychological_questionaire SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"	;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `psychological_questionaire` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
    $select_result = run_select_query($select_query);   
	
	// php code to Insert data into mysql database from input text
	// if(isset($_POST['submit'])){
	// 	$patient_id = $_POST['patient_id'];
    //     $receipt_number = $_POST['receipt_number'];
	// 	$status = $_POST['status'];
	// 	// get values form input text and number
	// 	$patient = $_POST['patient'];
	// 	$case_sheet = $_POST['case_sheet'];
	// 	$anxiety_snoring = $_POST['anxiety_snoring'];
	// 	$depression_snoring = $_POST['depression_snoring'];
	// 	$social_support_score = $_POST['social_support_score'];
	// 	$cognitive_ability_snoring = $_POST['cognitive_ability_snoring'];
	// 	$egg_donor = $_POST['egg_donor'];
	// 	$surrogate = $_POST['surrogate'];
	// 	$name = $_POST['name'];
	// 	$address = $_POST['address'];
	// 	$phone = $_POST['phone'];
	// 	$work = $_POST['work'];
	// 	$cell = $_POST['cell'];
	// 	$age = $_POST['age'];
	// 	$occupation = $_POST['occupation'];
	// 	$gender = $_POST['gender'];
	// 	$referred_by = $_POST['referred_by'];
	// 	$acknowledge = $_POST['acknowledge'];
	// 	$marital_status = $_POST['marital_status'];
	// 	$presenting_problem = $_POST['presenting_problem'];
	// 	$problem_severity = $_POST['problem_severity'];
	// 	$problem_begin = $_POST['problem_begin'];
	// 	$significant_events = $_POST['significant_events'];
	// 	$therapy_before = $_POST['therapy_before'];
	// 	$hospitalized = $_POST['hospitalized'];
	// 	$attempted_suicide = $_POST['attempted_suicide'];
	// 	$meditation = $_POST['meditation'];
	// 	$main_fear1 = $_POST['main_fear1'];
	// 	$main_fear2 = $_POST['main_fear2'];
	// 	$main_fear3 = $_POST['main_fear3'];
	// 	$main_fear4 = $_POST['main_fear4'];
	// 	$main_fear5 = $_POST['main_fear5'];
	// 	$therapy_before_text = $_POST['therapy_before_text'];
	// 	$hospitalized_text = $_POST['hospitalized_text'];

	// 	// connect to mysql database using mysqli
		
		
	// 	// mysql query to insert data
	// 	$query = "INSERT INTO `psychological_questionaire`(`patient_id`, `receipt_number`, `status`,`patient`,`case_sheet`,`anxiety_snoring`,`depression_snoring`,`social_support_score`,`cognitive_ability_snoring`,`egg_donor`,`surrogate`,`name`,`address`,`phone`,`work`,`cell`,`age`,`occupation`,`gender`,`referred_by`,`acknowledge`,`marital_status`,`presenting_problem`,`problem_severity`,`problem_begin`,`significant_events`,`therapy_before`,`hospitalized`,`attempted_suicide`,`meditation`,`main_fear1`,`main_fear2`,`main_fear3`,`main_fear4`,`main_fear5`,`therapy_before_text`,`hospitalized_text`) VALUES ('$patient_id','$receipt_number','$status','$patient','$case_sheet','$anxiety_snoring','$depression_snoring','$social_support_score','$cognitive_ability_snoring','$egg_donor','$surrogate','$name','$address','$phone','$work','$cell','$age','$occupation','$gender','$referred_by','$acknowledge','$marital_status','$presenting_problem','$problem_severity','$problem_begin','$significant_events','$therapy_before','$hospitalized','$attempted_suicide','$meditation','$main_fear1','$main_fear2','$main_fear3','$main_fear4','$main_fear5','$therapy_before_text','$hospitalized_text')";
		
	// 	$result = run_form_query($query);

    //     if($result){
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
	// 				die();
    //     }else{
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
	// 				die();
    //     }
	// }
?>

<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
	<input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
	<input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
	<input type="hidden" value="pending" name="status"> 
	<table class="table-bordered" width="100%">
		<tr>
			<td colspan="2">PSYCHOLOGY PROFORMA</td>
			<td colspan="2">
			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
			            ){?>
			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
			    <?php } ?>
			</td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td>Patient</td>
			<td><input  type="text" value="<?php echo isset($select_result['patient'])?$select_result['patient']:""; ?>"   name="patient" class="form-control"></td>
			<td colspan="2">Psychological Questionaire</td>
		</tr>
		<tr>
			<td colspan="2"></td>
			<td>Case sheet</td>
			<td><input  type="text" value="<?php echo isset($select_result['case_sheet'])?$select_result['case_sheet']:""; ?>"   name="case_sheet" class="form-control"></td>
		</tr>
		<tr>
			<td colspan="2"></td>
			<td>Anxiety scoring</td>
			<td><input  type="text" value="<?php echo isset($select_result['anxiety_snoring'])?$select_result['anxiety_snoring']:""; ?>"   name="anxiety_snoring" class="form-control"></td>
		</tr>
		<tr>
			<td colspan="2"></td>
			<td>Depression scoring</td>
			<td><input  type="text" value="<?php echo isset($select_result['depression_snoring'])?$select_result['depression_snoring']:""; ?>"   name="depression_snoring" class="form-control"></td>
		</tr>
		<tr>
			<td colspan="2"></td>
			<td>Social support score</td>
			<td><input  type="text" value="<?php echo isset($select_result['social_support_score'])?$select_result['social_support_score']:""; ?>"   name="social_support_score" class="form-control"></td>
		</tr>
		<tr>
			<td colspan="2"></td>
			<td>Cognitive ability scoring</td>
			<td><input  type="text" value="<?php echo isset($select_result['cognitive_ability_snoring'])?$select_result['cognitive_ability_snoring']:""; ?>"   name="cognitive_ability_snoring" class="form-control"></td>
		</tr>
	</table>
	<table class="table-bordered" width="100%">
		<tr>
			<td>Egg Donor</td>
			<td><input  type="text" value="<?php echo isset($select_result['egg_donor'])?$select_result['egg_donor']:""; ?>"   name="egg_donor" class="form-control"></td>
		</tr>
		<tr>
			<td>Surrogate</td>
			<td><input  type="text" value="<?php echo isset($select_result['surrogate'])?$select_result['surrogate']:""; ?>"   name="surrogate" class="form-control"></td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
	</table>
	<h3>Psychological Questionaire</h3>
	<p>I. General Information</p>
	<table>
		<tr>
			<td>Name</td>
			<td><input  type="text" value="<?php echo isset($select_result['name'])?$select_result['name']:""; ?>"   name="name" class="form-control"></td>
		</tr>
		<tr>
			<td>Address</td>
			<td><input  type="text" value="<?php echo isset($select_result['address'])?$select_result['address']:""; ?>"   maxlength="50" name="address" class="form-control"></td>
		</tr>
		<tr>
			<td>Phone: (Home)</td>
			<td><input  type="text" value="<?php echo isset($select_result['phone'])?$select_result['phone']:""; ?>"   maxlength="50" name="phone" class="form-control"></td>
			<td>(Work):</td>
			<td><input  type="text" value="<?php echo isset($select_result['work'])?$select_result['work']:""; ?>"   maxlength="50" name="work" class="form-control"></td>
		</tr>
		<tr>
			<td>Cell:</td>
			<td><input  type="text" value="<?php echo isset($select_result['cell'])?$select_result['cell']:""; ?>"   maxlength="50" name="cell" class="form-control"></td>
		</tr>
		<tr>
			<td>Age:</td>
			<td><input  type="number" value="<?php echo isset($select_result['age'])?$select_result['age']:""; ?>"   max="100" min="1" name="age" class="form-control"></td>
			<td>Occupations:</td>
			<td><input  type="text" value="<?php echo isset($select_result['occupation'])?$select_result['occupation']:""; ?>"   maxlength="50" name="occupation" class="form-control"></td>
			<td>Gender:</td>
			<td><input  type="text" value="<?php echo isset($select_result['gender'])?$select_result['gender']:""; ?>"   name="gender" class="form-control"></td>
		</tr>
		<tr>
			<td>Referred by:</td>
			<td><input  type="text" value="<?php echo isset($select_result['referred_by'])?$select_result['referred_by']:""; ?>"   name="referred_by" class="form-control"></td>
		</tr>
		<tr>
			<td>May I acknowledge the referral?</td>
			<td>
				<input type="radio"  name="acknowledge" value="Yes"  <?php if(isset($select_result['acknowledge']) && $select_result['acknowledge'] == "Yes"){echo 'checked="checked"'; }?>  > <label for="type2"> Yes</label>
				<input type="radio"  name="acknowledge"  value="No"  <?php if(isset($select_result['acknowledge']) && $select_result['acknowledge'] == "No"){echo 'checked="checked"'; }
else if(isset($select_result['acknowledge']) && $select_result['acknowledge'] != "Yes"){echo 'checked="checked"';}?>  > <label for="type2"> No</label>
			</td>
		</tr>
		<tr>
			<td>Marital Status:</td>
			<td colspan="3">
				<input type="radio"  name="marital_status" <?php if(isset($select_result['marital_status']) && $select_result['marital_status'] == "Single"){echo 'checked="checked"'; }?> value="Single"> <label for="type2">Single</label>&nbsp;
				<input type="radio"  name="marital_status" <?php if(isset($select_result['marital_status']) && $select_result['marital_status'] == "Engaged"){echo 'checked="checked"'; }?> value="Engaged"> <label for="type2">Engaged</label>&nbsp;
				<input type="radio"  name="marital_status" <?php if(isset($select_result['marital_status']) && $select_result['marital_status'] == "Married"){echo 'checked="checked"'; }?> value="Married"> <label for="type2">Married</label><br>
				<input type="radio"  name="marital_status" <?php if(isset($select_result['marital_status']) && $select_result['marital_status'] == "Separated"){echo 'checked="checked"'; }?> value="Separated"> <label for="type2">Separated</label>&nbsp;
				<input type="radio"  name="marital_status" <?php if(isset($select_result['marital_status']) && $select_result['marital_status'] == "Divorced"){echo 'checked="checked"'; }?> value="Divorced"> <label for="type2">Divorced</label>&nbsp;
				<input type="radio"  name="marital_status" <?php if(isset($select_result['marital_status']) && $select_result['marital_status'] == "Widowed"){echo 'checked="checked"'; }?> value="Widowed"> <label for="type2">Widowed</label>
			</td>
		</tr>
		<tr>
			<td>2. Description of Presenting Problem</td>
			<td>
				<p>State in your own words the nature of your main problems:</p>
				<textarea name="presenting_problem" class="form-control"><?php echo isset($select_result['presenting_problem'])?$select_result['presenting_problem']:""; ?></textarea>
			</td>
		</tr>
		<tr>
			<td>3. On the scale below, please estimate the severity of your problem(s) now.</td>
			<td colspan="3">
				<input type="radio"  name="problem_severity" <?php if(isset($select_result['problem_severity']) && $select_result['problem_severity'] == "Mildly upsetting"){echo 'checked="checked"'; }?>  value="Mildly upsetting"> <label for="type2">Mildly upsetting</label>&nbsp;
				<input type="radio"  name="problem_severity" <?php if(isset($select_result['problem_severity']) && $select_result['problem_severity'] == "Moderately upsetting"){echo 'checked="checked"'; }?>  value="Moderately upsetting"> <label for="type2">Moderately upsetting</label><br>
				<input type="radio"  name="problem_severity" <?php if(isset($select_result['problem_severity']) && $select_result['problem_severity'] == "Severely upsetting"){echo 'checked="checked"'; }?>  value="Severely upsetting"> <label for="type2">Severely upsetting</label>&nbsp;
				<input type="radio"  name="problem_severity" <?php if(isset($select_result['problem_severity']) && $select_result['problem_severity'] == "extremely severe"){echo 'checked="checked"'; }?>  value="extremely severe"> <label for="type2">Extremely Severe</label>&nbsp;
			</td>
		</tr>
		<tr>
			<td>4. When did your problems begin?</td>
			<td>
				<input  type="text" value="<?php echo isset($select_result['problem_begin'])?$select_result['problem_begin']:""; ?>"   name="problem_begin" class="form-control" >
			</td>
		</tr>
		<tr>
			<td>5. Please describe significant events occurring at that time, or since then, which may relate to the development or maintenance of your problems.</td>
			<td>
				<input  type="text" value="<?php echo isset($select_result['significant_events'])?$select_result['significant_events']:""; ?>"   name="significant_events" class="form-control" >
			</td>
		</tr>
		<tr>
			<td>6. Have you been in therapy before or received any prior professional assistance for your problems?  If so, please give names, professional titles, dates of treatment, and results.</td>
			<td>
				<input type="radio"  name="therapy_before"  value="Yes" <?php if(isset($select_result['therapy_before']) && $select_result['therapy_before'] == "Yes"){echo 'checked="checked"'; }?>> Yes
				<input type="radio"  name="therapy_before"  value="No" <?php if(isset($select_result['therapy_before']) && $select_result['therapy_before'] == "No"){echo 'checked="checked"'; }
else if(isset($select_result['therapy_before']) && $select_result['therapy_before'] != "Yes"){echo 'checked="checked"';}?>  > No
				<input  type="text" value="<?php echo isset($select_result['therapy_before_text'])?$select_result['therapy_before_text']:""; ?>"   name="therapy_before_text">
			</td>
		</tr>
		<tr>
			<td>7. Have you ever been hospitalized for a psychological problem?   Y   N  If yes, when and where?</td>
			<td>
				<input type="radio"  name="hospitalized"  value="Yes"  <?php if(isset($select_result['hospitalized']) && $select_result['hospitalized'] == "Yes"){echo 'checked="checked"'; }?>> Yes
				<input type="radio"  name="hospitalized"  value="No"  <?php if(isset($select_result['hospitalized']) && $select_result['hospitalized'] == "No"){echo 'checked="checked"'; }
else if(isset($select_result['hospitalized']) && $select_result['hospitalized'] != "Yes"){echo 'checked="checked"';}?>  > No
				<input  type="text" value="<?php echo isset($select_result['hospitalized_text'])?$select_result['hospitalized_text']:""; ?>"   name="hospitalized_text">
			</td>
		</tr>
		<tr>
			<td>8. Have you ever attempted suicide?</td>
			<td>
				<input type="radio"  name="attempted_suicide"   value="Yes"    <?php if(isset($select_result['attempted_suicide']) && $select_result['attempted_suicide'] == "Yes"){echo 'checked="checked"'; }?>  > <label for="type2"> Yes</label>
				<input type="radio"  name="attempted_suicide"  value="No"  <?php if(isset($select_result['attempted_suicide']) && $select_result['attempted_suicide'] == "No"){echo 'checked="checked"'; }
else if(isset($select_result['attempted_suicide']) && $select_result['attempted_suicide'] != "Yes"){echo 'checked="checked"';}?>  > <label for="type2"> No</label>
			</td>
		</tr>
		<tr>
			<td>9.Do you practice relaxation or meditation regularly?</td>
			<td>
				<input  type="text" value="<?php echo isset($select_result['meditation'])?$select_result['meditation']:""; ?>"   name="meditation" class="form-control" >
			</td>
		</tr>
	</table>
	<br>
	<p>10. Present Feelings<br>
		<em>Circle any of the following feelings that often apply to you.</em>
	</p>
	<p>Angry &nbsp; &nbsp; Guilty &nbsp; &nbsp; Unhappy &nbsp; &nbsp; Annoyed &nbsp; &nbsp; Happy</p>
	<p>Bored &nbsp; &nbsp; Depressed &nbsp; &nbsp; Regretful &nbsp; &nbsp; Lonely &nbsp; &nbsp; Anxious</p>
	<p>Hopeless &nbsp; &nbsp; Contented Fearful &nbsp; &nbsp; Hopeful &nbsp; &nbsp; Excited &nbsp; &nbsp; Panicky &nbsp; &nbsp; Helpless Optimistic</p>
	<p>Energetic &nbsp; &nbsp; Relaxed &nbsp; &nbsp; Tense &nbsp; &nbsp; Envy &nbsp; &nbsp; Jealous</p>
	<br>
	<table>
		<tr>
			<p>List your 5 main fears:</p>
		</tr>
		<tr>
			<td><input  type="text" value="<?php echo isset($select_result['main_fear1'])?$select_result['main_fear1']:""; ?>"   name="main_fear1" class="form-control"></td>
			<td><input  type="text" value="<?php echo isset($select_result['main_fear2'])?$select_result['main_fear2']:""; ?>"   name="main_fear2" class="form-control"></td>
			<td><input  type="text" value="<?php echo isset($select_result['main_fear3'])?$select_result['main_fear3']:""; ?>"   name="main_fear3" class="form-control"></td>
			<td><input  type="text" value="<?php echo isset($select_result['main_fear4'])?$select_result['main_fear4']:""; ?>"   name="main_fear4" class="form-control"></td>
			<td><input  type="text" value="<?php echo isset($select_result['main_fear5'])?$select_result['main_fear5']:""; ?>"   name="main_fear5" class="form-control"></td>
		</tr>
	</table>
	<div class="card-footer">
		<!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
		<input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
	</div>
</form>