<?php
    if(isset($_POST['submit'])){
      unset($_POST['submit']);
      
      $select_query = "SELECT * FROM `uterine_prp` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
      $select_result = run_select_query($select_query); 
      if(empty($select_result)){
          // mysql query to insert data
          $query = "INSERT INTO `uterine_prp` SET ";
          $sqlArr = array();
          foreach( $_POST as $key=> $value )
          {
            $sqlArr[] = " $key = '".addslashes($value)."'";
          }		
          $query .= implode(',' , $sqlArr);
      }else{
          // mysql query to update data
          $query = "UPDATE uterine_prp SET ";
          foreach( $_POST as $key=> $value )
          {
            $sqlArr[] = " $key = '".$value."'"	;
          }
          $query .= implode(',' , $sqlArr);
          $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
      }
      $result = run_form_query($query);        

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
  }
  $select_query = "SELECT * FROM `uterine_prp` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
  $select_result = run_select_query($select_query);   
	
	// php code to Insert data into mysql database from input text
// if(isset($_POST['submit'])){
//     $patient_id = $_POST['patient_id'];
//         $receipt_number = $_POST['receipt_number'];
//     $status = $_POST['status'];
//     // get values form input text and number
//     $date = $_POST['date'];
//     $time = $_POST['time'];
//     $indication = $_POST['indication'];
//     $allergy = $_POST['allergy'];
//     $consent = $_POST['consent'];
//     $id_ = $_POST['id_'];
//     $bp = $_POST['bp'];
//     $pulse = $_POST['pulse'];
//     $resp = $_POST['resp'];
//     $voided = $_POST['voided'];
//     $ht = $_POST['ht'];
//     $wt = $_POST['wt'];
//     $contacts = $_POST['contacts'];
//     $denture = $_POST['denture'];
//     $dental_bridge = $_POST['dental_bridge'];
//     $valuables_with_escort = $_POST['valuables_with_escort'];
//     $last_meal = $_POST['last_meal'];
//     $resp2 = $_POST['resp2'];
//     $CVS = $_POST['CVS'];
//     $CNS = $_POST['CNS'];
//     $abdominal = $_POST['abdominal'];
//     $others = $_POST['others'];    
//     $doctor_signature = $_POST['doctor_signature'];
//     $doctor = $_POST['doctor'];
//     $nurse = $_POST['nurse'];
//     $prescriptions_others = $_POST['prescriptions_others'];
//     $normal_diet = $_POST['normal_diet'];
//     $tab_crocin = $_POST['tab_crocin'];
//     $other_medicines = $_POST['other_medicines'];
//     $report = $_POST['report'];
//     $glasses = $_POST['glasses'];

//     // connect to mysql database using mysqli
    
    
//     // mysql query to insert data
//     $query = "INSERT INTO `uterine_prp`(`patient_id`, `receipt_number`, `status`,`date`,`time`,`indication`,`allergy`,`consent`,`id_`,`bp`,`pulse`,`resp`,`voided`,`ht`,`wt`,`contacts`,`denture`,`dental_bridge`,`valuables_with_escort`,`last_meal`,`resp2`,`CVS`,`CNS`,`abdominal`,`others`,`doctor_signature`,`doctor`,`nurse`,`prescriptions_others`,`normal_diet`,`tab_crocin`,`other_medicines`,`report`,`glasses`) VALUES ('$patient_id','$receipt_number','$status','$date','$time','$indication','$allergy','$consent','$id_','$bp','$pulse','$resp','$voided','$ht','$wt','$contacts','$denture','$dental_bridge','$valuables_with_escort','$last_meal','$resp2','$CVS','$CNS','$abdominal','$others','$doctor_signature','$doctor','$nurse','$prescriptions_others','$normal_diet','$tab_crocin','$other_medicines','$report','$glasses')";
    
//     $result = run_form_query($query);

//         if($result){
//           header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
//           die();
//         }else{
//           header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
//           die();
//         }
// 	}

?>

<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
      <input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
      <input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
      <input type="hidden" value="pending" name="status"> 
      <div class="container red-field form mt-5 mb-5">
        <ul class="d-flex mb-1 mt-2 list-unstyled">
          <div class = "table-responsive">
            <table class="table table-bordered table-hover table-sm">
              <thead>
                <tr style="color: red;">
                  <th colspan="2"><strong>UTERINE PRP</strong></th>
                  <th colspan="2">
        			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
        			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
        			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
        			            ){?>
        			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
        			    <?php } ?>
        			</th>
                  <td>Date <input  type="date" value="<?php echo isset($select_result['date'])?$select_result['date']:""; ?>"   placeholder="enter a date" name="date"></td>
                  <td>Time <input  type="time" value="<?php echo isset($select_result['time'])?$select_result['time']:""; ?>"   id="appt" name="time"></td>
                  <td>Indication <input  type="text" value="<?php echo isset($select_result['indication'])?$select_result['indication']:""; ?>"   maxlength="50" name="indication"></td>
                  <td>
                    ALLERGIES <br>
                    <input  type="text" value="<?php echo isset($select_result['allergy'])?$select_result['allergy']:""; ?>"   maxlength="50" name="allergy">
                  </td>
                  <td>
                    Consent<br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "Yes"){echo 'checked="checked"'; }?>  name="consent"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['consent']) && $select_result['consent'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['consent']) && $select_result['consent'] != "Yes"){echo 'checked="checked"';}?>   name="consent"> No</label>
                  </td>
                  <td>
                    ID checked<br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "Yes"){echo 'checked="checked"'; }?>  name="id_checked"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['id_checked']) && $select_result['id_checked'] != "Yes"){echo 'checked="checked"';}?>   name="id_checked"> No</label>
                  </td>
                </tr>
                <tr style="color: red;">
                  <td>PRE ASSESSMENT</td>
                  <td>BP <input  type="text" value="<?php echo isset($select_result['bp'])?$select_result['bp']:""; ?>"   maxlength="20" name="bp"></td>
                  <td>
                    PULSE <br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "Yes"){echo 'checked="checked"'; }?>  name="pulse"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['pulse']) && $select_result['pulse'] != "Yes"){echo 'checked="checked"';}?>   name="pulse"> No</label>
                  </td>
                  <td>
                    RESP <br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "Yes"){echo 'checked="checked"'; }?>  name="resp"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['resp']) && $select_result['resp'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp']) && $select_result['resp'] != "Yes"){echo 'checked="checked"';}?>   name="resp"> No</label>
                  </td>
                  <td>
                    VOIDED <br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "Yes"){echo 'checked="checked"'; }?>  name="voided"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['voided']) && $select_result['voided'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['voided']) && $select_result['voided'] != "Yes"){echo 'checked="checked"';}?>   name="voided"> No</label>
                  </td>
                  <td>HT (Cms)<br>
                    <input  type="number" value="<?php echo isset($select_result['ht'])?$select_result['ht']:""; ?>"   min="0" name="ht">
                  </td>
                  <td>
                    WT (Kg)<br>
                     <input  type="number" value="<?php echo isset($select_result['wt'])?$select_result['wt']:""; ?>"   min="0" name="wt">
                  </td>
                </tr>
                <tr>
                  <td>
                    Glasses<br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "Yes"){echo 'checked="checked"'; }?>     name="glasses"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['glasses']) && $select_result['glasses'] != "Yes"){echo 'checked="checked"';}?>   name="glasses"> No</label>
                  </td>
                  <td>
                    Contacts<br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "Yes"){echo 'checked="checked"'; }?>     name="contacts"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['contacts']) && $select_result['contacts'] != "Yes"){echo 'checked="checked"';}?>   name="contacts"> No</label>
                  </td>
                  <td>
                    Denture<br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "Yes"){echo 'checked="checked"'; }?>     name="denture"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['denture']) && $select_result['denture'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['denture']) && $select_result['denture'] != "Yes"){echo 'checked="checked"';}?>   name="denture"> No</label>
                  </td>
                  <td colspan="2">
                    Dental bridge<br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "Yes"){echo 'checked="checked"'; }?>     name="dental_bridge"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] != "Yes"){echo 'checked="checked"';}?>   name="dental_bridge"> No</label>
                  </td>
                  <td>
                    Valuables with escort<br>
                    <label><input type="radio"   value="Yes"  <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "Yes"){echo 'checked="checked"'; }?>     name="valuables_with_escort"> Yes</label>
                    <label><input type="radio"    value="No"  <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] != "Yes"){echo 'checked="checked"';}?>   name="valuables_with_escort"> No</label>
                  </td>
                  <td>Last meal <input  type="time" value="<?php echo isset($select_result['last_meal'])?$select_result['last_meal']:""; ?>"   name="last_meal"></td>
                </tr>
              </thead>
            </table>
          </div>
        </ul>
        <div class = "table-responsive">
        <table class="table table-bordered table-hover  table-sm red-field tableMg">
          <tr>
            <td colspan="2"><b>Prescriptions given</b></td>
          </tr>
          <tr>
            <td colspan="2">Lignocaine jelly applied vaginally</td>
          </tr>
          <tr>
            <td>Other</td>
            <td><input  type="text" value="<?php echo isset($select_result['prescriptions_others'])?$select_result['prescriptions_others']:""; ?>"   maxlength="100" name="prescriptions_others"></td>
          </tr>
        </table>
        <table class="table table-bordered table-hover table-sm red-field tableMg">
          <tr>
            <td>NURSE</td>
            <td><input  type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>"   maxlength="20" class="form-control" name="nurse"></td>
            <td>DOCTOR</td>
            <td><input  type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>"   maxlength="20" class="form-control" name="doctor"></td>
          </tr>
          <tr>
            <td colspan="2" style="padding: 0; width:30%;">
              <table>
                <tr>
                  <td colspan="2">Physical Examination</td>
                </tr>
                <tr>
                  <td>Resp</td>
                  <td><input class="form-control" maxlength="20"  type="text" value="<?php echo isset($select_result['resp2'])?$select_result['resp2']:""; ?>"   name="resp2"></td>
                </tr>
                <tr>
                  <td>CVS</td>
                  <td><input class="form-control" maxlength="20"  type="text" value="<?php echo isset($select_result['CVS'])?$select_result['CVS']:""; ?>"  name="CVS"></td>
                </tr>
                <tr>
                  <td>CNS</td>
                  <td><input class="form-control" maxlength="20"  type="text" value="<?php echo isset($select_result['CNS'])?$select_result['CNS']:""; ?>"   name="CNS"></td>
                </tr>
                <tr>
                  <td>Abdominal</td>
                  <td><input class="form-control" maxlength="20"  type="text" value="<?php echo isset($select_result['abdominal'])?$select_result['abdominal']:""; ?>"   name="abdominal"></td>
                </tr>
                <tr>
                  <td>Others</td>
                  <td><input class="form-control" maxlength="100"  type="text" value="<?php echo isset($select_result['others'])?$select_result['others']:""; ?>"   name="others"></td>
                </tr>
              </table>
            </td>
            <td style="padding: 0;" colspan="2">
              <table width="100%">
                <tr>
                  <td>Written informed consent taken. All vitals  under normal range. 15 ml of venous blood was drawn from  Arthrex  Double syringe system, centrifuged by ACP centrifuge system for 10 min.</td>
                </tr>
                <tr>
                  <td>Patient put in lithotomy position ,under all sterile conditions, the vulva and vagina were cleansed by betadine and draped. A condom with lubricated jelly is put on the vaginal ultrasound probe,it is introduced transvaginally  ,a baseline transvaginal ultrasound performed to see endometrium and ovaries. Following baseline scan , a sterile Cuscos speculum /Sims speculum with tenaculum introduced .The cervix cleansed with betadine.An IUI catheter with 0.5 ml of prepared PRP(supernatant pellet ) put in the uterine cavity .The speculum is taken out.</td>
                </tr>
                <tr>
                  <td>No complications seen. Patient stood the procedure well.Till20 mins patient made to lie down</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
        <table class="table table-bordered table-hover table-sm red-field">
          <tr>
            <td colspan="2"><b>Post Procedure orders</b></td>
          </tr>
          <tr>
            <td>
              <label><input type="radio"   value="Yes"  <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "Yes"){echo 'checked="checked"'; }?>     name="normal_diet"> Yes</label>
              <label><input type="radio"    value="No"  <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['normal_diet']) && $select_result['normal_diet'] != "Yes"){echo 'checked="checked"';}?>   name="normal_diet"> No</label>
            </td>
            <td>Normal diet</td>
          </tr>
          <tr>
            <td>
              <label><input type="radio"   value="Yes"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "Yes"){echo 'checked="checked"'; }?>     name="tab_crocin"> Yes</label>
              <label><input type="radio"    value="No"  <?php if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_crocin']) && $select_result['tab_crocin'] != "Yes"){echo 'checked="checked"';}?>   name="tab_crocin"> No</label>
            </td>
            <td>Tab Crocin 500 mg (SOS) thrice daily eight hourly after meals for 1 days</td>
          </tr>
          <tr>
            <td>
              <label><input type="radio"   value="Yes"  <?php if(isset($select_result['other_medicines']) && $select_result['other_medicines'] == "Yes"){echo 'checked="checked"'; }?>     name="other_medicines"> Yes</label>
              <label><input type="radio"    value="No"  <?php if(isset($select_result['other_medicines']) && $select_result['other_medicines'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['other_medicines']) && $select_result['other_medicines'] != "Yes"){echo 'checked="checked"';}?>   name="other_medicines"> No</label>
            </td>
            <td>Keep taking other medicines as the pt is taking</td>
          </tr>
          <tr>
            <td>
              <label><input type="radio"   value="Yes"  <?php if(isset($select_result['report']) && $select_result['report'] == "Yes"){echo 'checked="checked"'; }?>     name="report"> Yes</label>
              <label><input type="radio"    value="No"  <?php if(isset($select_result['report']) && $select_result['report'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['report']) && $select_result['report'] != "Yes"){echo 'checked="checked"';}?>   name="report"> No</label>
            </td>
            <td>To report if giddiness /nausea/vomiting/bleeding/pain/fever /purulent discharge immediately</td>
          </tr>
          <tr>
            <td>Doctors signature</td>
            <td><input  type="text" value="<?php echo isset($select_result['doctor_signature'])?$select_result['doctor_signature']:""; ?>"   class="form" name="doctor_signature"></td>
          </tr>
        </table>
        </div>
          <!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
          <input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
</form>