<?php
    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        $select_query = "SELECT * FROM `intrauterine` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `intrauterine` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }       
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE intrauterine SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"    ;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

       if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `intrauterine` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
    $select_result = run_select_query($select_query);  
    
?>

<?php
    // php code to Insert data into mysql database from input text
  //   if(isset($_POST['submit'])){
  //       $patient_id = $_POST['patient_id'];
  //       $receipt_number = $_POST['receipt_number'];
  //       $status = $_POST['status'];
    
  //       // get values form input text and number
		// $date = $_POST['date'];
		// $time = $_POST['time'];
		// $indication = $_POST['indication'];
		// $allergy = $_POST['allergy'];
		// $consent = $_POST['consent'];
		// $id_checked = $_POST['id_checked'];
		// $bp = $_POST['bp'];
		// $pulse = $_POST['pulse'];
		// $resp = $_POST['resp'];
		// $ht = $_POST['ht'];
		// $wt = $_POST['wt'];
		// $contacts = $_POST['contacts'];
		// $denture = $_POST['denture'];
		// $dental_bridge = $_POST['dental_bridge'];
		// $valuables_with_escort = $_POST['valuables_with_escort'];
		// $last_meal = $_POST['last_meal'];
		// $Resp2 = $_POST['Resp2'];
		// $CVS = $_POST['CVS'];
		// $CNS = $_POST['CNS'];
		// $abdominal = $_POST['abdominal'];
		// $others = $_POST['others'];
		// $sperm_detail = $_POST['sperm_detail'];
  //       $doctor_signature = $_POST['doctor_signature'];
  //       $embryologist = $_POST['embryologist'];
  //       $doctor = $_POST['doctor'];
  //       $nurse = $_POST['nurse'];
  //       $voided = $_POST['voided'];
  //       $glasses = $_POST['glasses'];
  //       $pre_assessment_other = $_POST['pre_assessment_other'];
  //       $normal_diet = $_POST['normal_diet'];
  //       $tab_estrabet = $_POST['tab_estrabet'];
  //       $tab_duphaston = $_POST['tab_duphaston'];
  //       $tab_ecosprin = $_POST['tab_ecosprin'];
  //       $serum_beta = $_POST['serum_beta'];
  //       $medications_as_advised = $_POST['medications_as_advised'];
  //       $report = $_POST['report'];
  //       $partners_name2 = $_POST['partners_name2'];
  //       $art_bank_reg_no2 = $_POST['art_bank_reg_no2'];
  //       $form_id2 = $_POST['form_id2'];
  //       $donor_d2 = $_POST['donor_d2'];
  //       $date2_1 = $_POST['date2_1'];
  //       $date2_2 = $_POST['date2_2'];
  //       $date2_3 = $_POST['date2_3'];
  //       $date2_4 = $_POST['date2_4'];
  //       $date2_5 = $_POST['date2_5'];
  //       $date2_6 = $_POST['date2_6'];
  //       $date2_7 = $_POST['date2_7'];
  //       $date2_8 = $_POST['date2_8'];
  //       $date2_9 = $_POST['date2_9'];
  //       $date2_10 = $_POST['date2_10'];
  //       $date2_11 = $_POST['date2_11'];
  //       $date2_12 = $_POST['date2_12'];
  //       $date2_13 = $_POST['date2_13'];
  //       $date2_14 = $_POST['date2_14'];
  //       $date2_15 = $_POST['date2_15'];
  //       $follicle_size_rt2_1 = $_POST['follicle_size_rt2_1'];
  //       $follicle_size_rt2_2 = $_POST['follicle_size_rt2_2'];
  //       $follicle_size_rt2_3 = $_POST['follicle_size_rt2_3'];
  //       $follicle_size_rt2_4 = $_POST['follicle_size_rt2_4'];
  //       $follicle_size_rt2_5 = $_POST['follicle_size_rt2_5'];
  //       $follicle_size_rt2_6 = $_POST['follicle_size_rt2_6'];
  //       $follicle_size_rt2_7 = $_POST['follicle_size_rt2_7'];
  //       $follicle_size_rt2_8 = $_POST['follicle_size_rt2_8'];
  //       $follicle_size_rt2_9 = $_POST['follicle_size_rt2_9'];
  //       $follicle_size_rt2_10 = $_POST['follicle_size_rt2_10'];
  //       $follicle_size_rt2_11 = $_POST['follicle_size_rt2_11'];
  //       $follicle_size_rt2_12 = $_POST['follicle_size_rt2_12'];
  //       $follicle_size_rt2_13 = $_POST['follicle_size_rt2_13'];
  //       $follicle_size_rt2_14 = $_POST['follicle_size_rt2_14'];
  //       $follicle_size_rt2_15 = $_POST['follicle_size_rt2_15'];
  //       $follicle_size_lt2_1 = $_POST['follicle_size_lt2_1'];
  //       $follicle_size_lt2_2 = $_POST['follicle_size_lt2_2'];
  //       $follicle_size_lt2_3 = $_POST['follicle_size_lt2_3'];
  //       $follicle_size_lt2_4 = $_POST['follicle_size_lt2_4'];
  //       $follicle_size_lt2_5 = $_POST['follicle_size_lt2_5'];
  //       $follicle_size_lt2_6 = $_POST['follicle_size_lt2_6'];
  //       $follicle_size_lt2_7 = $_POST['follicle_size_lt2_7'];
  //       $follicle_size_lt2_8 = $_POST['follicle_size_lt2_8'];
  //       $follicle_size_lt2_9 = $_POST['follicle_size_lt2_9'];
  //       $follicle_size_lt2_10 = $_POST['follicle_size_lt2_10'];
  //       $follicle_size_lt2_11 = $_POST['follicle_size_lt2_11'];
  //       $follicle_size_lt2_12 = $_POST['follicle_size_lt2_12'];
  //       $follicle_size_lt2_13 = $_POST['follicle_size_lt2_13'];
  //       $follicle_size_lt2_14 = $_POST['follicle_size_lt2_14'];
  //       $follicle_size_lt2_15 = $_POST['follicle_size_lt2_15'];
  //       $endometrial_thickness2_1 = $_POST['endometrial_thickness2_1'];
  //       $endometrial_thickness2_2 = $_POST['endometrial_thickness2_2'];
  //       $endometrial_thickness2_3 = $_POST['endometrial_thickness2_3'];
  //       $endometrial_thickness2_4 = $_POST['endometrial_thickness2_4'];
  //       $endometrial_thickness2_5 = $_POST['endometrial_thickness2_5'];
  //       $endometrial_thickness2_6 = $_POST['endometrial_thickness2_6'];
  //       $endometrial_thickness2_7 = $_POST['endometrial_thickness2_7'];
  //       $endometrial_thickness2_8 = $_POST['endometrial_thickness2_8'];
  //       $endometrial_thickness2_9 = $_POST['endometrial_thickness2_9'];
  //       $endometrial_thickness2_10 = $_POST['endometrial_thickness2_10'];
  //       $endometrial_thickness2_11 = $_POST['endometrial_thickness2_11'];
  //       $endometrial_thickness2_12 = $_POST['endometrial_thickness2_12'];
  //       $endometrial_thickness2_13 = $_POST['endometrial_thickness2_13'];
  //       $endometrial_thickness2_14 = $_POST['endometrial_thickness2_14'];
  //       $endometrial_thickness2_15 = $_POST['endometrial_thickness2_15'];
  //       $inf_fsh_1 = $_POST['inf_fsh_1'];
  //       $inf_fsh_2 = $_POST['inf_fsh_2'];
  //       $inf_fsh_3 = $_POST['inf_fsh_3'];
  //       $inf_fsh_4 = $_POST['inf_fsh_4'];
  //       $inf_fsh_5 = $_POST['inf_fsh_5'];
  //       $inf_fsh_6 = $_POST['inf_fsh_6'];
  //       $inf_fsh_7 = $_POST['inf_fsh_7'];
  //       $inf_fsh_8 = $_POST['inf_fsh_8'];
  //       $inf_fsh_9 = $_POST['inf_fsh_9'];
  //       $inf_fsh_10 = $_POST['inf_fsh_10'];
  //       $inf_fsh_11 = $_POST['inf_fsh_11'];
  //       $inf_fsh_12 = $_POST['inf_fsh_12'];
  //       $inf_fsh_13 = $_POST['inf_fsh_13'];
  //       $inf_fsh_14 = $_POST['inf_fsh_14'];
  //       $inf_fsh_15 = $_POST['inf_fsh_15'];
  //       $hmg_1 = $_POST['hmg_1'];
  //       $hmg_2 = $_POST['hmg_2'];
  //       $hmg_3 = $_POST['hmg_3'];
  //       $hmg_4 = $_POST['hmg_4'];
  //       $hmg_5 = $_POST['hmg_5'];
  //       $hmg_6 = $_POST['hmg_6'];
  //       $hmg_7 = $_POST['hmg_7'];
  //       $hmg_8 = $_POST['hmg_8'];
  //       $hmg_9 = $_POST['hmg_9'];
  //       $hmg_10 = $_POST['hmg_10'];
  //       $hmg_11 = $_POST['hmg_11'];
  //       $hmg_12 = $_POST['hmg_12'];
  //       $hmg_13 = $_POST['hmg_13'];
  //       $hmg_14 = $_POST['hmg_14'];
  //       $hmg_15 = $_POST['hmg_15'];
  //       $antagonist_1 = $_POST['antagonist_1'];
  //       $antagonist_2 = $_POST['antagonist_2'];
  //       $antagonist_3 = $_POST['antagonist_3'];
  //       $antagonist_4 = $_POST['antagonist_4'];
  //       $antagonist_5 = $_POST['antagonist_5'];
  //       $antagonist_6 = $_POST['antagonist_6'];
  //       $antagonist_7 = $_POST['antagonist_7'];
  //       $antagonist_8 = $_POST['antagonist_8'];
  //       $antagonist_9 = $_POST['antagonist_9'];
  //       $antagonist_10 = $_POST['antagonist_10'];
  //       $antagonist_11 = $_POST['antagonist_11'];
  //       $antagonist_12 = $_POST['antagonist_12'];
  //       $antagonist_13 = $_POST['antagonist_13'];
  //       $antagonist_14 = $_POST['antagonist_14'];
  //       $antagonist_15 = $_POST['antagonist_15'];
  //       $hcg2_1 = $_POST['hcg2_1'];
  //       $hcg2_2 = $_POST['hcg2_2'];
  //       $hcg2_3 = $_POST['hcg2_3'];
  //       $hcg2_4 = $_POST['hcg2_4'];
  //       $hcg2_5 = $_POST['hcg2_5'];
  //       $hcg2_6 = $_POST['hcg2_6'];
  //       $hcg2_7 = $_POST['hcg2_7'];
  //       $hcg2_8 = $_POST['hcg2_8'];
  //       $hcg2_9 = $_POST['hcg2_9'];
  //       $hcg2_10 = $_POST['hcg2_10'];
  //       $hcg2_11 = $_POST['hcg2_11'];
  //       $hcg2_12 = $_POST['hcg2_12'];
  //       $hcg2_13 = $_POST['hcg2_13'];
  //       $hcg2_14 = $_POST['hcg2_14'];
  //       $hcg2_15 = $_POST['hcg2_15'];
  //       $medicine_added2_1 = $_POST['medicine_added2_1'];
  //       $medicine_added2_2 = $_POST['medicine_added2_2'];
  //       $medicine_added2_3 = $_POST['medicine_added2_3'];
  //       $medicine_added2_4 = $_POST['medicine_added2_4'];
  //       $medicine_added2_5 = $_POST['medicine_added2_5'];
  //       $medicine_added2_6 = $_POST['medicine_added2_6'];
  //       $medicine_added2_7 = $_POST['medicine_added2_7'];
  //       $medicine_added2_8 = $_POST['medicine_added2_8'];
  //       $medicine_added2_9 = $_POST['medicine_added2_9'];
  //       $medicine_added2_10 = $_POST['medicine_added2_10'];
  //       $medicine_added2_11 = $_POST['medicine_added2_11'];
  //       $medicine_added2_12 = $_POST['medicine_added2_12'];
  //       $medicine_added2_13 = $_POST['medicine_added2_13'];
  //       $medicine_added2_14 = $_POST['medicine_added2_14'];
  //       $medicine_added2_15 = $_POST['medicine_added2_15'];
  //       $remarks2_1 = $_POST['remarks2_1'];
  //       $remarks2_2 = $_POST['remarks2_2'];
  //       $remarks2_3 = $_POST['remarks2_3'];
  //       $remarks2_4 = $_POST['remarks2_4'];
  //       $remarks2_5 = $_POST['remarks2_5'];
  //       $remarks2_6 = $_POST['remarks2_6'];
  //       $remarks2_7 = $_POST['remarks2_7'];
  //       $remarks2_8 = $_POST['remarks2_8'];
  //       $remarks2_9 = $_POST['remarks2_9'];
  //       $remarks2_10 = $_POST['remarks2_10'];
  //       $remarks2_11 = $_POST['remarks2_11'];
  //       $remarks2_12 = $_POST['remarks2_12'];
  //       $remarks2_13 = $_POST['remarks2_13'];
  //       $remarks2_14 = $_POST['remarks2_14'];
  //       $remarks2_15 = $_POST['remarks2_15'];
  //       $follow_up2_1 = $_POST['follow_up2_1'];
  //       $follow_up2_2 = $_POST['follow_up2_2'];
  //       $follow_up2_3 = $_POST['follow_up2_3'];
  //       $follow_up2_4 = $_POST['follow_up2_4'];
  //       $follow_up2_5 = $_POST['follow_up2_5'];
  //       $follow_up2_6 = $_POST['follow_up2_6'];
  //       $follow_up2_7 = $_POST['follow_up2_7'];
  //       $follow_up2_8 = $_POST['follow_up2_8'];
  //       $follow_up2_9 = $_POST['follow_up2_9'];
  //       $follow_up2_10 = $_POST['follow_up2_10'];
  //       $follow_up2_11 = $_POST['follow_up2_11'];
  //       $follow_up2_12 = $_POST['follow_up2_12'];
  //       $follow_up2_13 = $_POST['follow_up2_13'];
  //       $follow_up2_14 = $_POST['follow_up2_14'];
  //       $follow_up2_15 = $_POST['follow_up2_15'];
  //       $estradoil2_1 = $_POST['estradoil2_1'];
  //       $estradoil2_2 = $_POST['estradoil2_2'];
  //       $estradoil2_3 = $_POST['estradoil2_3'];
  //       $estradoil2_4 = $_POST['estradoil2_4'];
  //       $estradoil2_5 = $_POST['estradoil2_5'];
  //       $estradoil2_6 = $_POST['estradoil2_6'];
  //       $estradoil2_7 = $_POST['estradoil2_7'];
  //       $estradoil2_8 = $_POST['estradoil2_8'];
  //       $estradoil2_9 = $_POST['estradoil2_9'];
  //       $estradoil2_10 = $_POST['estradoil2_10'];
  //       $estradoil2_11 = $_POST['estradoil2_11'];
  //       $estradoil2_12 = $_POST['estradoil2_12'];
  //       $estradoil2_13 = $_POST['estradoil2_13'];
  //       $estradoil2_14 = $_POST['estradoil2_14'];
  //       $estradoil2_15 = $_POST['estradoil2_15'];
  //       $progesterone2_1 = $_POST['progesterone2_1'];
  //       $progesterone2_2 = $_POST['progesterone2_2'];
  //       $progesterone2_3 = $_POST['progesterone2_3'];
  //       $progesterone2_4 = $_POST['progesterone2_4'];
  //       $progesterone2_5 = $_POST['progesterone2_5'];
  //       $progesterone2_6 = $_POST['progesterone2_6'];
  //       $progesterone2_7 = $_POST['progesterone2_7'];
  //       $progesterone2_8 = $_POST['progesterone2_8'];
  //       $progesterone2_9 = $_POST['progesterone2_9'];
  //       $progesterone2_10 = $_POST['progesterone2_10'];
  //       $progesterone2_11 = $_POST['progesterone2_11'];
  //       $progesterone2_12 = $_POST['progesterone2_12'];
  //       $progesterone2_13 = $_POST['progesterone2_13'];
  //       $progesterone2_14 = $_POST['progesterone2_14'];
  //       $progesterone2_15 = $_POST['progesterone2_15'];
  //       $doctor2 = $_POST['doctor2'];
  //       $counsellor2 = $_POST['counsellor2'];
  //       $nurse2 = $_POST['nurse2'];

        // connect to mysql database using mysqli
        

        // mysql query to insert data
        //$query = "INSERT INTO `intrauterine`(`patient_id`, `receipt_number`, `status`,`date`,`time`,`indication`,`allergy`,`consent`,`id_checked`,`bp`,`pulse`,`resp`,`ht`,`wt`,`contacts`,`denture`,`dental_bridge`,`valuables_with_escort`,`last_meal`,`Resp2`,`CVS`,`CNS`,`abdominal`,`others`,`sperm_detail`,`doctor_signature`,`embryologist`,`doctor`,`nurse`,`voided`,`glasses`,`pre_assessment_other`,`normal_diet`,`tab_estrabet`,`tab_duphaston`,`tab_ecosprin`,`serum_beta`,`medications_as_advised`,`report`,`partners_name2`,`art_bank_reg_no2`,`form_id2`,`donor_d2`,`date2_1`,`date2_2`,`date2_3`,`date2_4`,`date2_5`,`date2_6`,`date2_7`,`date2_8`,`date2_9`,`date2_10`,`date2_11`,`date2_12`,`date2_13`,`date2_14`,`date2_15`,`follicle_size_rt2_1`,`follicle_size_rt2_2`,`follicle_size_rt2_3`,`follicle_size_rt2_4`,`follicle_size_rt2_5`,`follicle_size_rt2_6`,`follicle_size_rt2_7`,`follicle_size_rt2_8`,`follicle_size_rt2_9`,`follicle_size_rt2_10`,`follicle_size_rt2_11`,`follicle_size_rt2_12`,`follicle_size_rt2_13`,`follicle_size_rt2_14`,`follicle_size_rt2_15`,`follicle_size_lt2_1`,`follicle_size_lt2_2`,`follicle_size_lt2_3`,`follicle_size_lt2_4`,`follicle_size_lt2_5`,`follicle_size_lt2_6`,`follicle_size_lt2_7`,`follicle_size_lt2_8`,`follicle_size_lt2_9`,`follicle_size_lt2_10`,`follicle_size_lt2_11`,`follicle_size_lt2_12`,`follicle_size_lt2_13`,`follicle_size_lt2_14`,`follicle_size_lt2_15`,`endometrial_thickness2_1`,`endometrial_thickness2_2`,`endometrial_thickness2_3`,`endometrial_thickness2_4`,`endometrial_thickness2_5`,`endometrial_thickness2_6`,`endometrial_thickness2_7`,`endometrial_thickness2_8`,`endometrial_thickness2_9`,`endometrial_thickness2_10`,`endometrial_thickness2_11`,`endometrial_thickness2_12`,`endometrial_thickness2_13`,`endometrial_thickness2_14`,`endometrial_thickness2_15`,`inf_fsh_1`,`inf_fsh_2`,`inf_fsh_3`,`inf_fsh_4`,`inf_fsh_5`,`inf_fsh_6`,`inf_fsh_7`,`inf_fsh_8`,`inf_fsh_9`,`inf_fsh_10`,`inf_fsh_11`,`inf_fsh_12`,`inf_fsh_13`,`inf_fsh_14`,`inf_fsh_15`,`hmg_1`,`hmg_2`,`hmg_3`,`hmg_4`,`hmg_5`,`hmg_6`,`hmg_7`,`hmg_8`,`hmg_9`,`hmg_10`,`hmg_11`,`hmg_12`,`hmg_13`,`hmg_14`,`hmg_15`,`antagonist_1`,`antagonist_2`,`antagonist_3`,`antagonist_4`,`antagonist_5`,`antagonist_6`,`antagonist_7`,`antagonist_8`,`antagonist_9`,`antagonist_10`,`antagonist_11`,`antagonist_12`,`antagonist_13`,`antagonist_14`,`antagonist_15`,`hcg2_1`,`hcg2_2`,`hcg2_3`,`hcg2_4`,`hcg2_5`,`hcg2_6`,`hcg2_7`,`hcg2_8`,`hcg2_9`,`hcg2_10`,`hcg2_11`,`hcg2_12`,`hcg2_13`,`hcg2_14`,`hcg2_15`,`medicine_added2_1`,`medicine_added2_2`,`medicine_added2_3`,`medicine_added2_4`,`medicine_added2_5`,`medicine_added2_6`,`medicine_added2_7`,`medicine_added2_8`,`medicine_added2_9`,`medicine_added2_10`,`medicine_added2_11`,`medicine_added2_12`,`medicine_added2_13`,`medicine_added2_14`,`medicine_added2_15`,`remarks2_1`,`remarks2_2`,`remarks2_3`,`remarks2_4`,`remarks2_5`,`remarks2_6`,`remarks2_7`,`remarks2_8`,`remarks2_9`,`remarks2_10`,`remarks2_11`,`remarks2_12`,`remarks2_13`,`remarks2_14`,`remarks2_15`,`follow_up2_1`,`follow_up2_2`,`follow_up2_3`,`follow_up2_4`,`follow_up2_5`,`follow_up2_6`,`follow_up2_7`,`follow_up2_8`,`follow_up2_9`,`follow_up2_10`,`follow_up2_11`,`follow_up2_12`,`follow_up2_13`,`follow_up2_14`,`follow_up2_15`,`estradoil2_1`,`estradoil2_2`,`estradoil2_3`,`estradoil2_4`,`estradoil2_5`,`estradoil2_6`,`estradoil2_7`,`estradoil2_8`,`estradoil2_9`,`estradoil2_10`,`estradoil2_11`,`estradoil2_12`,`estradoil2_13`,`estradoil2_14`,`estradoil2_15`,`progesterone2_1`,`progesterone2_2`,`progesterone2_3`,`progesterone2_4`,`progesterone2_5`,`progesterone2_6`,`progesterone2_7`,`progesterone2_8`,`progesterone2_9`,`progesterone2_10`,`progesterone2_11`,`progesterone2_12`,`progesterone2_13`,`progesterone2_14`,`progesterone2_15`,`doctor2`,`counsellor2`,`nurse2`) VALUES ('$patient_id','$receipt_number','$status','$date','$time','$indication','$allergy','$consent','$id_checked','$bp','$pulse','$resp','$ht','$wt','$contacts','$denture','$dental_bridge','$valuables_with_escort','$last_meal','$Resp2','$CVS','$CNS','$abdominal','$others','$sperm_detail','$doctor_signature','$embryologist','$doctor','$nurse','$voided','$glasses','$pre_assessment_other','$normal_diet','$tab_estrabet','$tab_duphaston','$tab_ecosprin','$serum_beta','$medications_as_advised','$report','$partners_name2','$art_bank_reg_no2','$form_id2','$donor_d2','$date2_1','$date2_2','$date2_3','$date2_4','$date2_5','$date2_6','$date2_7','$date2_8','$date2_9','$date2_10','$date2_11','$date2_12','$date2_13','$date2_14','$date2_15','$follicle_size_rt2_1','$follicle_size_rt2_2','$follicle_size_rt2_3','$follicle_size_rt2_4','$follicle_size_rt2_5','$follicle_size_rt2_6','$follicle_size_rt2_7','$follicle_size_rt2_8','$follicle_size_rt2_9','$follicle_size_rt2_10','$follicle_size_rt2_11','$follicle_size_rt2_12','$follicle_size_rt2_13','$follicle_size_rt2_14','$follicle_size_rt2_15','$follicle_size_lt2_1','$follicle_size_lt2_2','$follicle_size_lt2_3','$follicle_size_lt2_4','$follicle_size_lt2_5','$follicle_size_lt2_6','$follicle_size_lt2_7','$follicle_size_lt2_8','$follicle_size_lt2_9','$follicle_size_lt2_10','$follicle_size_lt2_11','$follicle_size_lt2_12','$follicle_size_lt2_13','$follicle_size_lt2_14','$follicle_size_lt2_15','$endometrial_thickness2_1','$endometrial_thickness2_2','$endometrial_thickness2_3','$endometrial_thickness2_4','$endometrial_thickness2_5','$endometrial_thickness2_6','$endometrial_thickness2_7','$endometrial_thickness2_8','$endometrial_thickness2_9','$endometrial_thickness2_10','$endometrial_thickness2_11','$endometrial_thickness2_12','$endometrial_thickness2_13','$endometrial_thickness2_14','$endometrial_thickness2_15','$inf_fsh_1','$inf_fsh_2','$inf_fsh_3','$inf_fsh_4','$inf_fsh_5','$inf_fsh_6','$inf_fsh_7','$inf_fsh_8','$inf_fsh_9','$inf_fsh_10','$inf_fsh_11','$inf_fsh_12','$inf_fsh_13','$inf_fsh_14','$inf_fsh_15','$hmg_1','$hmg_2','$hmg_3','$hmg_4','$hmg_5','$hmg_6','$hmg_7','$hmg_8','$hmg_9','$hmg_10','$hmg_11','$hmg_12','$hmg_13','$hmg_14','$hmg_15','$antagonist_1','$antagonist_2','$antagonist_3','$antagonist_4','$antagonist_5','$antagonist_6','$antagonist_7','$antagonist_8','$antagonist_9','$antagonist_10','$antagonist_11','$antagonist_12','$antagonist_13','$antagonist_14','$antagonist_15','$hcg2_1','$hcg2_2','$hcg2_3','$hcg2_4','$hcg2_5','$hcg2_6','$hcg2_7','$hcg2_8','$hcg2_9','$hcg2_10','$hcg2_11','$hcg2_12','$hcg2_13','$hcg2_14','$hcg2_15','$medicine_added2_1','$medicine_added2_2','$medicine_added2_3','$medicine_added2_4','$medicine_added2_5','$medicine_added2_6','$medicine_added2_7','$medicine_added2_8','$medicine_added2_9','$medicine_added2_10','$medicine_added2_11','$medicine_added2_12','$medicine_added2_13','$medicine_added2_14','$medicine_added2_15','$remarks2_1','$remarks2_2','$remarks2_3','$remarks2_4','$remarks2_5','$remarks2_6','$remarks2_7','$remarks2_8','$remarks2_9','$remarks2_10','$remarks2_11','$remarks2_12','$remarks2_13','$remarks2_14','$remarks2_15','$follow_up2_1','$follow_up2_2','$follow_up2_3','$follow_up2_4','$follow_up2_5','$follow_up2_6','$follow_up2_7','$follow_up2_8','$follow_up2_9','$follow_up2_10','$follow_up2_11','$follow_up2_12','$follow_up2_13','$follow_up2_14','$follow_up2_15','$estradoil2_1','$estradoil2_2','$estradoil2_3','$estradoil2_4','$estradoil2_5','$estradoil2_6','$estradoil2_7','$estradoil2_8','$estradoil2_9','$estradoil2_10','$estradoil2_11','$estradoil2_12','$estradoil2_13','$estradoil2_14','$estradoil2_15','$progesterone2_1','$progesterone2_2','$progesterone2_3','$progesterone2_4','$progesterone2_5','$progesterone2_6','$progesterone2_7','$progesterone2_8','$progesterone2_9','$progesterone2_10','$progesterone2_11','$progesterone2_12','$progesterone2_13','$progesterone2_14','$progesterone2_15','$doctor2','$counsellor2','$nurse2')";
  
    //     $result = run_form_query($query);

    //     if($result){
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
				// 	die();
    //     }else{
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
				// 	die();
    //     }
    // }
?>

<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
  <input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
  <input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
  <input type="hidden" value="pending" name="status"> 
    <div class="container red-field form mt-5 mb-5">
        <ul class="d-flex mb-1 mt-2 list-unstyled">
        <div class="table-responsive">
        <table class="table table-bordered table-hover mt-2 table-sm red-field tableMg">
            <thead>
                <tr>
                    <td colspan="2"><h2>IUI CYCLE OVULATION INDUCTION PROTOCOL</h2></td>
                    <td colspan="2">
        			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
        			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
        			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
        			            ){?>
        			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
        			    <?php } ?>
        			</td>
                </tr>
            </thead>
            <table class="table table-bordered table-hover mt-2 table-sm tableMg">
                <thead>
                    <tr>
                        <th style="color: red;"><h2>SELF CYCLE  (S)</h2></th>
                        <th><h2>DONOR CYCLE (D)</h2></th>
                    </tr>
                </thead>
            </table>
                <ul class="d-flex mb-1 mt-2 list-unstyled">
                <div class = "table-responsive">
                    <table class="table table-bordered table-hover table-sm">
                    <thead>
                        <tr>
                        <th style="color: red;"><strong>Partners name</strong></th>
                        <th><input type="text" value="<?php echo isset($select_result['partners_name2'])?$select_result['partners_name2']:""; ?>" maxlength="20" class="form" name="partners_name2"></th>
                        <th><strong>ART bank reg no</strong></th>
                        <th><input type="text" value="<?php echo isset($select_result['art_bank_reg_no2'])?$select_result['art_bank_reg_no2']:""; ?>" maxlength="20" class="form" name="art_bank_reg_no2"></th>
                        </tr>
                    </thead>
                  <thead>
                    <tr>
                      <th style="color: red;"><strong>ID</strong></th>
                      <th><input type="text" value="<?php echo isset($select_result['form_id2'])?$select_result['form_id2']:""; ?>" maxlength="20" class="form" name="form_id2"></th>
                      <th><strong>Donor ID</strong></th>
                      <th><input type="text" value="<?php echo isset($select_result['donor_d2'])?$select_result['donor_d2']:""; ?>" maxlength="20" class="form" name="donor_d2"></th>
                    </tr>
                  </thead>
            </table>
            </div>
        </ul>
        <table class="table table-bordered table-hover  table-sm red-field tableMg">
            <thead>
                <tr>
                    <td>LAST MENSTRUAL PERIOD</td>
                    <td><input type="date" class="form" value="<?php echo isset($select_result['last_menstrual_period2'])?$select_result['last_menstrual_period2']:""; ?>" name="last_menstrual_period2"></td>
                </tr>
            </thead>
        </table>
        <div class = "table-responsive">
        <table class="table table-bordered table-hover  table-sm red-field tableMg">
            <thead>
                        <tr>
                        <th><strong>Day of Stimulation</strong></th>
                        <th>1</th>
                        <th>2</th>
                        <th>3</th>
                        <th>4</th>
                        <th>5</th>
                        <th>6</th>
                        <th>7</th>
                        <th>8</th>
                        <th>9</th>
                        <th>10</th>
                        <th>11</th>
                        <th>12</th>
                        <th>13</th>
                        <th>14</th>
                        <th>15</th>
                        </tr>
                    </thead>
                <tbody>
                    <tr>
                    <td>DATE</td>
                    <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['date2_'.$i])) {$value = $select_result['date2_'.$i]; }
                        echo '<td><input type="date" class="form" value="'.$value.'" name="date2_'.$i.'"></td>';
                        }
                        ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>FOLLICLE SIZE RT (cm)</td>
                      <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['follicle_size_rt2_'.$i])) {$value = $select_result['follicle_size_rt2_'.$i]; }
                        echo '<td><input type="number" min="0" class="form" value="'.$value.'" name="follicle_size_rt2_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                    <td>FOLLICLE SIZE LT (cm)</td>
                      <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['follicle_size_lt2_'.$i])) {$value = $select_result['follicle_size_lt2_'.$i]; }
                        echo '<td><input type="number" min="0" class="form" value="'.$value.'" name="follicle_size_lt2_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                        <td>ENDOMETRIAL THICKNESS (cm)</td>
                        <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['endometrial_thickness2_'.$i])) {$value = $select_result['endometrial_thickness2_'.$i]; }
                            echo '<td><input type="number" min="0" class="form" value="'.$value.'" name="endometrial_thickness2_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                        <td>INJECTION DOSE: FSH</td>
                        <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['inf_fsh_'.$i])) {$value = $select_result['inf_fsh_'.$i]; }
                            echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="inf_fsh_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>HMG</td>
                    <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['hmg_'.$i])) {$value = $select_result['hmg_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="hmg_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>ANTAGONIST</td>
                    <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['antagonist_'.$i])) {$value = $select_result['antagonist_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="antagonist_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                    <td>HCG(TRIGGER)</td>
                      <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['hcg2_'.$i])) {$value = $select_result['hcg2_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="hcg2_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>MEDICINE ADDED</td>
                      <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['medicine_added2_'.$i])) {$value = $select_result['medicine_added2_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="medicine_added2_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>REMARKS</td>
                      <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['remarks2_'.$i])) {$value = $select_result['remarks2_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="remarks2_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                    <td>FOLLOWUP ON</td>
                    <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['follow_up2_'.$i])) {$value = $select_result['follow_up2_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="follow_up2_'.$i.'"></td>';
                        }
                      ?>
                      
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                    <td>SERUM ESTRADIOL (E2) LEVEL</td>
                      <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['estradoil2_'.$i])) {$value = $select_result['estradoil2_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="estradoil2_'.$i.'"></td>';
                        }
                      ?>
                      
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>SERUM PROGESTERONE LEVEL</td>
                      <?php for($i=1;$i<=15;$i++){
                            $value=""; if(isset($select_result['progesterone2_'.$i])) {$value = $select_result['progesterone2_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" value="'.$value.'" name="progesterone2_'.$i.'"></td>';
                        }
                      ?>
                    </tr>
                  </tbody>
        </table>
        </div>
        <table class="table table-bordered table-hover  table-sm red-field tableMg">
            <thead>
                <tr>
                    <th>DOCTOR <input type="text" value="<?php echo isset($select_result['doctor2'])?$select_result['doctor2']:""; ?>" class="form" name="doctor2"></th>
                    <th>COUNSELLOR <input type="text" value="<?php echo isset($select_result['counsellor2'])?$select_result['counsellor2']:""; ?>" class="form" name="counsellor2"></th>
                    <th>NURSE <input type="text" value="<?php echo isset($select_result['nurse2'])?$select_result['nurse2']:""; ?>" class="form" name="nurse2"></th>
                </tr>
            </thead>
        </table>
                  <table class="table table-bordered table-hover table-sm">
                    <thead>
                      <tr style="color: red;">
                        <td><strong>INTRAUTERINE INSEMINATION</strong></td>
                        <td>Date <input type="date" value="<?php echo isset($select_result['date'])?$select_result['date']:""; ?>" class="form-control" name="date"></td>
                        <td>Time <input type="time" value="<?php echo isset($select_result['time'])?$select_result['time']:""; ?>" class="form-control" name="time"></td>
                        <td>Indication <input type="text" value="<?php echo isset($select_result['indication'])?$select_result['indication']:""; ?>" maxlength="50" class="form-control" name="indication"></td>
                        <td>ALLERGIES <input type="text" value="<?php echo isset($select_result['allergy'])?$select_result['allergy']:""; ?>" maxlength="50" class="form-control" name="allergy"></td>
                        <td>
                            Consent<br>
                            <label><input type="radio"  name="consent" value="yes" <?php if(isset($select_result['consent']) && $select_result['consent'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="consent" value="No" <?php if(isset($select_result['consent']) && $select_result['consent'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['consent']) && $select_result['consent'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>
                            ID checked<br>
                            <label><input type="radio"  name="id_checked" value="yes" <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="id_checked" value="No" <?php if(isset($select_result['id_checked']) && $select_result['id_checked'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['id_checked']) && $select_result['id_checked'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                      </tr>
                      <tr style="color: red;">
                        <td><strong>PRE ASSESSMENT</strong></td>
                        <td>BP <input type="text" value="<?php echo isset($select_result['bp'])?$select_result['bp']:""; ?>" maxlength="20" class="form-control" name="bp"></td>
                        <td>
                            PULSE<br>
                            <label><input type="radio"  name="pulse" value="yes" <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="pulse" value="No" <?php if(isset($select_result['pulse']) && $select_result['pulse'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['pulse']) && $select_result['pulse'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>
                            RESP<br>
                            <label><input type="radio"  name="resp" value="yes" <?php if(isset($select_result['resp']) && $select_result['resp'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="resp" value="No" <?php if(isset($select_result['resp']) && $select_result['resp'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['resp']) && $select_result['resp'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>
                            voided<br>
                            <label><input type="radio"  name="voided" value="yes" <?php if(isset($select_result['voided']) && $select_result['voided'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="voided" value="No" <?php if(isset($select_result['voided']) && $select_result['voided'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['voided']) && $select_result['voided'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>HT (Cms)<input type="number" min="0" class="form-control" value="<?php echo isset($select_result['ht'])?$select_result['ht']:""; ?>" maxlength="20" name="ht"></td>
                        <td>WT (Kg)<input type="number" min="0" class="form-control" value="<?php echo isset($select_result['wt'])?$select_result['wt']:""; ?>" maxlength="20" name="wt"></td>
                      </tr>
                      <tr>
                        <td>
                            Glasses<br>
                            <label><input type="radio"  name="glasses" value="yes" <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="glasses" value="No" <?php if(isset($select_result['glasses']) && $select_result['glasses'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['glasses']) && $select_result['glasses'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>
                            Contacts<br>
                            <label><input type="radio"  name="contacts" value="yes" <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="contacts" value="No" <?php if(isset($select_result['contacts']) && $select_result['contacts'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['contacts']) && $select_result['contacts'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>
                            Denture<br>
                            <label><input type="radio"  name="denture" value="yes" <?php if(isset($select_result['denture']) && $select_result['denture'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="denture" value="No" <?php if(isset($select_result['denture']) && $select_result['denture'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['denture']) && $select_result['denture'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td colspan="2">
                            Dental bridge<br>
                            <label><input type="radio"  name="dental_bridge" value="yes" <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="dental_bridge" value="No" <?php if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['dental_bridge']) && $select_result['dental_bridge'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>
                            Valuables with escort<br>
                            <label><input type="radio"  name="valuables_with_escort" value="yes" <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                            <label><input type="radio"  name="valuables_with_escort" value="No" <?php if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['valuables_with_escort']) && $select_result['valuables_with_escort'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                        </td>
                        <td>Last meal <input type="time" value="<?php echo isset($select_result['last_meal'])?$select_result['last_meal']:""; ?>" class="form-control" name="last_meal"></td>
                      </tr>
                      <tr style="color: red;">
                        <th colspan="7">
                          <strong>PRE ASSESSMENT</strong>
                        </th>
                      </tr>
                      <tr style="color: red;">
                        <td colspan="7">
                            No active vaginal infection<br>
                            Other <input type="text" value="<?php echo isset($select_result['pre_assessment_other'])?$select_result['pre_assessment_other']:""; ?>" maxlength="100" class="form-control" name="pre_assessment_other">
                        </td>
                      </tr>
                    </thead>
                  </table>
            </div>
        </ul>
        <div class = "table-responsive">
        <table class="table table-bordered table-hover  table-sm red-field tableMg">
            <thead>
                <tr>
                    <th>NURSE <input type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>" maxlength="20" name="nurse"></th>
                    <th>DOCTOR <input type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>" maxlength="20" name="doctor"></th>
                    <th>Embryologist <input type="text" value="<?php echo isset($select_result['embryologist'])?$select_result['embryologist']:""; ?>" maxlength="20" name="embryologist"></th>
                </tr>
            </thead>
        </table>
        <table class="table table-bordered table-hover  table-sm red-field tableMg">
            <thead>
                <tr>
                    <th><ul class = "list-unstyled">
                            <li class="d-flex mb-1 mt-2 "><span>Physical Examination</span></li> 
                            <li class="d-flex mb-1 ml-4"><span class= "mr-5 ">Resp</span> <input type="text" value="<?php echo isset($select_result['Resp2'])?$select_result['Resp2']:""; ?>" class="form" name="Resp2"></li> 
                            <li class="d-flex mb-1 ml-4"><span class= "mr-5 ml-1 ">CVS</span> <input type="text" value="<?php echo isset($select_result['CVS'])?$select_result['CVS']:""; ?>" class="form" name="CVS"></li> 
                            <li class="d-flex mb-1 ml-4"><span class= "mr-5 ml-1 ">CNS</span> <input type="text" value="<?php echo isset($select_result['CNS'])?$select_result['CNS']:""; ?>" class="form" name="CNS"></li>
                            <li class="d-flex mb-1"><span class= "mr-4 ">Abdominal</span> <input type="text" value="<?php echo isset($select_result['abdominal'])?$select_result['abdominal']:""; ?>" class="form" name="abdominal"></li>
                            <li class="d-flex mb-1 ml-2"><span class= "mr-5 ">Others</span> <input type="text" value="<?php echo isset($select_result['others'])?$select_result['others']:""; ?>" class="form" name="others"></li>
                        </ul>
                    </th>
                    <th>
                        <p>
                            Written informed consent taken. All vitals checked under normal range. Patient put in lithotomy position ,under all sterile conditions, the vulva and vagina were cleansed by normal saline  and draped.A baseline transabdominal ultrasound performed to see endometrium and ovaries. Following baseline scan , a sterile Cuscos speculum /Sims speculum with tenaculum introduced .The cervix cleansed with normal saline .An IUI catheter with 0.5 ml of prepared sperm sample  put in the uterine cavity .The speculum is taken out . No complications seen. Patient stood the procedure well.Till20 mins patient made to lie down
                        </p>
                        <!-- <p>Written informed consent taken . All vitals checked under normal range.  15 ml of venous blood was drawn from  Arthrex  Double syringe system ,  centrifuged by ACP centrifuge system for 10 min.  
                            Patient put in lithotomy position ,under all sterile conditions, the vulva and vagina were cleansed by betadine and draped. A condom with lubricated jelly is put on the vaginal ultrasound probe,it is introduced transvaginally  ,a baseline transvaginal ultrasound performed to see endometrium and ovaries. Following baseline scan , a sterile Cuscos speculum /Sims speculum with tenaculum introduced .The cervix cleansed with betadine.An IUI catheter with 0.5 ml of prepared PRP(supernatant pellet ) put in the uterine cavity .The speculum is taken out .
                            No complications seen. Patient stood the procedure well.Till20 mins patient made to lie down </p> -->
                    </th>
                </tr>
            </thead>
            <thead>
                <tr>
                    <th><p class="d-flex p-2"><span>SPERM DETAIL</span><input type="text" class="form" name="sperm_detail" value="<?php echo isset($select_result['sperm_detail'])?$select_result['sperm_detail']:""; ?>"></p></th>
                    <th><a href="sperm_preparation.php">SEMEN PREPERATION CHART</a></th>
                </tr>
            </thead>
        </table>
        <table class="table table-bordered table-hover  mb-2 table-sm red-field tableMg">
            <thead>
                <tr><th colspan="2">Post Procedure orders</th></tr>
                <tr>
                    <td>
                        <label><input type="radio"  name="normal_diet" value="yes" <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                        <label><input type="radio"  name="normal_diet" value="No" <?php if(isset($select_result['normal_diet']) && $select_result['normal_diet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['normal_diet']) && $select_result['normal_diet'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Normal diet</td>
                </tr>
                <tr>
                    <td>
                        <label><input type="radio"  name="tab_estrabet" value="yes" <?php if(isset($select_result['tab_estrabet']) && $select_result['tab_estrabet'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                        <label><input type="radio"  name="tab_estrabet" value="No" <?php if(isset($select_result['tab_estrabet']) && $select_result['tab_estrabet'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_estrabet']) && $select_result['tab_estrabet'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Tab estrabet 2 mg twice/ thrice/four times  daily after meals for 16 days</td>
                </tr>
                <tr>
                    <td>
                        <label><input type="radio"  name="tab_duphaston" value="yes" <?php if(isset($select_result['tab_duphaston']) && $select_result['tab_duphaston'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                        <label><input type="radio"  name="tab_duphaston" value="No" <?php if(isset($select_result['tab_duphaston']) && $select_result['tab_duphaston'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_duphaston']) && $select_result['tab_duphaston'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Tab Duphaston 10 mg three times daily after meals for 16 days</td>
                </tr>
                <tr>
                    <td>
                        <label><input type="radio"  name="tab_ecosprin" value="yes" <?php if(isset($select_result['tab_ecosprin']) && $select_result['tab_ecosprin'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                        <label><input type="radio"  name="tab_ecosprin" value="No" <?php if(isset($select_result['tab_ecosprin']) && $select_result['tab_ecosprin'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['tab_ecosprin']) && $select_result['tab_ecosprin'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Tab ecosprin 75 mg once daily for 16 days</td>
                </tr>
                <tr>
                    <td>
                        <label><input type="radio"  name="serum_beta" value="yes" <?php if(isset($select_result['serum_beta']) && $select_result['serum_beta'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                        <label><input type="radio"  name="serum_beta" value="No" <?php if(isset($select_result['serum_beta']) && $select_result['serum_beta'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['serum_beta']) && $select_result['serum_beta'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Serum beta hcg after 15 days</td>
                </tr>
                <tr>
                    <td>
                        <label><input type="radio"  name="medications_as_advised" value="yes" <?php if(isset($select_result['medications_as_advised']) && $select_result['medications_as_advised'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                        <label><input type="radio"  name="medications_as_advised" value="No" <?php if(isset($select_result['medications_as_advised']) && $select_result['medications_as_advised'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['medications_as_advised']) && $select_result['medications_as_advised'] != "Yes"){echo 'checked="checked"';}?> > No</label>
                    </td>
                    <td>Continue thyroid/antihypertensive/diabetes /other medical disorder medications as advised</td>
                </tr>
                <tr>
                    <td>
                        <label><input type="radio"  name="report" value="yes" <?php if(isset($select_result['report']) && $select_result['report'] == "Yes"){echo 'checked="checked"'; }?> > Yes</label>
                        <label><input type="radio"  name="report" value="No" <?php if(isset($select_result['report']) && $select_result['report'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['report']) && $select_result['report'] != "Yes"){echo 'checked="checked"';}?> > No</label>

                    </td>
                    <td>To report if giddiness /nausea/vomiting/bleeding/pain/fever /purulent discharge immediately</td>
                </tr>
            </thead> 
            <thead>
                <tr>
                    <th colspan="2"><p>Doctors signature <input name="doctor_signature" value="<?php echo isset($select_result['doctor_signature'])?$select_result['doctor_signature']:""; ?>" type="text"></p></th>
                </tr>
            </thead>  
        </table>
        </div>
                    <!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
                    <input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
</form>