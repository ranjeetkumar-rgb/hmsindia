<?php
    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        $select_query = "SELECT * FROM `natural_cycle_protocol` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `natural_cycle_protocol` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }       
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE natural_cycle_protocol SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"    ;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

       if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `natural_cycle_protocol` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
    $select_result = run_select_query($select_query);  
    
?>

<!--<?php
	// php code to Insert data into mysql database from input text
// 	if(isset($_POST['submit'])){
// 		$patient_id = $_POST['patient_id'];
//         $receipt_number = $_POST['receipt_number'];
//         $status = $_POST['status'];
    
// 		// get values form input text and number
// 		$partners_name = $_POST['partners_name'];
//                 $art_bank_reg_no = $_POST['art_bank_reg_no'];
//                 $form_id = $_POST['form_id'];
//                 $donor_d = $_POST['donor_d'];
//                 $date_1 = $_POST['date_1'];
//                 $date_2 = $_POST['date_2'];
//                 $date_3 = $_POST['date_3'];
//                 $date_4 = $_POST['date_4'];
//                 $date_5 = $_POST['date_5'];
//                 $date_6 = $_POST['date_6'];
//                 $date_7 = $_POST['date_7'];
//                 $date_8 = $_POST['date_8'];
//                 $date_9 = $_POST['date_9'];
//                 $date_10 = $_POST['date_10'];
//                 $date_11 = $_POST['date_11'];
//                 $date_12 = $_POST['date_12'];
//                 $date_13 = $_POST['date_13'];
//                 $date_14 = $_POST['date_14'];
//                 $date_15 = $_POST['date_15'];
//                 $follicle_size_rt_1 = $_POST['follicle_size_rt_1'];
//                 $follicle_size_rt_2 = $_POST['follicle_size_rt_2'];
//                 $follicle_size_rt_3 = $_POST['follicle_size_rt_3'];
//                 $follicle_size_rt_4 = $_POST['follicle_size_rt_4'];
//                 $follicle_size_rt_5 = $_POST['follicle_size_rt_5'];
//                 $follicle_size_rt_6 = $_POST['follicle_size_rt_6'];
//                 $follicle_size_rt_7 = $_POST['follicle_size_rt_7'];
//                 $follicle_size_rt_8 = $_POST['follicle_size_rt_8'];
//                 $follicle_size_rt_9 = $_POST['follicle_size_rt_9'];
//                 $follicle_size_rt_10 = $_POST['follicle_size_rt_10'];
//                 $follicle_size_rt_11 = $_POST['follicle_size_rt_11'];
//                 $follicle_size_rt_12 = $_POST['follicle_size_rt_12'];
//                 $follicle_size_rt_13 = $_POST['follicle_size_rt_13'];
//                 $follicle_size_rt_14 = $_POST['follicle_size_rt_14'];
//                 $follicle_size_rt_15 = $_POST['follicle_size_rt_15'];
//                 $follicle_size_lt_1 = $_POST['follicle_size_lt_1'];
//                 $follicle_size_lt_2 = $_POST['follicle_size_lt_2'];
//                 $follicle_size_lt_3 = $_POST['follicle_size_lt_3'];
//                 $follicle_size_lt_4 = $_POST['follicle_size_lt_4'];
//                 $follicle_size_lt_5 = $_POST['follicle_size_lt_5'];
//                 $follicle_size_lt_6 = $_POST['follicle_size_lt_6'];
//                 $follicle_size_lt_7 = $_POST['follicle_size_lt_7'];
//                 $follicle_size_lt_8 = $_POST['follicle_size_lt_8'];
//                 $follicle_size_lt_9 = $_POST['follicle_size_lt_9'];
//                 $follicle_size_lt_10 = $_POST['follicle_size_lt_10'];
//                 $follicle_size_lt_11 = $_POST['follicle_size_lt_11'];
//                 $follicle_size_lt_12 = $_POST['follicle_size_lt_12'];
//                 $follicle_size_lt_13 = $_POST['follicle_size_lt_13'];
//                 $follicle_size_lt_14 = $_POST['follicle_size_lt_14'];
//                 $follicle_size_lt_15 = $_POST['follicle_size_lt_15'];
//                 $endometrial_thickness_1 = $_POST['endometrial_thickness_1'];
//                 $endometrial_thickness_2 = $_POST['endometrial_thickness_2'];
//                 $endometrial_thickness_3 = $_POST['endometrial_thickness_3'];
//                 $endometrial_thickness_4 = $_POST['endometrial_thickness_4'];
//                 $endometrial_thickness_5 = $_POST['endometrial_thickness_5'];
//                 $endometrial_thickness_6 = $_POST['endometrial_thickness_6'];
//                 $endometrial_thickness_7 = $_POST['endometrial_thickness_7'];
//                 $endometrial_thickness_8 = $_POST['endometrial_thickness_8'];
//                 $endometrial_thickness_9 = $_POST['endometrial_thickness_9'];
//                 $endometrial_thickness_10 = $_POST['endometrial_thickness_10'];
//                 $endometrial_thickness_11 = $_POST['endometrial_thickness_11'];
//                 $endometrial_thickness_12 = $_POST['endometrial_thickness_12'];
//                 $endometrial_thickness_13 = $_POST['endometrial_thickness_13'];
//                 $endometrial_thickness_14 = $_POST['endometrial_thickness_14'];
//                 $endometrial_thickness_15 = $_POST['endometrial_thickness_15'];
//                 $hcg_1 = $_POST['hcg_1'];
//                 $hcg_2 = $_POST['hcg_2'];
//                 $hcg_3 = $_POST['hcg_3'];
//                 $hcg_4 = $_POST['hcg_4'];
//                 $hcg_5 = $_POST['hcg_5'];
//                 $hcg_6 = $_POST['hcg_6'];
//                 $hcg_7 = $_POST['hcg_7'];
//                 $hcg_8 = $_POST['hcg_8'];
//                 $hcg_9 = $_POST['hcg_9'];
//                 $hcg_10 = $_POST['hcg_10'];
//                 $hcg_11 = $_POST['hcg_11'];
//                 $hcg_12 = $_POST['hcg_12'];
//                 $hcg_13 = $_POST['hcg_13'];
//                 $hcg_14 = $_POST['hcg_14'];
//                 $hcg_15 = $_POST['hcg_15'];
//                 $medicine_added_1 = $_POST['medicine_added_1'];
//                 $medicine_added_2 = $_POST['medicine_added_2'];
//                 $medicine_added_3 = $_POST['medicine_added_3'];
//                 $medicine_added_4 = $_POST['medicine_added_4'];
//                 $medicine_added_5 = $_POST['medicine_added_5'];
//                 $medicine_added_6 = $_POST['medicine_added_6'];
//                 $medicine_added_7 = $_POST['medicine_added_7'];
//                 $medicine_added_8 = $_POST['medicine_added_8'];
//                 $medicine_added_9 = $_POST['medicine_added_9'];
//                 $medicine_added_10 = $_POST['medicine_added_10'];
//                 $medicine_added_11 = $_POST['medicine_added_11'];
//                 $medicine_added_12 = $_POST['medicine_added_12'];
//                 $medicine_added_13 = $_POST['medicine_added_13'];
//                 $medicine_added_14 = $_POST['medicine_added_14'];
//                 $medicine_added_15 = $_POST['medicine_added_15'];
//                 $remarks_1 = $_POST['remarks_1'];
//                 $remarks_2 = $_POST['remarks_2'];
//                 $remarks_3 = $_POST['remarks_3'];
//                 $remarks_4 = $_POST['remarks_4'];
//                 $remarks_5 = $_POST['remarks_5'];
//                 $remarks_6 = $_POST['remarks_6'];
//                 $remarks_7 = $_POST['remarks_7'];
//                 $remarks_8 = $_POST['remarks_8'];
//                 $remarks_9 = $_POST['remarks_9'];
//                 $remarks_10 = $_POST['remarks_10'];
//                 $remarks_11 = $_POST['remarks_11'];
//                 $remarks_12 = $_POST['remarks_12'];
//                 $remarks_13 = $_POST['remarks_13'];
//                 $remarks_14 = $_POST['remarks_14'];
//                 $remarks_15 = $_POST['remarks_15'];
//                 $follow_up_1 = $_POST['follow_up_1'];
//                 $follow_up_2 = $_POST['follow_up_2'];
//                 $follow_up_3 = $_POST['follow_up_3'];
//                 $follow_up_4 = $_POST['follow_up_4'];
//                 $follow_up_5 = $_POST['follow_up_5'];
//                 $follow_up_6 = $_POST['follow_up_6'];
//                 $follow_up_7 = $_POST['follow_up_7'];
//                 $follow_up_8 = $_POST['follow_up_8'];
//                 $follow_up_9 = $_POST['follow_up_9'];
//                 $follow_up_10 = $_POST['follow_up_10'];
//                 $follow_up_11 = $_POST['follow_up_11'];
//                 $follow_up_12 = $_POST['follow_up_12'];
//                 $follow_up_13 = $_POST['follow_up_13'];
//                 $follow_up_14 = $_POST['follow_up_14'];
//                 $follow_up_15 = $_POST['follow_up_15'];
//                 $estradoil_1 = $_POST['estradoil_1'];
//                 $estradoil_2 = $_POST['estradoil_2'];
//                 $estradoil_3 = $_POST['estradoil_3'];
//                 $estradoil_4 = $_POST['estradoil_4'];
//                 $estradoil_5 = $_POST['estradoil_5'];
//                 $estradoil_6 = $_POST['estradoil_6'];
//                 $estradoil_7 = $_POST['estradoil_7'];
//                 $estradoil_8 = $_POST['estradoil_8'];
//                 $estradoil_9 = $_POST['estradoil_9'];
//                 $estradoil_10 = $_POST['estradoil_10'];
//                 $estradoil_11 = $_POST['estradoil_11'];
//                 $estradoil_12 = $_POST['estradoil_12'];
//                 $estradoil_13 = $_POST['estradoil_13'];
//                 $estradoil_14 = $_POST['estradoil_14'];
//                 $estradoil_15 = $_POST['estradoil_15'];
//                 $progesterone_1 = $_POST['progesterone_1'];
//                 $progesterone_2 = $_POST['progesterone_2'];
//                 $progesterone_3 = $_POST['progesterone_3'];
//                 $progesterone_4 = $_POST['progesterone_4'];
//                 $progesterone_5 = $_POST['progesterone_5'];
//                 $progesterone_6 = $_POST['progesterone_6'];
//                 $progesterone_7 = $_POST['progesterone_7'];
//                 $progesterone_8 = $_POST['progesterone_8'];
//                 $progesterone_9 = $_POST['progesterone_9'];
//                 $progesterone_10 = $_POST['progesterone_10'];
//                 $progesterone_11 = $_POST['progesterone_11'];
//                 $progesterone_12 = $_POST['progesterone_12'];
//                 $progesterone_13 = $_POST['progesterone_13'];
//                 $progesterone_14 = $_POST['progesterone_14'];
//                 $progesterone_15 = $_POST['progesterone_15'];
//                 $doctor = $_POST['doctor'];
//                 $counsellor = $_POST['counsellor'];
//                 $nurse = $_POST['nurse'];
//                 $last_menstrual_period = $_POST['last_menstrual_period'];

// 		// connect to mysql database using mysqli
		

// 		// mysql query to insert data
// 		$query = "INSERT INTO `natural_cycle_protocol`(`patient_id`, `receipt_number`, `status`,`partners_name`,`art_bank_reg_no`,`form_id`,`donor_d`,`date_1`,`date_2`,`date_3`,`date_4`,`date_5`,`date_6`,`date_7`,`date_8`,`date_9`,`date_10`,`date_11`,`date_12`,`date_13`,`date_14`,`date_15`,`follicle_size_rt_1`,`follicle_size_rt_2`,`follicle_size_rt_3`,`follicle_size_rt_4`,`follicle_size_rt_5`,`follicle_size_rt_6`,`follicle_size_rt_7`,`follicle_size_rt_8`,`follicle_size_rt_9`,`follicle_size_rt_10`,`follicle_size_rt_11`,`follicle_size_rt_12`,`follicle_size_rt_13`,`follicle_size_rt_14`,`follicle_size_rt_15`,`follicle_size_lt_1`,`follicle_size_lt_2`,`follicle_size_lt_3`,`follicle_size_lt_4`,`follicle_size_lt_5`,`follicle_size_lt_6`,`follicle_size_lt_7`,`follicle_size_lt_8`,`follicle_size_lt_9`,`follicle_size_lt_10`,`follicle_size_lt_11`,`follicle_size_lt_12`,`follicle_size_lt_13`,`follicle_size_lt_14`,`follicle_size_lt_15`,`endometrial_thickness_1`,`endometrial_thickness_2`,`endometrial_thickness_3`,`endometrial_thickness_4`,`endometrial_thickness_5`,`endometrial_thickness_6`,`endometrial_thickness_7`,`endometrial_thickness_8`,`endometrial_thickness_9`,`endometrial_thickness_10`,`endometrial_thickness_11`,`endometrial_thickness_12`,`endometrial_thickness_13`,`endometrial_thickness_14`,`endometrial_thickness_15`,`hcg_1`,`hcg_2`,`hcg_3`,`hcg_4`,`hcg_5`,`hcg_6`,`hcg_7`,`hcg_8`,`hcg_9`,`hcg_10`,`hcg_11`,`hcg_12`,`hcg_13`,`hcg_14`,`hcg_15`,`medicine_added_1`,`medicine_added_2`,`medicine_added_3`,`medicine_added_4`,`medicine_added_5`,`medicine_added_6`,`medicine_added_7`,`medicine_added_8`,`medicine_added_9`,`medicine_added_10`,`medicine_added_11`,`medicine_added_12`,`medicine_added_13`,`medicine_added_14`,`medicine_added_15`,`remarks_1`,`remarks_2`,`remarks_3`,`remarks_4`,`remarks_5`,`remarks_6`,`remarks_7`,`remarks_8`,`remarks_9`,`remarks_10`,`remarks_11`,`remarks_12`,`remarks_13`,`remarks_14`,`remarks_15`,`follow_up_1`,`follow_up_2`,`follow_up_3`,`follow_up_4`,`follow_up_5`,`follow_up_6`,`follow_up_7`,`follow_up_8`,`follow_up_9`,`follow_up_10`,`follow_up_11`,`follow_up_12`,`follow_up_13`,`follow_up_14`,`follow_up_15`,`estradoil_1`,`estradoil_2`,`estradoil_3`,`estradoil_4`,`estradoil_5`,`estradoil_6`,`estradoil_7`,`estradoil_8`,`estradoil_9`,`estradoil_10`,`estradoil_11`,`estradoil_12`,`estradoil_13`,`estradoil_14`,`estradoil_15`,`progesterone_1`,`progesterone_2`,`progesterone_3`,`progesterone_4`,`progesterone_5`,`progesterone_6`,`progesterone_7`,`progesterone_8`,`progesterone_9`,`progesterone_10`,`progesterone_11`,`progesterone_12`,`progesterone_13`,`progesterone_14`,`progesterone_15`,`doctor`,`counsellor`,`nurse`,`last_menstrual_period`) VALUES ('$patient_id','$receipt_number','$status','$partners_name','$art_bank_reg_no','$form_id','$donor_d','$date_1','$date_2','$date_3','$date_4','$date_5','$date_6','$date_7','$date_8','$date_9','$date_10','$date_11','$date_12','$date_13','$date_14','$date_15','$follicle_size_rt_1','$follicle_size_rt_2','$follicle_size_rt_3','$follicle_size_rt_4','$follicle_size_rt_5','$follicle_size_rt_6','$follicle_size_rt_7','$follicle_size_rt_8','$follicle_size_rt_9','$follicle_size_rt_10','$follicle_size_rt_11','$follicle_size_rt_12','$follicle_size_rt_13','$follicle_size_rt_14','$follicle_size_rt_15','$follicle_size_lt_1','$follicle_size_lt_2','$follicle_size_lt_3','$follicle_size_lt_4','$follicle_size_lt_5','$follicle_size_lt_6','$follicle_size_lt_7','$follicle_size_lt_8','$follicle_size_lt_9','$follicle_size_lt_10','$follicle_size_lt_11','$follicle_size_lt_12','$follicle_size_lt_13','$follicle_size_lt_14','$follicle_size_lt_15','$endometrial_thickness_1','$endometrial_thickness_2','$endometrial_thickness_3','$endometrial_thickness_4','$endometrial_thickness_5','$endometrial_thickness_6','$endometrial_thickness_7','$endometrial_thickness_8','$endometrial_thickness_9','$endometrial_thickness_10','$endometrial_thickness_11','$endometrial_thickness_12','$endometrial_thickness_13','$endometrial_thickness_14','$endometrial_thickness_15','$hcg_1','$hcg_2','$hcg_3','$hcg_4','$hcg_5','$hcg_6','$hcg_7','$hcg_8','$hcg_9','$hcg_10','$hcg_11','$hcg_12','$hcg_13','$hcg_14','$hcg_15','$medicine_added_1','$medicine_added_2','$medicine_added_3','$medicine_added_4','$medicine_added_5','$medicine_added_6','$medicine_added_7','$medicine_added_8','$medicine_added_9','$medicine_added_10','$medicine_added_11','$medicine_added_12','$medicine_added_13','$medicine_added_14','$medicine_added_15','$remarks_1','$remarks_2','$remarks_3','$remarks_4','$remarks_5','$remarks_6','$remarks_7','$remarks_8','$remarks_9','$remarks_10','$remarks_11','$remarks_12','$remarks_13','$remarks_14','$remarks_15','$follow_up_1','$follow_up_2','$follow_up_3','$follow_up_4','$follow_up_5','$follow_up_6','$follow_up_7','$follow_up_8','$follow_up_9','$follow_up_10','$follow_up_11','$follow_up_12','$follow_up_13','$follow_up_14','$follow_up_15','$estradoil_1','$estradoil_2','$estradoil_3','$estradoil_4','$estradoil_5','$estradoil_6','$estradoil_7','$estradoil_8','$estradoil_9','$estradoil_10','$estradoil_11','$estradoil_12','$estradoil_13','$estradoil_14','$estradoil_15','$progesterone_1','$progesterone_2','$progesterone_3','$progesterone_4','$progesterone_5','$progesterone_6','$progesterone_7','$progesterone_8','$progesterone_9','$progesterone_10','$progesterone_11','$progesterone_12','$progesterone_13','$progesterone_14','$progesterone_15','$doctor','$counsellor','$nurse','$last_menstrual_period')";
    
// $result = run_form_query($query);

//         if($result){
//           header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
// 					die();
//         }else{
//           header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
// 					die();
//         }
// 	}
?>-->
<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
  <input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
  <input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
  <input type="hidden" value="pending" name="status"> 
    <div class="container red-field form mt-5 mb-5">
    <table class="table table-bordered table-hover mt-2 table-sm red-field tableMg">
     <thead>
                <tr>
                    <td colspan="2"><h2>NATURAL CYCLE  PROTOCOL</h2></td>
                    <td colspan="2">
        			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
        			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
        			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
        			            ){?>
        			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
        			    <?php } ?>
        			</td>
                </tr>
     </thead>
     <table class="table table-bordered table-hover mt-2 table-sm tableMg">
     <thead>
                <tr>
                <th style="color: red;"><h2>SELF CYCLE  (S)</h2></th>
                <th><h2>DONOR CYCLE (D)</h2></th>
                </tr>
                
     </thead>
    </table>
        <ul class="d-flex mb-1 mt-2 list-unstyled">
        <div class = "table-responsive">
            <table class="table table-bordered table-hover table-sm">
            <thead>
                <tr>
                <th style="color: red;"><strong>Partners name</strong></th>
                <th><input type="text" value="<?php echo isset($select_result['partners_name'])?$select_result['partners_name']:""; ?>" maxlength="20" class="form" name="partners_name"></th>
                <th><strong>ART bank reg no</strong></th>
                <th><input type="text" value="<?php echo isset($select_result['art_bank_reg_no'])?$select_result['art_bank_reg_no']:""; ?>" maxlength="20" class="form" name="art_bank_reg_no"></th>
                </tr>
            </thead>
          <thead>
            <tr>
              <th style="color: red;"><strong>ID</strong></th>
              <th><input type="text" value="<?php echo isset($select_result['form_id'])?$select_result['form_id']:""; ?>" maxlength="20" class="form" name="form_id"></th>
              <th><strong>Donor ID</strong></th>
              <th><input type="text" value="<?php echo isset($select_result['donor_d'])?$select_result['donor_d']:""; ?>" maxlength="20" class="form" name="donor_d"></th>
            </tr>
          </thead>
    </table>
    </div>
    </ul>
    <table class="table table-bordered table-hover  table-sm red-field tableMg">
        <thead>
            <tr>
                <td>LAST MENSTRUAL PERIOD</td>
                <td><input type="date" value="<?php echo isset($select_result['last_menstrual_period'])?$select_result['last_menstrual_period']:""; ?>" class="form" name="last_menstrual_period"></td>
            </tr>
        </thead>
    </table>
    <div class = "table-responsive">
    <table class="table table-bordered table-hover table-sm red-field tableMg">
            <thead>
                    <tr>
                            <th><strong>Day of Stimulation</strong></th>
                            <th>1</th>
                            <th>2</th>
                            <th>3</th>
                            <th>4</th>
                            <th>5</th>
                            <th>6</th>
                            <th>7</th>
                            <th>8</th>
                            <th>9</th>
                            <th>10</th>
                            <th>11</th>
                            <th>12</th>
                            <th>13</th>
                            <th>14</th>
                            <th>15</th>
                    </tr>
                </thead>
              <tbody>
                <tr>
                <td>DATE</td>
                <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['date_'.$i])) {$value = $select_result['date_'.$i]; }
                    echo '<td><input type="date" class="form" name="date_'.$i.'"></td>';
                    }
                    ?>
                </tr>
              </tbody>
              <tbody>
                <tr>
                  <td>FOLLICLE SIZE RT (cm)</td>
                  <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['follicle_size_rt_'.$i])) {$value = $select_result['follicle_size_rt_'.$i]; }
                    echo '<td><input type="number" min="0" class="form" name="follicle_size_rt_'.$i.'"></td>';
                    }
                  ?>
                </tr>
              </tbody>
              <tbody>
                <tr>
                <td>FOLLICLE SIZE LT (cm)</td>
                  <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['follicle_size_lt_'.$i])) {$value = $select_result['follicle_size_lt_'.$i]; }
                    echo '<td><input type="number" min="0" class="form" name="follicle_size_lt_'.$i.'"></td>';
                    }
                  ?>
                </tr>
              </tbody>
              <tbody>
                <tr>
                  <td>ENDOMETRIAL THICKNESS (cm)</td>
                <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['endometrial_thickness_'.$i])) {$value = $select_result['endometrial_thickness_'.$i]; }
                    echo '<td><input type="number" min="0" class="form" name="endometrial_thickness_'.$i.'"></td>';
                    }
                  ?>
                </tr>
              </tbody>
              <tbody>
                <tr>
                <td>HCG(TRIGGER)</td>
                  <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['hcg_'.$i])) {$value = $select_result['hcg_'.$i]; }
                    echo '<td><input type="text" maxlength="20" class="form" name="hcg_'.$i.'"></td>';
                    }
                  ?>
                </tr>
              </tbody>
              <tbody>
                <tr>
                  <td>MEDICINE ADDED</td>
                  <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['medicine_added_'.$i])) {$value = $select_result['medicine_added_'.$i]; }
                    echo '<td><input type="text" maxlength="20" class="form" name="medicine_added_'.$i.'"></td>';
                    }
                  ?>
                </tr>
              </tbody>
              <tbody>
                <tr>
                  <td>REMARKS</td>
                  <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['remarks_'.$i])) {$value = $select_result['remarks_'.$i]; }
                    echo '<td><input type="text" maxlength="20" class="form" name="remarks_'.$i.'"></td>';
                    }
                  ?>
                </tr>
              </tbody>
              <tbody>
                <tr>
                <td>FOLLOWUP ON</td>
                <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['follow_up_'.$i])) {$value = $select_result['follow_up_'.$i]; }
                    echo '<td><input type="text" maxlength="20" class="form" name="follow_up_'.$i.'"></td>';
                    }
                  ?>
                  
                </tr>
              </tbody>
              <tbody>
                <tr>
                <td>SERUM ESTRADIOL (E2) LEVEL</td>
                  <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['estradoil_'.$i])) {$value = $select_result['estradoil_'.$i]; }
                    echo '<td><input type="text" maxlength="20" class="form" name="estradoil_'.$i.'"></td>';
                    }
                  ?>
                  
                </tr>
              </tbody>
              <tbody>
                <tr>
                    <td>SERUM PROGESTERONE LEVEL</td>
                    <?php for($i=1;$i<=15;$i++){
                        $value=""; if(isset($select_result['progesterone_'.$i])) {$value = $select_result['progesterone_'.$i]; }
                        echo '<td><input type="text" maxlength="20" class="form" name="progesterone_'.$i.'"></td>';
                    }
                  ?>
                </tr>
              </tbody>
    </table>
    </div>
    <table class="table table-bordered table-hover table-sm red-field tableMg">
        <thead>
            <tr>
                <th>DOCTOR <input type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>" class="form" name="doctor"></th>
                <th>COUNSELLOR <input type="text" value="<?php echo isset($select_result['counsellor'])?$select_result['counsellor']:""; ?>" class="form" name="counsellor"></th>
                <th>NURSE <input type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>" class="form" name="nurse"></th>
            </tr>
        </thead>
    </table>
            <!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
            <input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
    </div>
</form>