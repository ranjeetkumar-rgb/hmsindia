<?php
    // php code to Insert data into mysql database from input text
    if(isset($_POST['submit'])){
        unset($_POST['submit']);
        
        if(!empty($_FILES['image_video_']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_1']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_1']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_1']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_1'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_2']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_2']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_2']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_2'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_3']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_3']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_3']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_3'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_4']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_4']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_4']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_4'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_5']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_5']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_5']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_5'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_6']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_6']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_6']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_6'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_7']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_7']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_7']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_7'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_8']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_8']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_8']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_8'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_9']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_9']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_9']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_9'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_10']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_10']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_10']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_10'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_11']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_11']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_11']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_11'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_12']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_12']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_12']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_12'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_13']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_13']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_13']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_13'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_14']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_14']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_14']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_14'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_15']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_15']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_15']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_15'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_16']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_16']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_16']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_16'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_17']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_17']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_17']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_17'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_18']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_18']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_18']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_18'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_19']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_19']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_19']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_19'] = $transaction_img;
        }
        
        if(!empty($_FILES['image_video_20']['tmp_name'])){
            $dest_path = $this->config->item('upload_path');
            $destination = $dest_path.'procedure-forms-uploads/';
            $NewImageName = rand(4,10000)."-".$_FILES['image_video_20']['name'];
            $transaction_img = base_url().'assets/procedure-forms-uploads/'.$NewImageName;
            move_uploaded_file($_FILES['image_video_20']['tmp_name'], $destination.$NewImageName);
            $_POST['image_video_20'] = $transaction_img;
        }
        
        $select_query = "SELECT * FROM `sperm_preparation` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        $select_result = run_select_query($select_query); 
        if(empty($select_result)){
            // mysql query to insert data
            $query = "INSERT INTO `sperm_preparation` SET ";
            $sqlArr = array();
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".addslashes($value)."'";
            }       
            $query .= implode(',' , $sqlArr);
        }else{
            // mysql query to update data
            $query = "UPDATE sperm_preparation SET ";
            foreach( $_POST as $key=> $value )
            {
              $sqlArr[] = " $key = '".$value."'"    ;
            }
            $query .= implode(',' , $sqlArr);
            $query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
        }
        $result = run_form_query($query);        

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
    }
    $select_query = "SELECT * FROM `sperm_preparation` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
    $select_result = run_select_query($select_query);  
    
?>

<!--<?php
    // php code to Insert data into mysql database from input text
    // if(isset($_POST['submit'])){
    //     $hostname = "localhost";
    //     $username = "root";
    //     $password = "";
    //     $databaseName = "forms";
    
    //     // get values form input text and number
    //     $s_no_ = $_POST['s_no_'];
    //     $produced_at_center_ = $_POST['produced_at_center_'];
    //     $produced_at_home_ = $_POST['produced_at_home_'];
    //     $produced_at_sperm_retreival_ = $_POST['produced_at_sperm_retreival_'];
    //     $abstinence_ = $_POST['abstinence_'];
    //     $volume_ = $_POST['volume_'];
    //     $sperm_counted_pre_wash_ = $_POST['sperm_counted_pre_wash_'];
    //     $sperm_counted_post_wash_ = $_POST['sperm_counted_post_wash_'];
    //     $progressively_pre_wash_ = $_POST['progressively_pre_wash_'];
    //     $progressively_post_wash_ = $_POST['progressively_post_wash_'];
    //     $morphology_ = $_POST['morphology_'];
    //     $pus_cells_ = $_POST['pus_cells_'];
    //     $agglutination_ = $_POST['agglutination_'];
    //     $cands_ = $_POST['cands_'];
    //     $preperation_method_ = $_POST['preperation_method_'];
    //     $purpose_ = $_POST['purpose_'];
    //     $media_used_ = $_POST['media_used_'];
    //     $remarks_ = $_POST['remarks_'];
    //     $image_video_ = $_POST['image_video_'];
    //     $freezing_date_ = $_POST['freezing_date_'];
    //     $freezing_media_ = $_POST['freezing_media_'];
    //     $freezing_container_no_ = $_POST['freezing_container_no_'];
    //     $freezing_holder_no_ = $_POST['freezing_holder_no_'];
    //     $freezing_colour_ = $_POST['freezing_colour_'];
    //     $freezing_position_ = $_POST['freezing_position_'];
    //     $thawing_date_ = $_POST['thawing_date_'];
    //     $thawing_purpose_ = $_POST['thawing_purpose_'];
    //     $thawing_path_ = $_POST['thawing_path_'];
    //     $storage_renewal_date_ = $_POST['storage_renewal_date_'];
    //     $take_away_date_ = $_POST['take_away_date_'];
    //     $take_away_purpose_ = $_POST['take_away_purpose_'];
    //     $prepared_by_ = $_POST['prepared_by_'];
    //     $witness_1_ = $_POST['witness_1_'];
    //     $witness_2_ = $_POST['witness_2_'];
    //     $s_no_1 = $_POST['s_no_1'];
    //     $produced_at_center_1 = $_POST['produced_at_center_1'];
    //     $produced_at_home_1 = $_POST['produced_at_home_1'];
    //     $produced_at_sperm_retreival_1 = $_POST['produced_at_sperm_retreival_1'];
    //     $abstinence_1 = $_POST['abstinence_1'];
    //     $volume_1 = $_POST['volume_1'];
    //     $sperm_counted_pre_wash_1 = $_POST['sperm_counted_pre_wash_1'];
    //     $sperm_counted_post_wash_1 = $_POST['sperm_counted_post_wash_1'];
    //     $progressively_pre_wash_1 = $_POST['progressively_pre_wash_1'];
    //     $progressively_post_wash_1 = $_POST['progressively_post_wash_1'];
    //     $morphology_1 = $_POST['morphology_1'];
    //     $pus_cells_1 = $_POST['pus_cells_1'];
    //     $agglutination_1 = $_POST['agglutination_1'];
    //     $cands_1 = $_POST['cands_1'];
    //     $preperation_method_1 = $_POST['preperation_method_1'];
    //     $purpose_1 = $_POST['purpose_1'];
    //     $media_used_1 = $_POST['media_used_1'];
    //     $remarks_1 = $_POST['remarks_1'];
    //     $image_video_1 = $_POST['image_video_1'];
    //     $freezing_date_1 = $_POST['freezing_date_1'];
    //     $freezing_media_1 = $_POST['freezing_media_1'];
    //     $freezing_container_no_1 = $_POST['freezing_container_no_1'];
    //     $freezing_holder_no_1 = $_POST['freezing_holder_no_1'];
    //     $freezing_colour_1 = $_POST['freezing_colour_1'];
    //     $freezing_position_1 = $_POST['freezing_position_1'];
    //     $thawing_date_1 = $_POST['thawing_date_1'];
    //     $thawing_purpose_1 = $_POST['thawing_purpose_1'];
    //     $thawing_path_1 = $_POST['thawing_path_1'];
    //     $storage_renewal_date_1 = $_POST['storage_renewal_date_1'];
    //     $take_away_date_1 = $_POST['take_away_date_1'];
    //     $take_away_purpose_1 = $_POST['take_away_purpose_1'];
    //     $prepared_by_1 = $_POST['prepared_by_1'];
    //     $witness_1_1 = $_POST['witness_1_1'];
    //     $witness_2_1 = $_POST['witness_2_1'];
    //     $s_no_2 = $_POST['s_no_2'];
    //     $produced_at_center_2 = $_POST['produced_at_center_2'];
    //     $produced_at_home_2 = $_POST['produced_at_home_2'];
    //     $produced_at_sperm_retreival_2 = $_POST['produced_at_sperm_retreival_2'];
    //     $abstinence_2 = $_POST['abstinence_2'];
    //     $volume_2 = $_POST['volume_2'];
    //     $sperm_counted_pre_wash_2 = $_POST['sperm_counted_pre_wash_2'];
    //     $sperm_counted_post_wash_2 = $_POST['sperm_counted_post_wash_2'];
    //     $progressively_pre_wash_2 = $_POST['progressively_pre_wash_2'];
    //     $progressively_post_wash_2 = $_POST['progressively_post_wash_2'];
    //     $morphology_2 = $_POST['morphology_2'];
    //     $pus_cells_2 = $_POST['pus_cells_2'];
    //     $agglutination_2 = $_POST['agglutination_2'];
    //     $cands_2 = $_POST['cands_2'];
    //     $preperation_method_2 = $_POST['preperation_method_2'];
    //     $purpose_2 = $_POST['purpose_2'];
    //     $media_used_2 = $_POST['media_used_2'];
    //     $remarks_2 = $_POST['remarks_2'];
    //     $image_video_2 = $_POST['image_video_2'];
    //     $freezing_date_2 = $_POST['freezing_date_2'];
    //     $freezing_media_2 = $_POST['freezing_media_2'];
    //     $freezing_container_no_2 = $_POST['freezing_container_no_2'];
    //     $freezing_holder_no_2 = $_POST['freezing_holder_no_2'];
    //     $freezing_colour_2 = $_POST['freezing_colour_2'];
    //     $freezing_position_2 = $_POST['freezing_position_2'];
    //     $thawing_date_2 = $_POST['thawing_date_2'];
    //     $thawing_purpose_2 = $_POST['thawing_purpose_2'];
    //     $thawing_path_2 = $_POST['thawing_path_2'];
    //     $storage_renewal_date_2 = $_POST['storage_renewal_date_2'];
    //     $take_away_date_2 = $_POST['take_away_date_2'];
    //     $take_away_purpose_2 = $_POST['take_away_purpose_2'];
    //     $prepared_by_2 = $_POST['prepared_by_2'];
    //     $witness_1_2 = $_POST['witness_1_2'];
    //     $witness_2_2 = $_POST['witness_2_2'];
    //     $s_no_3 = $_POST['s_no_3'];
    //     $produced_at_center_3 = $_POST['produced_at_center_3'];
    //     $produced_at_home_3 = $_POST['produced_at_home_3'];
    //     $produced_at_sperm_retreival_3 = $_POST['produced_at_sperm_retreival_3'];
    //     $abstinence_3 = $_POST['abstinence_3'];
    //     $volume_3 = $_POST['volume_3'];
    //     $sperm_counted_pre_wash_3 = $_POST['sperm_counted_pre_wash_3'];
    //     $sperm_counted_post_wash_3 = $_POST['sperm_counted_post_wash_3'];
    //     $progressively_pre_wash_3 = $_POST['progressively_pre_wash_3'];
    //     $progressively_post_wash_3 = $_POST['progressively_post_wash_3'];
    //     $morphology_3 = $_POST['morphology_3'];
    //     $pus_cells_3 = $_POST['pus_cells_3'];
    //     $agglutination_3 = $_POST['agglutination_3'];
    //     $cands_3 = $_POST['cands_3'];
    //     $preperation_method_3 = $_POST['preperation_method_3'];
    //     $purpose_3 = $_POST['purpose_3'];
    //     $media_used_3 = $_POST['media_used_3'];
    //     $remarks_3 = $_POST['remarks_3'];
    //     $image_video_3 = $_POST['image_video_3'];
    //     $freezing_date_3 = $_POST['freezing_date_3'];
    //     $freezing_media_3 = $_POST['freezing_media_3'];
    //     $freezing_container_no_3 = $_POST['freezing_container_no_3'];
    //     $freezing_holder_no_3 = $_POST['freezing_holder_no_3'];
    //     $freezing_colour_3 = $_POST['freezing_colour_3'];
    //     $freezing_position_3 = $_POST['freezing_position_3'];
    //     $thawing_date_3 = $_POST['thawing_date_3'];
    //     $thawing_purpose_3 = $_POST['thawing_purpose_3'];
    //     $thawing_path_3 = $_POST['thawing_path_3'];
    //     $storage_renewal_date_3 = $_POST['storage_renewal_date_3'];
    //     $take_away_date_3 = $_POST['take_away_date_3'];
    //     $take_away_purpose_3 = $_POST['take_away_purpose_3'];
    //     $prepared_by_3 = $_POST['prepared_by_3'];
    //     $witness_1_3 = $_POST['witness_1_3'];
    //     $witness_2_3 = $_POST['witness_2_3'];
    //     $s_no_4 = $_POST['s_no_4'];
    //     $produced_at_center_4 = $_POST['produced_at_center_4'];
    //     $produced_at_home_4 = $_POST['produced_at_home_4'];
    //     $produced_at_sperm_retreival_4 = $_POST['produced_at_sperm_retreival_4'];
    //     $abstinence_4 = $_POST['abstinence_4'];
    //     $volume_4 = $_POST['volume_4'];
    //     $sperm_counted_pre_wash_4 = $_POST['sperm_counted_pre_wash_4'];
    //     $sperm_counted_post_wash_4 = $_POST['sperm_counted_post_wash_4'];
    //     $progressively_pre_wash_4 = $_POST['progressively_pre_wash_4'];
    //     $progressively_post_wash_4 = $_POST['progressively_post_wash_4'];
    //     $morphology_4 = $_POST['morphology_4'];
    //     $pus_cells_4 = $_POST['pus_cells_4'];
    //     $agglutination_4 = $_POST['agglutination_4'];
    //     $cands_4 = $_POST['cands_4'];
    //     $preperation_method_4 = $_POST['preperation_method_4'];
    //     $purpose_4 = $_POST['purpose_4'];
    //     $media_used_4 = $_POST['media_used_4'];
    //     $remarks_4 = $_POST['remarks_4'];
    //     $image_video_4 = $_POST['image_video_4'];
    //     $freezing_date_4 = $_POST['freezing_date_4'];
    //     $freezing_media_4 = $_POST['freezing_media_4'];
    //     $freezing_container_no_4 = $_POST['freezing_container_no_4'];
    //     $freezing_holder_no_4 = $_POST['freezing_holder_no_4'];
    //     $freezing_colour_4 = $_POST['freezing_colour_4'];
    //     $freezing_position_4 = $_POST['freezing_position_4'];
    //     $thawing_date_4 = $_POST['thawing_date_4'];
    //     $thawing_purpose_4 = $_POST['thawing_purpose_4'];
    //     $thawing_path_4 = $_POST['thawing_path_4'];
    //     $storage_renewal_date_4 = $_POST['storage_renewal_date_4'];
    //     $take_away_date_4 = $_POST['take_away_date_4'];
    //     $take_away_purpose_4 = $_POST['take_away_purpose_4'];
    //     $prepared_by_4 = $_POST['prepared_by_4'];
    //     $witness_1_4 = $_POST['witness_1_4'];
    //     $witness_2_4 = $_POST['witness_2_4'];
    //     $s_no_5 = $_POST['s_no_5'];
    //     $produced_at_center_5 = $_POST['produced_at_center_5'];
    //     $produced_at_home_5 = $_POST['produced_at_home_5'];
    //     $produced_at_sperm_retreival_5 = $_POST['produced_at_sperm_retreival_5'];
    //     $abstinence_5 = $_POST['abstinence_5'];
    //     $volume_5 = $_POST['volume_5'];
    //     $sperm_counted_pre_wash_5 = $_POST['sperm_counted_pre_wash_5'];
    //     $sperm_counted_post_wash_5 = $_POST['sperm_counted_post_wash_5'];
    //     $progressively_pre_wash_5 = $_POST['progressively_pre_wash_5'];
    //     $progressively_post_wash_5 = $_POST['progressively_post_wash_5'];
    //     $morphology_5 = $_POST['morphology_5'];
    //     $pus_cells_5 = $_POST['pus_cells_5'];
    //     $agglutination_5 = $_POST['agglutination_5'];
    //     $cands_5 = $_POST['cands_5'];
    //     $preperation_method_5 = $_POST['preperation_method_5'];
    //     $purpose_5 = $_POST['purpose_5'];
    //     $media_used_5 = $_POST['media_used_5'];
    //     $remarks_5 = $_POST['remarks_5'];
    //     $image_video_5 = $_POST['image_video_5'];
    //     $freezing_date_5 = $_POST['freezing_date_5'];
    //     $freezing_media_5 = $_POST['freezing_media_5'];
    //     $freezing_container_no_5 = $_POST['freezing_container_no_5'];
    //     $freezing_holder_no_5 = $_POST['freezing_holder_no_5'];
    //     $freezing_colour_5 = $_POST['freezing_colour_5'];
    //     $freezing_position_5 = $_POST['freezing_position_5'];
    //     $thawing_date_5 = $_POST['thawing_date_5'];
    //     $thawing_purpose_5 = $_POST['thawing_purpose_5'];
    //     $thawing_path_5 = $_POST['thawing_path_5'];
    //     $storage_renewal_date_5 = $_POST['storage_renewal_date_5'];
    //     $take_away_date_5 = $_POST['take_away_date_5'];
    //     $take_away_purpose_5 = $_POST['take_away_purpose_5'];
    //     $prepared_by_5 = $_POST['prepared_by_5'];
    //     $witness_1_5 = $_POST['witness_1_5'];
    //     $witness_2_5 = $_POST['witness_2_5'];
    //     $s_no_6 = $_POST['s_no_6'];
    //     $produced_at_center_6 = $_POST['produced_at_center_6'];
    //     $produced_at_home_6 = $_POST['produced_at_home_6'];
    //     $produced_at_sperm_retreival_6 = $_POST['produced_at_sperm_retreival_6'];
    //     $abstinence_6 = $_POST['abstinence_6'];
    //     $volume_6 = $_POST['volume_6'];
    //     $sperm_counted_pre_wash_6 = $_POST['sperm_counted_pre_wash_6'];
    //     $sperm_counted_post_wash_6 = $_POST['sperm_counted_post_wash_6'];
    //     $progressively_pre_wash_6 = $_POST['progressively_pre_wash_6'];
    //     $progressively_post_wash_6 = $_POST['progressively_post_wash_6'];
    //     $morphology_6 = $_POST['morphology_6'];
    //     $pus_cells_6 = $_POST['pus_cells_6'];
    //     $agglutination_6 = $_POST['agglutination_6'];
    //     $cands_6 = $_POST['cands_6'];
    //     $preperation_method_6 = $_POST['preperation_method_6'];
    //     $purpose_6 = $_POST['purpose_6'];
    //     $media_used_6 = $_POST['media_used_6'];
    //     $remarks_6 = $_POST['remarks_6'];
    //     $image_video_6 = $_POST['image_video_6'];
    //     $freezing_date_6 = $_POST['freezing_date_6'];
    //     $freezing_media_6 = $_POST['freezing_media_6'];
    //     $freezing_container_no_6 = $_POST['freezing_container_no_6'];
    //     $freezing_holder_no_6 = $_POST['freezing_holder_no_6'];
    //     $freezing_colour_6 = $_POST['freezing_colour_6'];
    //     $freezing_position_6 = $_POST['freezing_position_6'];
    //     $thawing_date_6 = $_POST['thawing_date_6'];
    //     $thawing_purpose_6 = $_POST['thawing_purpose_6'];
    //     $thawing_path_6 = $_POST['thawing_path_6'];
    //     $storage_renewal_date_6 = $_POST['storage_renewal_date_6'];
    //     $take_away_date_6 = $_POST['take_away_date_6'];
    //     $take_away_purpose_6 = $_POST['take_away_purpose_6'];
    //     $prepared_by_6 = $_POST['prepared_by_6'];
    //     $witness_1_6 = $_POST['witness_1_6'];
    //     $witness_2_6 = $_POST['witness_2_6'];
    //     $s_no_7 = $_POST['s_no_7'];
    //     $produced_at_center_7 = $_POST['produced_at_center_7'];
    //     $produced_at_home_7 = $_POST['produced_at_home_7'];
    //     $produced_at_sperm_retreival_7 = $_POST['produced_at_sperm_retreival_7'];
    //     $abstinence_7 = $_POST['abstinence_7'];
    //     $volume_7 = $_POST['volume_7'];
    //     $sperm_counted_pre_wash_7 = $_POST['sperm_counted_pre_wash_7'];
    //     $sperm_counted_post_wash_7 = $_POST['sperm_counted_post_wash_7'];
    //     $progressively_pre_wash_7 = $_POST['progressively_pre_wash_7'];
    //     $progressively_post_wash_7 = $_POST['progressively_post_wash_7'];
    //     $morphology_7 = $_POST['morphology_7'];
    //     $pus_cells_7 = $_POST['pus_cells_7'];
    //     $agglutination_7 = $_POST['agglutination_7'];
    //     $cands_7 = $_POST['cands_7'];
    //     $preperation_method_7 = $_POST['preperation_method_7'];
    //     $purpose_7 = $_POST['purpose_7'];
    //     $media_used_7 = $_POST['media_used_7'];
    //     $remarks_7 = $_POST['remarks_7'];
    //     $image_video_7 = $_POST['image_video_7'];
    //     $freezing_date_7 = $_POST['freezing_date_7'];
    //     $freezing_media_7 = $_POST['freezing_media_7'];
    //     $freezing_container_no_7 = $_POST['freezing_container_no_7'];
    //     $freezing_holder_no_7 = $_POST['freezing_holder_no_7'];
    //     $freezing_colour_7 = $_POST['freezing_colour_7'];
    //     $freezing_position_7 = $_POST['freezing_position_7'];
    //     $thawing_date_7 = $_POST['thawing_date_7'];
    //     $thawing_purpose_7 = $_POST['thawing_purpose_7'];
    //     $thawing_path_7 = $_POST['thawing_path_7'];
    //     $storage_renewal_date_7 = $_POST['storage_renewal_date_7'];
    //     $take_away_date_7 = $_POST['take_away_date_7'];
    //     $take_away_purpose_7 = $_POST['take_away_purpose_7'];
    //     $prepared_by_7 = $_POST['prepared_by_7'];
    //     $witness_1_7 = $_POST['witness_1_7'];
    //     $witness_2_7 = $_POST['witness_2_7'];
    //     $s_no_8 = $_POST['s_no_8'];
    //     $produced_at_center_8 = $_POST['produced_at_center_8'];
    //     $produced_at_home_8 = $_POST['produced_at_home_8'];
    //     $produced_at_sperm_retreival_8 = $_POST['produced_at_sperm_retreival_8'];
    //     $abstinence_8 = $_POST['abstinence_8'];
    //     $volume_8 = $_POST['volume_8'];
    //     $sperm_counted_pre_wash_8 = $_POST['sperm_counted_pre_wash_8'];
    //     $sperm_counted_post_wash_8 = $_POST['sperm_counted_post_wash_8'];
    //     $progressively_pre_wash_8 = $_POST['progressively_pre_wash_8'];
    //     $progressively_post_wash_8 = $_POST['progressively_post_wash_8'];
    //     $morphology_8 = $_POST['morphology_8'];
    //     $pus_cells_8 = $_POST['pus_cells_8'];
    //     $agglutination_8 = $_POST['agglutination_8'];
    //     $cands_8 = $_POST['cands_8'];
    //     $preperation_method_8 = $_POST['preperation_method_8'];
    //     $purpose_8 = $_POST['purpose_8'];
    //     $media_used_8 = $_POST['media_used_8'];
    //     $remarks_8 = $_POST['remarks_8'];
    //     $image_video_8 = $_POST['image_video_8'];
    //     $freezing_date_8 = $_POST['freezing_date_8'];
    //     $freezing_media_8 = $_POST['freezing_media_8'];
    //     $freezing_container_no_8 = $_POST['freezing_container_no_8'];
    //     $freezing_holder_no_8 = $_POST['freezing_holder_no_8'];
    //     $freezing_colour_8 = $_POST['freezing_colour_8'];
    //     $freezing_position_8 = $_POST['freezing_position_8'];
    //     $thawing_date_8 = $_POST['thawing_date_8'];
    //     $thawing_purpose_8 = $_POST['thawing_purpose_8'];
    //     $thawing_path_8 = $_POST['thawing_path_8'];
    //     $storage_renewal_date_8 = $_POST['storage_renewal_date_8'];
    //     $take_away_date_8 = $_POST['take_away_date_8'];
    //     $take_away_purpose_8 = $_POST['take_away_purpose_8'];
    //     $prepared_by_8 = $_POST['prepared_by_8'];
    //     $witness_1_8 = $_POST['witness_1_8'];
    //     $witness_2_8 = $_POST['witness_2_8'];
    //     $s_no_9 = $_POST['s_no_9'];
    //     $produced_at_center_9 = $_POST['produced_at_center_9'];
    //     $produced_at_home_9 = $_POST['produced_at_home_9'];
    //     $produced_at_sperm_retreival_9 = $_POST['produced_at_sperm_retreival_9'];
    //     $abstinence_9 = $_POST['abstinence_9'];
    //     $volume_9 = $_POST['volume_9'];
    //     $sperm_counted_pre_wash_9 = $_POST['sperm_counted_pre_wash_9'];
    //     $sperm_counted_post_wash_9 = $_POST['sperm_counted_post_wash_9'];
    //     $progressively_pre_wash_9 = $_POST['progressively_pre_wash_9'];
    //     $progressively_post_wash_9 = $_POST['progressively_post_wash_9'];
    //     $morphology_9 = $_POST['morphology_9'];
    //     $pus_cells_9 = $_POST['pus_cells_9'];
    //     $agglutination_9 = $_POST['agglutination_9'];
    //     $cands_9 = $_POST['cands_9'];
    //     $preperation_method_9 = $_POST['preperation_method_9'];
    //     $purpose_9 = $_POST['purpose_9'];
    //     $media_used_9 = $_POST['media_used_9'];
    //     $remarks_9 = $_POST['remarks_9'];
    //     $image_video_9 = $_POST['image_video_9'];
    //     $freezing_date_9 = $_POST['freezing_date_9'];
    //     $freezing_media_9 = $_POST['freezing_media_9'];
    //     $freezing_container_no_9 = $_POST['freezing_container_no_9'];
    //     $freezing_holder_no_9 = $_POST['freezing_holder_no_9'];
    //     $freezing_colour_9 = $_POST['freezing_colour_9'];
    //     $freezing_position_9 = $_POST['freezing_position_9'];
    //     $thawing_date_9 = $_POST['thawing_date_9'];
    //     $thawing_purpose_9 = $_POST['thawing_purpose_9'];
    //     $thawing_path_9 = $_POST['thawing_path_9'];
    //     $storage_renewal_date_9 = $_POST['storage_renewal_date_9'];
    //     $take_away_date_9 = $_POST['take_away_date_9'];
    //     $take_away_purpose_9 = $_POST['take_away_purpose_9'];
    //     $prepared_by_9 = $_POST['prepared_by_9'];
    //     $witness_1_9 = $_POST['witness_1_9'];
    //     $witness_2_9 = $_POST['witness_2_9'];
    //     $s_no_10 = $_POST['s_no_10'];
    //     $produced_at_center_10 = $_POST['produced_at_center_10'];
    //     $produced_at_home_10 = $_POST['produced_at_home_10'];
    //     $produced_at_sperm_retreival_10 = $_POST['produced_at_sperm_retreival_10'];
    //     $abstinence_10 = $_POST['abstinence_10'];
    //     $volume_10 = $_POST['volume_10'];
    //     $sperm_counted_pre_wash_10 = $_POST['sperm_counted_pre_wash_10'];
    //     $sperm_counted_post_wash_10 = $_POST['sperm_counted_post_wash_10'];
    //     $progressively_pre_wash_10 = $_POST['progressively_pre_wash_10'];
    //     $progressively_post_wash_10 = $_POST['progressively_post_wash_10'];
    //     $morphology_10 = $_POST['morphology_10'];
    //     $pus_cells_10 = $_POST['pus_cells_10'];
    //     $agglutination_10 = $_POST['agglutination_10'];
    //     $cands_10 = $_POST['cands_10'];
    //     $preperation_method_10 = $_POST['preperation_method_10'];
    //     $purpose_10 = $_POST['purpose_10'];
    //     $media_used_10 = $_POST['media_used_10'];
    //     $remarks_10 = $_POST['remarks_10'];
    //     $image_video_10 = $_POST['image_video_10'];
    //     $freezing_date_10 = $_POST['freezing_date_10'];
    //     $freezing_media_10 = $_POST['freezing_media_10'];
    //     $freezing_container_no_10 = $_POST['freezing_container_no_10'];
    //     $freezing_holder_no_10 = $_POST['freezing_holder_no_10'];
    //     $freezing_colour_10 = $_POST['freezing_colour_10'];
    //     $freezing_position_10 = $_POST['freezing_position_10'];
    //     $thawing_date_10 = $_POST['thawing_date_10'];
    //     $thawing_purpose_10 = $_POST['thawing_purpose_10'];
    //     $thawing_path_10 = $_POST['thawing_path_10'];
    //     $storage_renewal_date_10 = $_POST['storage_renewal_date_10'];
    //     $take_away_date_10 = $_POST['take_away_date_10'];
    //     $take_away_purpose_10 = $_POST['take_away_purpose_10'];
    //     $prepared_by_10 = $_POST['prepared_by_10'];
    //     $witness_1_10 = $_POST['witness_1_10'];
    //     $witness_2_10 = $_POST['witness_2_10'];
    //     $s_no_11 = $_POST['s_no_11'];
    //     $produced_at_center_11 = $_POST['produced_at_center_11'];
    //     $produced_at_home_11 = $_POST['produced_at_home_11'];
    //     $produced_at_sperm_retreival_11 = $_POST['produced_at_sperm_retreival_11'];
    //     $abstinence_11 = $_POST['abstinence_11'];
    //     $volume_11 = $_POST['volume_11'];
    //     $sperm_counted_pre_wash_11 = $_POST['sperm_counted_pre_wash_11'];
    //     $sperm_counted_post_wash_11 = $_POST['sperm_counted_post_wash_11'];
    //     $progressively_pre_wash_11 = $_POST['progressively_pre_wash_11'];
    //     $progressively_post_wash_11 = $_POST['progressively_post_wash_11'];
    //     $morphology_11 = $_POST['morphology_11'];
    //     $pus_cells_11 = $_POST['pus_cells_11'];
    //     $agglutination_11 = $_POST['agglutination_11'];
    //     $cands_11 = $_POST['cands_11'];
    //     $preperation_method_11 = $_POST['preperation_method_11'];
    //     $purpose_11 = $_POST['purpose_11'];
    //     $media_used_11 = $_POST['media_used_11'];
    //     $remarks_11 = $_POST['remarks_11'];
    //     $image_video_11 = $_POST['image_video_11'];
    //     $freezing_date_11 = $_POST['freezing_date_11'];
    //     $freezing_media_11 = $_POST['freezing_media_11'];
    //     $freezing_container_no_11 = $_POST['freezing_container_no_11'];
    //     $freezing_holder_no_11 = $_POST['freezing_holder_no_11'];
    //     $freezing_colour_11 = $_POST['freezing_colour_11'];
    //     $freezing_position_11 = $_POST['freezing_position_11'];
    //     $thawing_date_11 = $_POST['thawing_date_11'];
    //     $thawing_purpose_11 = $_POST['thawing_purpose_11'];
    //     $thawing_path_11 = $_POST['thawing_path_11'];
    //     $storage_renewal_date_11 = $_POST['storage_renewal_date_11'];
    //     $take_away_date_11 = $_POST['take_away_date_11'];
    //     $take_away_purpose_11 = $_POST['take_away_purpose_11'];
    //     $prepared_by_11 = $_POST['prepared_by_11'];
    //     $witness_1_11 = $_POST['witness_1_11'];
    //     $witness_2_11 = $_POST['witness_2_11'];
    //     $s_no_12 = $_POST['s_no_12'];
    //     $produced_at_center_12 = $_POST['produced_at_center_12'];
    //     $produced_at_home_12 = $_POST['produced_at_home_12'];
    //     $produced_at_sperm_retreival_12 = $_POST['produced_at_sperm_retreival_12'];
    //     $abstinence_12 = $_POST['abstinence_12'];
    //     $volume_12 = $_POST['volume_12'];
    //     $sperm_counted_pre_wash_12 = $_POST['sperm_counted_pre_wash_12'];
    //     $sperm_counted_post_wash_12 = $_POST['sperm_counted_post_wash_12'];
    //     $progressively_pre_wash_12 = $_POST['progressively_pre_wash_12'];
    //     $progressively_post_wash_12 = $_POST['progressively_post_wash_12'];
    //     $morphology_12 = $_POST['morphology_12'];
    //     $pus_cells_12 = $_POST['pus_cells_12'];
    //     $agglutination_12 = $_POST['agglutination_12'];
    //     $cands_12 = $_POST['cands_12'];
    //     $preperation_method_12 = $_POST['preperation_method_12'];
    //     $purpose_12 = $_POST['purpose_12'];
    //     $media_used_12 = $_POST['media_used_12'];
    //     $remarks_12 = $_POST['remarks_12'];
    //     $image_video_12 = $_POST['image_video_12'];
    //     $freezing_date_12 = $_POST['freezing_date_12'];
    //     $freezing_media_12 = $_POST['freezing_media_12'];
    //     $freezing_container_no_12 = $_POST['freezing_container_no_12'];
    //     $freezing_holder_no_12 = $_POST['freezing_holder_no_12'];
    //     $freezing_colour_12 = $_POST['freezing_colour_12'];
    //     $freezing_position_12 = $_POST['freezing_position_12'];
    //     $thawing_date_12 = $_POST['thawing_date_12'];
    //     $thawing_purpose_12 = $_POST['thawing_purpose_12'];
    //     $thawing_path_12 = $_POST['thawing_path_12'];
    //     $storage_renewal_date_12 = $_POST['storage_renewal_date_12'];
    //     $take_away_date_12 = $_POST['take_away_date_12'];
    //     $take_away_purpose_12 = $_POST['take_away_purpose_12'];
    //     $prepared_by_12 = $_POST['prepared_by_12'];
    //     $witness_1_12 = $_POST['witness_1_12'];
    //     $witness_2_12 = $_POST['witness_2_12'];
    //     $s_no_13 = $_POST['s_no_13'];
    //     $produced_at_center_13 = $_POST['produced_at_center_13'];
    //     $produced_at_home_13 = $_POST['produced_at_home_13'];
    //     $produced_at_sperm_retreival_13 = $_POST['produced_at_sperm_retreival_13'];
    //     $abstinence_13 = $_POST['abstinence_13'];
    //     $volume_13 = $_POST['volume_13'];
    //     $sperm_counted_pre_wash_13 = $_POST['sperm_counted_pre_wash_13'];
    //     $sperm_counted_post_wash_13 = $_POST['sperm_counted_post_wash_13'];
    //     $progressively_pre_wash_13 = $_POST['progressively_pre_wash_13'];
    //     $progressively_post_wash_13 = $_POST['progressively_post_wash_13'];
    //     $morphology_13 = $_POST['morphology_13'];
    //     $pus_cells_13 = $_POST['pus_cells_13'];
    //     $agglutination_13 = $_POST['agglutination_13'];
    //     $cands_13 = $_POST['cands_13'];
    //     $preperation_method_13 = $_POST['preperation_method_13'];
    //     $purpose_13 = $_POST['purpose_13'];
    //     $media_used_13 = $_POST['media_used_13'];
    //     $remarks_13 = $_POST['remarks_13'];
    //     $image_video_13 = $_POST['image_video_13'];
    //     $freezing_date_13 = $_POST['freezing_date_13'];
    //     $freezing_media_13 = $_POST['freezing_media_13'];
    //     $freezing_container_no_13 = $_POST['freezing_container_no_13'];
    //     $freezing_holder_no_13 = $_POST['freezing_holder_no_13'];
    //     $freezing_colour_13 = $_POST['freezing_colour_13'];
    //     $freezing_position_13 = $_POST['freezing_position_13'];
    //     $thawing_date_13 = $_POST['thawing_date_13'];
    //     $thawing_purpose_13 = $_POST['thawing_purpose_13'];
    //     $thawing_path_13 = $_POST['thawing_path_13'];
    //     $storage_renewal_date_13 = $_POST['storage_renewal_date_13'];
    //     $take_away_date_13 = $_POST['take_away_date_13'];
    //     $take_away_purpose_13 = $_POST['take_away_purpose_13'];
    //     $prepared_by_13 = $_POST['prepared_by_13'];
    //     $witness_1_13 = $_POST['witness_1_13'];
    //     $witness_2_13 = $_POST['witness_2_13'];
    //     $s_no_14 = $_POST['s_no_14'];
    //     $produced_at_center_14 = $_POST['produced_at_center_14'];
    //     $produced_at_home_14 = $_POST['produced_at_home_14'];
    //     $produced_at_sperm_retreival_14 = $_POST['produced_at_sperm_retreival_14'];
    //     $abstinence_14 = $_POST['abstinence_14'];
    //     $volume_14 = $_POST['volume_14'];
    //     $sperm_counted_pre_wash_14 = $_POST['sperm_counted_pre_wash_14'];
    //     $sperm_counted_post_wash_14 = $_POST['sperm_counted_post_wash_14'];
    //     $progressively_pre_wash_14 = $_POST['progressively_pre_wash_14'];
    //     $progressively_post_wash_14 = $_POST['progressively_post_wash_14'];
    //     $morphology_14 = $_POST['morphology_14'];
    //     $pus_cells_14 = $_POST['pus_cells_14'];
    //     $agglutination_14 = $_POST['agglutination_14'];
    //     $cands_14 = $_POST['cands_14'];
    //     $preperation_method_14 = $_POST['preperation_method_14'];
    //     $purpose_14 = $_POST['purpose_14'];
    //     $media_used_14 = $_POST['media_used_14'];
    //     $remarks_14 = $_POST['remarks_14'];
    //     $image_video_14 = $_POST['image_video_14'];
    //     $freezing_date_14 = $_POST['freezing_date_14'];
    //     $freezing_media_14 = $_POST['freezing_media_14'];
    //     $freezing_container_no_14 = $_POST['freezing_container_no_14'];
    //     $freezing_holder_no_14 = $_POST['freezing_holder_no_14'];
    //     $freezing_colour_14 = $_POST['freezing_colour_14'];
    //     $freezing_position_14 = $_POST['freezing_position_14'];
    //     $thawing_date_14 = $_POST['thawing_date_14'];
    //     $thawing_purpose_14 = $_POST['thawing_purpose_14'];
    //     $thawing_path_14 = $_POST['thawing_path_14'];
    //     $storage_renewal_date_14 = $_POST['storage_renewal_date_14'];
    //     $take_away_date_14 = $_POST['take_away_date_14'];
    //     $take_away_purpose_14 = $_POST['take_away_purpose_14'];
    //     $prepared_by_14 = $_POST['prepared_by_14'];
    //     $witness_1_14 = $_POST['witness_1_14'];
    //     $witness_2_14 = $_POST['witness_2_14'];
    //     $s_no_15 = $_POST['s_no_15'];
    //     $produced_at_center_15 = $_POST['produced_at_center_15'];
    //     $produced_at_home_15 = $_POST['produced_at_home_15'];
    //     $produced_at_sperm_retreival_15 = $_POST['produced_at_sperm_retreival_15'];
    //     $abstinence_15 = $_POST['abstinence_15'];
    //     $volume_15 = $_POST['volume_15'];
    //     $sperm_counted_pre_wash_15 = $_POST['sperm_counted_pre_wash_15'];
    //     $sperm_counted_post_wash_15 = $_POST['sperm_counted_post_wash_15'];
    //     $progressively_pre_wash_15 = $_POST['progressively_pre_wash_15'];
    //     $progressively_post_wash_15 = $_POST['progressively_post_wash_15'];
    //     $morphology_15 = $_POST['morphology_15'];
    //     $pus_cells_15 = $_POST['pus_cells_15'];
    //     $agglutination_15 = $_POST['agglutination_15'];
    //     $cands_15 = $_POST['cands_15'];
    //     $preperation_method_15 = $_POST['preperation_method_15'];
    //     $purpose_15 = $_POST['purpose_15'];
    //     $media_used_15 = $_POST['media_used_15'];
    //     $remarks_15 = $_POST['remarks_15'];
    //     $image_video_15 = $_POST['image_video_15'];
    //     $freezing_date_15 = $_POST['freezing_date_15'];
    //     $freezing_media_15 = $_POST['freezing_media_15'];
    //     $freezing_container_no_15 = $_POST['freezing_container_no_15'];
    //     $freezing_holder_no_15 = $_POST['freezing_holder_no_15'];
    //     $freezing_colour_15 = $_POST['freezing_colour_15'];
    //     $freezing_position_15 = $_POST['freezing_position_15'];
    //     $thawing_date_15 = $_POST['thawing_date_15'];
    //     $thawing_purpose_15 = $_POST['thawing_purpose_15'];
    //     $thawing_path_15 = $_POST['thawing_path_15'];
    //     $storage_renewal_date_15 = $_POST['storage_renewal_date_15'];
    //     $take_away_date_15 = $_POST['take_away_date_15'];
    //     $take_away_purpose_15 = $_POST['take_away_purpose_15'];
    //     $prepared_by_15 = $_POST['prepared_by_15'];
    //     $witness_1_15 = $_POST['witness_1_15'];
    //     $witness_2_15 = $_POST['witness_2_15'];
    //     $s_no_16 = $_POST['s_no_16'];
    //     $produced_at_center_16 = $_POST['produced_at_center_16'];
    //     $produced_at_home_16 = $_POST['produced_at_home_16'];
    //     $produced_at_sperm_retreival_16 = $_POST['produced_at_sperm_retreival_16'];
    //     $abstinence_16 = $_POST['abstinence_16'];
    //     $volume_16 = $_POST['volume_16'];
    //     $sperm_counted_pre_wash_16 = $_POST['sperm_counted_pre_wash_16'];
    //     $sperm_counted_post_wash_16 = $_POST['sperm_counted_post_wash_16'];
    //     $progressively_pre_wash_16 = $_POST['progressively_pre_wash_16'];
    //     $progressively_post_wash_16 = $_POST['progressively_post_wash_16'];
    //     $morphology_16 = $_POST['morphology_16'];
    //     $pus_cells_16 = $_POST['pus_cells_16'];
    //     $agglutination_16 = $_POST['agglutination_16'];
    //     $cands_16 = $_POST['cands_16'];
    //     $preperation_method_16 = $_POST['preperation_method_16'];
    //     $purpose_16 = $_POST['purpose_16'];
    //     $media_used_16 = $_POST['media_used_16'];
    //     $remarks_16 = $_POST['remarks_16'];
    //     $image_video_16 = $_POST['image_video_16'];
    //     $freezing_date_16 = $_POST['freezing_date_16'];
    //     $freezing_media_16 = $_POST['freezing_media_16'];
    //     $freezing_container_no_16 = $_POST['freezing_container_no_16'];
    //     $freezing_holder_no_16 = $_POST['freezing_holder_no_16'];
    //     $freezing_colour_16 = $_POST['freezing_colour_16'];
    //     $freezing_position_16 = $_POST['freezing_position_16'];
    //     $thawing_date_16 = $_POST['thawing_date_16'];
    //     $thawing_purpose_16 = $_POST['thawing_purpose_16'];
    //     $thawing_path_16 = $_POST['thawing_path_16'];
    //     $storage_renewal_date_16 = $_POST['storage_renewal_date_16'];
    //     $take_away_date_16 = $_POST['take_away_date_16'];
    //     $take_away_purpose_16 = $_POST['take_away_purpose_16'];
    //     $prepared_by_16 = $_POST['prepared_by_16'];
    //     $witness_1_16 = $_POST['witness_1_16'];
    //     $witness_2_16 = $_POST['witness_2_16'];
    //     $s_no_17 = $_POST['s_no_17'];
    //     $produced_at_center_17 = $_POST['produced_at_center_17'];
    //     $produced_at_home_17 = $_POST['produced_at_home_17'];
    //     $produced_at_sperm_retreival_17 = $_POST['produced_at_sperm_retreival_17'];
    //     $abstinence_17 = $_POST['abstinence_17'];
    //     $volume_17 = $_POST['volume_17'];
    //     $sperm_counted_pre_wash_17 = $_POST['sperm_counted_pre_wash_17'];
    //     $sperm_counted_post_wash_17 = $_POST['sperm_counted_post_wash_17'];
    //     $progressively_pre_wash_17 = $_POST['progressively_pre_wash_17'];
    //     $progressively_post_wash_17 = $_POST['progressively_post_wash_17'];
    //     $morphology_17 = $_POST['morphology_17'];
    //     $pus_cells_17 = $_POST['pus_cells_17'];
    //     $agglutination_17 = $_POST['agglutination_17'];
    //     $cands_17 = $_POST['cands_17'];
    //     $preperation_method_17 = $_POST['preperation_method_17'];
    //     $purpose_17 = $_POST['purpose_17'];
    //     $media_used_17 = $_POST['media_used_17'];
    //     $remarks_17 = $_POST['remarks_17'];
    //     $image_video_17 = $_POST['image_video_17'];
    //     $freezing_date_17 = $_POST['freezing_date_17'];
    //     $freezing_media_17 = $_POST['freezing_media_17'];
    //     $freezing_container_no_17 = $_POST['freezing_container_no_17'];
    //     $freezing_holder_no_17 = $_POST['freezing_holder_no_17'];
    //     $freezing_colour_17 = $_POST['freezing_colour_17'];
    //     $freezing_position_17 = $_POST['freezing_position_17'];
    //     $thawing_date_17 = $_POST['thawing_date_17'];
    //     $thawing_purpose_17 = $_POST['thawing_purpose_17'];
    //     $thawing_path_17 = $_POST['thawing_path_17'];
    //     $storage_renewal_date_17 = $_POST['storage_renewal_date_17'];
    //     $take_away_date_17 = $_POST['take_away_date_17'];
    //     $take_away_purpose_17 = $_POST['take_away_purpose_17'];
    //     $prepared_by_17 = $_POST['prepared_by_17'];
    //     $witness_1_17 = $_POST['witness_1_17'];
    //     $witness_2_17 = $_POST['witness_2_17'];
    //     $s_no_18 = $_POST['s_no_18'];
    //     $produced_at_center_18 = $_POST['produced_at_center_18'];
    //     $produced_at_home_18 = $_POST['produced_at_home_18'];
    //     $produced_at_sperm_retreival_18 = $_POST['produced_at_sperm_retreival_18'];
    //     $abstinence_18 = $_POST['abstinence_18'];
    //     $volume_18 = $_POST['volume_18'];
    //     $sperm_counted_pre_wash_18 = $_POST['sperm_counted_pre_wash_18'];
    //     $sperm_counted_post_wash_18 = $_POST['sperm_counted_post_wash_18'];
    //     $progressively_pre_wash_18 = $_POST['progressively_pre_wash_18'];
    //     $progressively_post_wash_18 = $_POST['progressively_post_wash_18'];
    //     $morphology_18 = $_POST['morphology_18'];
    //     $pus_cells_18 = $_POST['pus_cells_18'];
    //     $agglutination_18 = $_POST['agglutination_18'];
    //     $cands_18 = $_POST['cands_18'];
    //     $preperation_method_18 = $_POST['preperation_method_18'];
    //     $purpose_18 = $_POST['purpose_18'];
    //     $media_used_18 = $_POST['media_used_18'];
    //     $remarks_18 = $_POST['remarks_18'];
    //     $image_video_18 = $_POST['image_video_18'];
    //     $freezing_date_18 = $_POST['freezing_date_18'];
    //     $freezing_media_18 = $_POST['freezing_media_18'];
    //     $freezing_container_no_18 = $_POST['freezing_container_no_18'];
    //     $freezing_holder_no_18 = $_POST['freezing_holder_no_18'];
    //     $freezing_colour_18 = $_POST['freezing_colour_18'];
    //     $freezing_position_18 = $_POST['freezing_position_18'];
    //     $thawing_date_18 = $_POST['thawing_date_18'];
    //     $thawing_purpose_18 = $_POST['thawing_purpose_18'];
    //     $thawing_path_18 = $_POST['thawing_path_18'];
    //     $storage_renewal_date_18 = $_POST['storage_renewal_date_18'];
    //     $take_away_date_18 = $_POST['take_away_date_18'];
    //     $take_away_purpose_18 = $_POST['take_away_purpose_18'];
    //     $prepared_by_18 = $_POST['prepared_by_18'];
    //     $witness_1_18 = $_POST['witness_1_18'];
    //     $witness_2_18 = $_POST['witness_2_18'];
    //     $s_no_19 = $_POST['s_no_19'];
    //     $produced_at_center_19 = $_POST['produced_at_center_19'];
    //     $produced_at_home_19 = $_POST['produced_at_home_19'];
    //     $produced_at_sperm_retreival_19 = $_POST['produced_at_sperm_retreival_19'];
    //     $abstinence_19 = $_POST['abstinence_19'];
    //     $volume_19 = $_POST['volume_19'];
    //     $sperm_counted_pre_wash_19 = $_POST['sperm_counted_pre_wash_19'];
    //     $sperm_counted_post_wash_19 = $_POST['sperm_counted_post_wash_19'];
    //     $progressively_pre_wash_19 = $_POST['progressively_pre_wash_19'];
    //     $progressively_post_wash_19 = $_POST['progressively_post_wash_19'];
    //     $morphology_19 = $_POST['morphology_19'];
    //     $pus_cells_19 = $_POST['pus_cells_19'];
    //     $agglutination_19 = $_POST['agglutination_19'];
    //     $cands_19 = $_POST['cands_19'];
    //     $preperation_method_19 = $_POST['preperation_method_19'];
    //     $purpose_19 = $_POST['purpose_19'];
    //     $media_used_19 = $_POST['media_used_19'];
    //     $remarks_19 = $_POST['remarks_19'];
    //     $image_video_19 = $_POST['image_video_19'];
    //     $freezing_date_19 = $_POST['freezing_date_19'];
    //     $freezing_media_19 = $_POST['freezing_media_19'];
    //     $freezing_container_no_19 = $_POST['freezing_container_no_19'];
    //     $freezing_holder_no_19 = $_POST['freezing_holder_no_19'];
    //     $freezing_colour_19 = $_POST['freezing_colour_19'];
    //     $freezing_position_19 = $_POST['freezing_position_19'];
    //     $thawing_date_19 = $_POST['thawing_date_19'];
    //     $thawing_purpose_19 = $_POST['thawing_purpose_19'];
    //     $thawing_path_19 = $_POST['thawing_path_19'];
    //     $storage_renewal_date_19 = $_POST['storage_renewal_date_19'];
    //     $take_away_date_19 = $_POST['take_away_date_19'];
    //     $take_away_purpose_19 = $_POST['take_away_purpose_19'];
    //     $prepared_by_19 = $_POST['prepared_by_19'];
    //     $witness_1_19 = $_POST['witness_1_19'];
    //     $witness_2_19 = $_POST['witness_2_19'];
    //     $s_no_20 = $_POST['s_no_20'];
    //     $produced_at_center_20 = $_POST['produced_at_center_20'];
    //     $produced_at_home_20 = $_POST['produced_at_home_20'];
    //     $produced_at_sperm_retreival_20 = $_POST['produced_at_sperm_retreival_20'];
    //     $abstinence_20 = $_POST['abstinence_20'];
    //     $volume_20 = $_POST['volume_20'];
    //     $sperm_counted_pre_wash_20 = $_POST['sperm_counted_pre_wash_20'];
    //     $sperm_counted_post_wash_20 = $_POST['sperm_counted_post_wash_20'];
    //     $progressively_pre_wash_20 = $_POST['progressively_pre_wash_20'];
    //     $progressively_post_wash_20 = $_POST['progressively_post_wash_20'];
    //     $morphology_20 = $_POST['morphology_20'];
    //     $pus_cells_20 = $_POST['pus_cells_20'];
    //     $agglutination_20 = $_POST['agglutination_20'];
    //     $cands_20 = $_POST['cands_20'];
    //     $preperation_method_20 = $_POST['preperation_method_20'];
    //     $purpose_20 = $_POST['purpose_20'];
    //     $media_used_20 = $_POST['media_used_20'];
    //     $remarks_20 = $_POST['remarks_20'];
    //     $image_video_20 = $_POST['image_video_20'];
    //     $freezing_date_20 = $_POST['freezing_date_20'];
    //     $freezing_media_20 = $_POST['freezing_media_20'];
    //     $freezing_container_no_20 = $_POST['freezing_container_no_20'];
    //     $freezing_holder_no_20 = $_POST['freezing_holder_no_20'];
    //     $freezing_colour_20 = $_POST['freezing_colour_20'];
    //     $freezing_position_20 = $_POST['freezing_position_20'];
    //     $thawing_date_20 = $_POST['thawing_date_20'];
    //     $thawing_purpose_20 = $_POST['thawing_purpose_20'];
    //     $thawing_path_20 = $_POST['thawing_path_20'];
    //     $storage_renewal_date_20 = $_POST['storage_renewal_date_20'];
    //     $take_away_date_20 = $_POST['take_away_date_20'];
    //     $take_away_purpose_20 = $_POST['take_away_purpose_20'];
    //     $prepared_by_20 = $_POST['prepared_by_20'];
    //     $witness_1_20 = $_POST['witness_1_20'];
    //     $witness_2_20 = $_POST['witness_2_20'];
    //     $partners_name = $_POST['partners_name'];
    //     $art_bank_reg_no = $_POST['art_bank_reg_no'];
    //     $form_id = $_POST['form_id'];
    //     $donor_d = $_POST['donor_d'];

    //     // connect to mysql database using mysqli
        

    //     // mysql query to insert data
    //     $query = "INSERT INTO `sperm_preparation`(`patient_id`, `receipt_number`, `status`,`s_no_`,`produced_at_center_`,`produced_at_home_`,`produced_at_sperm_retreival_`,`abstinence_`,`volume_`,`sperm_counted_pre_wash_`,`sperm_counted_post_wash_`,`progressively_pre_wash_`,`progressively_post_wash_`,`morphology_`,`pus_cells_`,`agglutination_`,`cands_`,`preperation_method_`,`purpose_`,`media_used_`,`remarks_`,`image_video_`,`freezing_date_`,`freezing_media_`,`freezing_container_no_`,`freezing_holder_no_`,`freezing_colour_`,`freezing_position_`,`thawing_date_`,`thawing_purpose_`,`thawing_path_`,`storage_renewal_date_`,`take_away_date_`,`take_away_purpose_`,`prepared_by_`,`witness_1_`,`witness_2_`,`s_no_1`,`produced_at_center_1`,`produced_at_home_1`,`produced_at_sperm_retreival_1`,`abstinence_1`,`volume_1`,`sperm_counted_pre_wash_1`,`sperm_counted_post_wash_1`,`progressively_pre_wash_1`,`progressively_post_wash_1`,`morphology_1`,`pus_cells_1`,`agglutination_1`,`cands_1`,`preperation_method_1`,`purpose_1`,`media_used_1`,`remarks_1`,`image_video_1`,`freezing_date_1`,`freezing_media_1`,`freezing_container_no_1`,`freezing_holder_no_1`,`freezing_colour_1`,`freezing_position_1`,`thawing_date_1`,`thawing_purpose_1`,`thawing_path_1`,`storage_renewal_date_1`,`take_away_date_1`,`take_away_purpose_1`,`prepared_by_1`,`witness_1_1`,`witness_2_1`,`s_no_2`,`produced_at_center_2`,`produced_at_home_2`,`produced_at_sperm_retreival_2`,`abstinence_2`,`volume_2`,`sperm_counted_pre_wash_2`,`sperm_counted_post_wash_2`,`progressively_pre_wash_2`,`progressively_post_wash_2`,`morphology_2`,`pus_cells_2`,`agglutination_2`,`cands_2`,`preperation_method_2`,`purpose_2`,`media_used_2`,`remarks_2`,`image_video_2`,`freezing_date_2`,`freezing_media_2`,`freezing_container_no_2`,`freezing_holder_no_2`,`freezing_colour_2`,`freezing_position_2`,`thawing_date_2`,`thawing_purpose_2`,`thawing_path_2`,`storage_renewal_date_2`,`take_away_date_2`,`take_away_purpose_2`,`prepared_by_2`,`witness_1_2`,`witness_2_2`,`s_no_3`,`produced_at_center_3`,`produced_at_home_3`,`produced_at_sperm_retreival_3`,`abstinence_3`,`volume_3`,`sperm_counted_pre_wash_3`,`sperm_counted_post_wash_3`,`progressively_pre_wash_3`,`progressively_post_wash_3`,`morphology_3`,`pus_cells_3`,`agglutination_3`,`cands_3`,`preperation_method_3`,`purpose_3`,`media_used_3`,`remarks_3`,`image_video_3`,`freezing_date_3`,`freezing_media_3`,`freezing_container_no_3`,`freezing_holder_no_3`,`freezing_colour_3`,`freezing_position_3`,`thawing_date_3`,`thawing_purpose_3`,`thawing_path_3`,`storage_renewal_date_3`,`take_away_date_3`,`take_away_purpose_3`,`prepared_by_3`,`witness_1_3`,`witness_2_3`,`s_no_4`,`produced_at_center_4`,`produced_at_home_4`,`produced_at_sperm_retreival_4`,`abstinence_4`,`volume_4`,`sperm_counted_pre_wash_4`,`sperm_counted_post_wash_4`,`progressively_pre_wash_4`,`progressively_post_wash_4`,`morphology_4`,`pus_cells_4`,`agglutination_4`,`cands_4`,`preperation_method_4`,`purpose_4`,`media_used_4`,`remarks_4`,`image_video_4`,`freezing_date_4`,`freezing_media_4`,`freezing_container_no_4`,`freezing_holder_no_4`,`freezing_colour_4`,`freezing_position_4`,`thawing_date_4`,`thawing_purpose_4`,`thawing_path_4`,`storage_renewal_date_4`,`take_away_date_4`,`take_away_purpose_4`,`prepared_by_4`,`witness_1_4`,`witness_2_4`,`s_no_5`,`produced_at_center_5`,`produced_at_home_5`,`produced_at_sperm_retreival_5`,`abstinence_5`,`volume_5`,`sperm_counted_pre_wash_5`,`sperm_counted_post_wash_5`,`progressively_pre_wash_5`,`progressively_post_wash_5`,`morphology_5`,`pus_cells_5`,`agglutination_5`,`cands_5`,`preperation_method_5`,`purpose_5`,`media_used_5`,`remarks_5`,`image_video_5`,`freezing_date_5`,`freezing_media_5`,`freezing_container_no_5`,`freezing_holder_no_5`,`freezing_colour_5`,`freezing_position_5`,`thawing_date_5`,`thawing_purpose_5`,`thawing_path_5`,`storage_renewal_date_5`,`take_away_date_5`,`take_away_purpose_5`,`prepared_by_5`,`witness_1_5`,`witness_2_5`,`s_no_6`,`produced_at_center_6`,`produced_at_home_6`,`produced_at_sperm_retreival_6`,`abstinence_6`,`volume_6`,`sperm_counted_pre_wash_6`,`sperm_counted_post_wash_6`,`progressively_pre_wash_6`,`progressively_post_wash_6`,`morphology_6`,`pus_cells_6`,`agglutination_6`,`cands_6`,`preperation_method_6`,`purpose_6`,`media_used_6`,`remarks_6`,`image_video_6`,`freezing_date_6`,`freezing_media_6`,`freezing_container_no_6`,`freezing_holder_no_6`,`freezing_colour_6`,`freezing_position_6`,`thawing_date_6`,`thawing_purpose_6`,`thawing_path_6`,`storage_renewal_date_6`,`take_away_date_6`,`take_away_purpose_6`,`prepared_by_6`,`witness_1_6`,`witness_2_6`,`s_no_7`,`produced_at_center_7`,`produced_at_home_7`,`produced_at_sperm_retreival_7`,`abstinence_7`,`volume_7`,`sperm_counted_pre_wash_7`,`sperm_counted_post_wash_7`,`progressively_pre_wash_7`,`progressively_post_wash_7`,`morphology_7`,`pus_cells_7`,`agglutination_7`,`cands_7`,`preperation_method_7`,`purpose_7`,`media_used_7`,`remarks_7`,`image_video_7`,`freezing_date_7`,`freezing_media_7`,`freezing_container_no_7`,`freezing_holder_no_7`,`freezing_colour_7`,`freezing_position_7`,`thawing_date_7`,`thawing_purpose_7`,`thawing_path_7`,`storage_renewal_date_7`,`take_away_date_7`,`take_away_purpose_7`,`prepared_by_7`,`witness_1_7`,`witness_2_7`,`s_no_8`,`produced_at_center_8`,`produced_at_home_8`,`produced_at_sperm_retreival_8`,`abstinence_8`,`volume_8`,`sperm_counted_pre_wash_8`,`sperm_counted_post_wash_8`,`progressively_pre_wash_8`,`progressively_post_wash_8`,`morphology_8`,`pus_cells_8`,`agglutination_8`,`cands_8`,`preperation_method_8`,`purpose_8`,`media_used_8`,`remarks_8`,`image_video_8`,`freezing_date_8`,`freezing_media_8`,`freezing_container_no_8`,`freezing_holder_no_8`,`freezing_colour_8`,`freezing_position_8`,`thawing_date_8`,`thawing_purpose_8`,`thawing_path_8`,`storage_renewal_date_8`,`take_away_date_8`,`take_away_purpose_8`,`prepared_by_8`,`witness_1_8`,`witness_2_8`,`s_no_9`,`produced_at_center_9`,`produced_at_home_9`,`produced_at_sperm_retreival_9`,`abstinence_9`,`volume_9`,`sperm_counted_pre_wash_9`,`sperm_counted_post_wash_9`,`progressively_pre_wash_9`,`progressively_post_wash_9`,`morphology_9`,`pus_cells_9`,`agglutination_9`,`cands_9`,`preperation_method_9`,`purpose_9`,`media_used_9`,`remarks_9`,`image_video_9`,`freezing_date_9`,`freezing_media_9`,`freezing_container_no_9`,`freezing_holder_no_9`,`freezing_colour_9`,`freezing_position_9`,`thawing_date_9`,`thawing_purpose_9`,`thawing_path_9`,`storage_renewal_date_9`,`take_away_date_9`,`take_away_purpose_9`,`prepared_by_9`,`witness_1_9`,`witness_2_9`,`s_no_10`,`produced_at_center_10`,`produced_at_home_10`,`produced_at_sperm_retreival_10`,`abstinence_10`,`volume_10`,`sperm_counted_pre_wash_10`,`sperm_counted_post_wash_10`,`progressively_pre_wash_10`,`progressively_post_wash_10`,`morphology_10`,`pus_cells_10`,`agglutination_10`,`cands_10`,`preperation_method_10`,`purpose_10`,`media_used_10`,`remarks_10`,`image_video_10`,`freezing_date_10`,`freezing_media_10`,`freezing_container_no_10`,`freezing_holder_no_10`,`freezing_colour_10`,`freezing_position_10`,`thawing_date_10`,`thawing_purpose_10`,`thawing_path_10`,`storage_renewal_date_10`,`take_away_date_10`,`take_away_purpose_10`,`prepared_by_10`,`witness_1_10`,`witness_2_10`,`s_no_11`,`produced_at_center_11`,`produced_at_home_11`,`produced_at_sperm_retreival_11`,`abstinence_11`,`volume_11`,`sperm_counted_pre_wash_11`,`sperm_counted_post_wash_11`,`progressively_pre_wash_11`,`progressively_post_wash_11`,`morphology_11`,`pus_cells_11`,`agglutination_11`,`cands_11`,`preperation_method_11`,`purpose_11`,`media_used_11`,`remarks_11`,`image_video_11`,`freezing_date_11`,`freezing_media_11`,`freezing_container_no_11`,`freezing_holder_no_11`,`freezing_colour_11`,`freezing_position_11`,`thawing_date_11`,`thawing_purpose_11`,`thawing_path_11`,`storage_renewal_date_11`,`take_away_date_11`,`take_away_purpose_11`,`prepared_by_11`,`witness_1_11`,`witness_2_11`,`s_no_12`,`produced_at_center_12`,`produced_at_home_12`,`produced_at_sperm_retreival_12`,`abstinence_12`,`volume_12`,`sperm_counted_pre_wash_12`,`sperm_counted_post_wash_12`,`progressively_pre_wash_12`,`progressively_post_wash_12`,`morphology_12`,`pus_cells_12`,`agglutination_12`,`cands_12`,`preperation_method_12`,`purpose_12`,`media_used_12`,`remarks_12`,`image_video_12`,`freezing_date_12`,`freezing_media_12`,`freezing_container_no_12`,`freezing_holder_no_12`,`freezing_colour_12`,`freezing_position_12`,`thawing_date_12`,`thawing_purpose_12`,`thawing_path_12`,`storage_renewal_date_12`,`take_away_date_12`,`take_away_purpose_12`,`prepared_by_12`,`witness_1_12`,`witness_2_12`,`s_no_13`,`produced_at_center_13`,`produced_at_home_13`,`produced_at_sperm_retreival_13`,`abstinence_13`,`volume_13`,`sperm_counted_pre_wash_13`,`sperm_counted_post_wash_13`,`progressively_pre_wash_13`,`progressively_post_wash_13`,`morphology_13`,`pus_cells_13`,`agglutination_13`,`cands_13`,`preperation_method_13`,`purpose_13`,`media_used_13`,`remarks_13`,`image_video_13`,`freezing_date_13`,`freezing_media_13`,`freezing_container_no_13`,`freezing_holder_no_13`,`freezing_colour_13`,`freezing_position_13`,`thawing_date_13`,`thawing_purpose_13`,`thawing_path_13`,`storage_renewal_date_13`,`take_away_date_13`,`take_away_purpose_13`,`prepared_by_13`,`witness_1_13`,`witness_2_13`,`s_no_14`,`produced_at_center_14`,`produced_at_home_14`,`produced_at_sperm_retreival_14`,`abstinence_14`,`volume_14`,`sperm_counted_pre_wash_14`,`sperm_counted_post_wash_14`,`progressively_pre_wash_14`,`progressively_post_wash_14`,`morphology_14`,`pus_cells_14`,`agglutination_14`,`cands_14`,`preperation_method_14`,`purpose_14`,`media_used_14`,`remarks_14`,`image_video_14`,`freezing_date_14`,`freezing_media_14`,`freezing_container_no_14`,`freezing_holder_no_14`,`freezing_colour_14`,`freezing_position_14`,`thawing_date_14`,`thawing_purpose_14`,`thawing_path_14`,`storage_renewal_date_14`,`take_away_date_14`,`take_away_purpose_14`,`prepared_by_14`,`witness_1_14`,`witness_2_14`,`s_no_15`,`produced_at_center_15`,`produced_at_home_15`,`produced_at_sperm_retreival_15`,`abstinence_15`,`volume_15`,`sperm_counted_pre_wash_15`,`sperm_counted_post_wash_15`,`progressively_pre_wash_15`,`progressively_post_wash_15`,`morphology_15`,`pus_cells_15`,`agglutination_15`,`cands_15`,`preperation_method_15`,`purpose_15`,`media_used_15`,`remarks_15`,`image_video_15`,`freezing_date_15`,`freezing_media_15`,`freezing_container_no_15`,`freezing_holder_no_15`,`freezing_colour_15`,`freezing_position_15`,`thawing_date_15`,`thawing_purpose_15`,`thawing_path_15`,`storage_renewal_date_15`,`take_away_date_15`,`take_away_purpose_15`,`prepared_by_15`,`witness_1_15`,`witness_2_15`,`s_no_16`,`produced_at_center_16`,`produced_at_home_16`,`produced_at_sperm_retreival_16`,`abstinence_16`,`volume_16`,`sperm_counted_pre_wash_16`,`sperm_counted_post_wash_16`,`progressively_pre_wash_16`,`progressively_post_wash_16`,`morphology_16`,`pus_cells_16`,`agglutination_16`,`cands_16`,`preperation_method_16`,`purpose_16`,`media_used_16`,`remarks_16`,`image_video_16`,`freezing_date_16`,`freezing_media_16`,`freezing_container_no_16`,`freezing_holder_no_16`,`freezing_colour_16`,`freezing_position_16`,`thawing_date_16`,`thawing_purpose_16`,`thawing_path_16`,`storage_renewal_date_16`,`take_away_date_16`,`take_away_purpose_16`,`prepared_by_16`,`witness_1_16`,`witness_2_16`,`s_no_17`,`produced_at_center_17`,`produced_at_home_17`,`produced_at_sperm_retreival_17`,`abstinence_17`,`volume_17`,`sperm_counted_pre_wash_17`,`sperm_counted_post_wash_17`,`progressively_pre_wash_17`,`progressively_post_wash_17`,`morphology_17`,`pus_cells_17`,`agglutination_17`,`cands_17`,`preperation_method_17`,`purpose_17`,`media_used_17`,`remarks_17`,`image_video_17`,`freezing_date_17`,`freezing_media_17`,`freezing_container_no_17`,`freezing_holder_no_17`,`freezing_colour_17`,`freezing_position_17`,`thawing_date_17`,`thawing_purpose_17`,`thawing_path_17`,`storage_renewal_date_17`,`take_away_date_17`,`take_away_purpose_17`,`prepared_by_17`,`witness_1_17`,`witness_2_17`,`s_no_18`,`produced_at_center_18`,`produced_at_home_18`,`produced_at_sperm_retreival_18`,`abstinence_18`,`volume_18`,`sperm_counted_pre_wash_18`,`sperm_counted_post_wash_18`,`progressively_pre_wash_18`,`progressively_post_wash_18`,`morphology_18`,`pus_cells_18`,`agglutination_18`,`cands_18`,`preperation_method_18`,`purpose_18`,`media_used_18`,`remarks_18`,`image_video_18`,`freezing_date_18`,`freezing_media_18`,`freezing_container_no_18`,`freezing_holder_no_18`,`freezing_colour_18`,`freezing_position_18`,`thawing_date_18`,`thawing_purpose_18`,`thawing_path_18`,`storage_renewal_date_18`,`take_away_date_18`,`take_away_purpose_18`,`prepared_by_18`,`witness_1_18`,`witness_2_18`,`s_no_19`,`produced_at_center_19`,`produced_at_home_19`,`produced_at_sperm_retreival_19`,`abstinence_19`,`volume_19`,`sperm_counted_pre_wash_19`,`sperm_counted_post_wash_19`,`progressively_pre_wash_19`,`progressively_post_wash_19`,`morphology_19`,`pus_cells_19`,`agglutination_19`,`cands_19`,`preperation_method_19`,`purpose_19`,`media_used_19`,`remarks_19`,`image_video_19`,`freezing_date_19`,`freezing_media_19`,`freezing_container_no_19`,`freezing_holder_no_19`,`freezing_colour_19`,`freezing_position_19`,`thawing_date_19`,`thawing_purpose_19`,`thawing_path_19`,`storage_renewal_date_19`,`take_away_date_19`,`take_away_purpose_19`,`prepared_by_19`,`witness_1_19`,`witness_2_19`,`s_no_20`,`produced_at_center_20`,`produced_at_home_20`,`produced_at_sperm_retreival_20`,`abstinence_20`,`volume_20`,`sperm_counted_pre_wash_20`,`sperm_counted_post_wash_20`,`progressively_pre_wash_20`,`progressively_post_wash_20`,`morphology_20`,`pus_cells_20`,`agglutination_20`,`cands_20`,`preperation_method_20`,`purpose_20`,`media_used_20`,`remarks_20`,`image_video_20`,`freezing_date_20`,`freezing_media_20`,`freezing_container_no_20`,`freezing_holder_no_20`,`freezing_colour_20`,`freezing_position_20`,`thawing_date_20`,`thawing_purpose_20`,`thawing_path_20`,`storage_renewal_date_20`,`take_away_date_20`,`take_away_purpose_20`,`prepared_by_20`,`witness_1_20`,`witness_2_20`,`partners_name`,`art_bank_reg_no`,`form_id`,`donor_d`) VALUES ('$patient_id','$receipt_number','$status','$s_no_','$produced_at_center_','$produced_at_home_','$produced_at_sperm_retreival_','$abstinence_','$volume_','$sperm_counted_pre_wash_','$sperm_counted_post_wash_','$progressively_pre_wash_','$progressively_post_wash_','$morphology_','$pus_cells_','$agglutination_','$cands_','$preperation_method_','$purpose_','$media_used_','$remarks_','$image_video_','$freezing_date_','$freezing_media_','$freezing_container_no_','$freezing_holder_no_','$freezing_colour_','$freezing_position_','$thawing_date_','$thawing_purpose_','$thawing_path_','$storage_renewal_date_','$take_away_date_','$take_away_purpose_','$prepared_by_','$witness_1_','$witness_2_','$s_no_1','$produced_at_center_1','$produced_at_home_1','$produced_at_sperm_retreival_1','$abstinence_1','$volume_1','$sperm_counted_pre_wash_1','$sperm_counted_post_wash_1','$progressively_pre_wash_1','$progressively_post_wash_1','$morphology_1','$pus_cells_1','$agglutination_1','$cands_1','$preperation_method_1','$purpose_1','$media_used_1','$remarks_1','$image_video_1','$freezing_date_1','$freezing_media_1','$freezing_container_no_1','$freezing_holder_no_1','$freezing_colour_1','$freezing_position_1','$thawing_date_1','$thawing_purpose_1','$thawing_path_1','$storage_renewal_date_1','$take_away_date_1','$take_away_purpose_1','$prepared_by_1','$witness_1_1','$witness_2_1','$s_no_2','$produced_at_center_2','$produced_at_home_2','$produced_at_sperm_retreival_2','$abstinence_2','$volume_2','$sperm_counted_pre_wash_2','$sperm_counted_post_wash_2','$progressively_pre_wash_2','$progressively_post_wash_2','$morphology_2','$pus_cells_2','$agglutination_2','$cands_2','$preperation_method_2','$purpose_2','$media_used_2','$remarks_2','$image_video_2','$freezing_date_2','$freezing_media_2','$freezing_container_no_2','$freezing_holder_no_2','$freezing_colour_2','$freezing_position_2','$thawing_date_2','$thawing_purpose_2','$thawing_path_2','$storage_renewal_date_2','$take_away_date_2','$take_away_purpose_2','$prepared_by_2','$witness_1_2','$witness_2_2','$s_no_3','$produced_at_center_3','$produced_at_home_3','$produced_at_sperm_retreival_3','$abstinence_3','$volume_3','$sperm_counted_pre_wash_3','$sperm_counted_post_wash_3','$progressively_pre_wash_3','$progressively_post_wash_3','$morphology_3','$pus_cells_3','$agglutination_3','$cands_3','$preperation_method_3','$purpose_3','$media_used_3','$remarks_3','$image_video_3','$freezing_date_3','$freezing_media_3','$freezing_container_no_3','$freezing_holder_no_3','$freezing_colour_3','$freezing_position_3','$thawing_date_3','$thawing_purpose_3','$thawing_path_3','$storage_renewal_date_3','$take_away_date_3','$take_away_purpose_3','$prepared_by_3','$witness_1_3','$witness_2_3','$s_no_4','$produced_at_center_4','$produced_at_home_4','$produced_at_sperm_retreival_4','$abstinence_4','$volume_4','$sperm_counted_pre_wash_4','$sperm_counted_post_wash_4','$progressively_pre_wash_4','$progressively_post_wash_4','$morphology_4','$pus_cells_4','$agglutination_4','$cands_4','$preperation_method_4','$purpose_4','$media_used_4','$remarks_4','$image_video_4','$freezing_date_4','$freezing_media_4','$freezing_container_no_4','$freezing_holder_no_4','$freezing_colour_4','$freezing_position_4','$thawing_date_4','$thawing_purpose_4','$thawing_path_4','$storage_renewal_date_4','$take_away_date_4','$take_away_purpose_4','$prepared_by_4','$witness_1_4','$witness_2_4','$s_no_5','$produced_at_center_5','$produced_at_home_5','$produced_at_sperm_retreival_5','$abstinence_5','$volume_5','$sperm_counted_pre_wash_5','$sperm_counted_post_wash_5','$progressively_pre_wash_5','$progressively_post_wash_5','$morphology_5','$pus_cells_5','$agglutination_5','$cands_5','$preperation_method_5','$purpose_5','$media_used_5','$remarks_5','$image_video_5','$freezing_date_5','$freezing_media_5','$freezing_container_no_5','$freezing_holder_no_5','$freezing_colour_5','$freezing_position_5','$thawing_date_5','$thawing_purpose_5','$thawing_path_5','$storage_renewal_date_5','$take_away_date_5','$take_away_purpose_5','$prepared_by_5','$witness_1_5','$witness_2_5','$s_no_6','$produced_at_center_6','$produced_at_home_6','$produced_at_sperm_retreival_6','$abstinence_6','$volume_6','$sperm_counted_pre_wash_6','$sperm_counted_post_wash_6','$progressively_pre_wash_6','$progressively_post_wash_6','$morphology_6','$pus_cells_6','$agglutination_6','$cands_6','$preperation_method_6','$purpose_6','$media_used_6','$remarks_6','$image_video_6','$freezing_date_6','$freezing_media_6','$freezing_container_no_6','$freezing_holder_no_6','$freezing_colour_6','$freezing_position_6','$thawing_date_6','$thawing_purpose_6','$thawing_path_6','$storage_renewal_date_6','$take_away_date_6','$take_away_purpose_6','$prepared_by_6','$witness_1_6','$witness_2_6','$s_no_7','$produced_at_center_7','$produced_at_home_7','$produced_at_sperm_retreival_7','$abstinence_7','$volume_7','$sperm_counted_pre_wash_7','$sperm_counted_post_wash_7','$progressively_pre_wash_7','$progressively_post_wash_7','$morphology_7','$pus_cells_7','$agglutination_7','$cands_7','$preperation_method_7','$purpose_7','$media_used_7','$remarks_7','$image_video_7','$freezing_date_7','$freezing_media_7','$freezing_container_no_7','$freezing_holder_no_7','$freezing_colour_7','$freezing_position_7','$thawing_date_7','$thawing_purpose_7','$thawing_path_7','$storage_renewal_date_7','$take_away_date_7','$take_away_purpose_7','$prepared_by_7','$witness_1_7','$witness_2_7','$s_no_8','$produced_at_center_8','$produced_at_home_8','$produced_at_sperm_retreival_8','$abstinence_8','$volume_8','$sperm_counted_pre_wash_8','$sperm_counted_post_wash_8','$progressively_pre_wash_8','$progressively_post_wash_8','$morphology_8','$pus_cells_8','$agglutination_8','$cands_8','$preperation_method_8','$purpose_8','$media_used_8','$remarks_8','$image_video_8','$freezing_date_8','$freezing_media_8','$freezing_container_no_8','$freezing_holder_no_8','$freezing_colour_8','$freezing_position_8','$thawing_date_8','$thawing_purpose_8','$thawing_path_8','$storage_renewal_date_8','$take_away_date_8','$take_away_purpose_8','$prepared_by_8','$witness_1_8','$witness_2_8','$s_no_9','$produced_at_center_9','$produced_at_home_9','$produced_at_sperm_retreival_9','$abstinence_9','$volume_9','$sperm_counted_pre_wash_9','$sperm_counted_post_wash_9','$progressively_pre_wash_9','$progressively_post_wash_9','$morphology_9','$pus_cells_9','$agglutination_9','$cands_9','$preperation_method_9','$purpose_9','$media_used_9','$remarks_9','$image_video_9','$freezing_date_9','$freezing_media_9','$freezing_container_no_9','$freezing_holder_no_9','$freezing_colour_9','$freezing_position_9','$thawing_date_9','$thawing_purpose_9','$thawing_path_9','$storage_renewal_date_9','$take_away_date_9','$take_away_purpose_9','$prepared_by_9','$witness_1_9','$witness_2_9','$s_no_10','$produced_at_center_10','$produced_at_home_10','$produced_at_sperm_retreival_10','$abstinence_10','$volume_10','$sperm_counted_pre_wash_10','$sperm_counted_post_wash_10','$progressively_pre_wash_10','$progressively_post_wash_10','$morphology_10','$pus_cells_10','$agglutination_10','$cands_10','$preperation_method_10','$purpose_10','$media_used_10','$remarks_10','$image_video_10','$freezing_date_10','$freezing_media_10','$freezing_container_no_10','$freezing_holder_no_10','$freezing_colour_10','$freezing_position_10','$thawing_date_10','$thawing_purpose_10','$thawing_path_10','$storage_renewal_date_10','$take_away_date_10','$take_away_purpose_10','$prepared_by_10','$witness_1_10','$witness_2_10','$s_no_11','$produced_at_center_11','$produced_at_home_11','$produced_at_sperm_retreival_11','$abstinence_11','$volume_11','$sperm_counted_pre_wash_11','$sperm_counted_post_wash_11','$progressively_pre_wash_11','$progressively_post_wash_11','$morphology_11','$pus_cells_11','$agglutination_11','$cands_11','$preperation_method_11','$purpose_11','$media_used_11','$remarks_11','$image_video_11','$freezing_date_11','$freezing_media_11','$freezing_container_no_11','$freezing_holder_no_11','$freezing_colour_11','$freezing_position_11','$thawing_date_11','$thawing_purpose_11','$thawing_path_11','$storage_renewal_date_11','$take_away_date_11','$take_away_purpose_11','$prepared_by_11','$witness_1_11','$witness_2_11','$s_no_12','$produced_at_center_12','$produced_at_home_12','$produced_at_sperm_retreival_12','$abstinence_12','$volume_12','$sperm_counted_pre_wash_12','$sperm_counted_post_wash_12','$progressively_pre_wash_12','$progressively_post_wash_12','$morphology_12','$pus_cells_12','$agglutination_12','$cands_12','$preperation_method_12','$purpose_12','$media_used_12','$remarks_12','$image_video_12','$freezing_date_12','$freezing_media_12','$freezing_container_no_12','$freezing_holder_no_12','$freezing_colour_12','$freezing_position_12','$thawing_date_12','$thawing_purpose_12','$thawing_path_12','$storage_renewal_date_12','$take_away_date_12','$take_away_purpose_12','$prepared_by_12','$witness_1_12','$witness_2_12','$s_no_13','$produced_at_center_13','$produced_at_home_13','$produced_at_sperm_retreival_13','$abstinence_13','$volume_13','$sperm_counted_pre_wash_13','$sperm_counted_post_wash_13','$progressively_pre_wash_13','$progressively_post_wash_13','$morphology_13','$pus_cells_13','$agglutination_13','$cands_13','$preperation_method_13','$purpose_13','$media_used_13','$remarks_13','$image_video_13','$freezing_date_13','$freezing_media_13','$freezing_container_no_13','$freezing_holder_no_13','$freezing_colour_13','$freezing_position_13','$thawing_date_13','$thawing_purpose_13','$thawing_path_13','$storage_renewal_date_13','$take_away_date_13','$take_away_purpose_13','$prepared_by_13','$witness_1_13','$witness_2_13','$s_no_14','$produced_at_center_14','$produced_at_home_14','$produced_at_sperm_retreival_14','$abstinence_14','$volume_14','$sperm_counted_pre_wash_14','$sperm_counted_post_wash_14','$progressively_pre_wash_14','$progressively_post_wash_14','$morphology_14','$pus_cells_14','$agglutination_14','$cands_14','$preperation_method_14','$purpose_14','$media_used_14','$remarks_14','$image_video_14','$freezing_date_14','$freezing_media_14','$freezing_container_no_14','$freezing_holder_no_14','$freezing_colour_14','$freezing_position_14','$thawing_date_14','$thawing_purpose_14','$thawing_path_14','$storage_renewal_date_14','$take_away_date_14','$take_away_purpose_14','$prepared_by_14','$witness_1_14','$witness_2_14','$s_no_15','$produced_at_center_15','$produced_at_home_15','$produced_at_sperm_retreival_15','$abstinence_15','$volume_15','$sperm_counted_pre_wash_15','$sperm_counted_post_wash_15','$progressively_pre_wash_15','$progressively_post_wash_15','$morphology_15','$pus_cells_15','$agglutination_15','$cands_15','$preperation_method_15','$purpose_15','$media_used_15','$remarks_15','$image_video_15','$freezing_date_15','$freezing_media_15','$freezing_container_no_15','$freezing_holder_no_15','$freezing_colour_15','$freezing_position_15','$thawing_date_15','$thawing_purpose_15','$thawing_path_15','$storage_renewal_date_15','$take_away_date_15','$take_away_purpose_15','$prepared_by_15','$witness_1_15','$witness_2_15','$s_no_16','$produced_at_center_16','$produced_at_home_16','$produced_at_sperm_retreival_16','$abstinence_16','$volume_16','$sperm_counted_pre_wash_16','$sperm_counted_post_wash_16','$progressively_pre_wash_16','$progressively_post_wash_16','$morphology_16','$pus_cells_16','$agglutination_16','$cands_16','$preperation_method_16','$purpose_16','$media_used_16','$remarks_16','$image_video_16','$freezing_date_16','$freezing_media_16','$freezing_container_no_16','$freezing_holder_no_16','$freezing_colour_16','$freezing_position_16','$thawing_date_16','$thawing_purpose_16','$thawing_path_16','$storage_renewal_date_16','$take_away_date_16','$take_away_purpose_16','$prepared_by_16','$witness_1_16','$witness_2_16','$s_no_17','$produced_at_center_17','$produced_at_home_17','$produced_at_sperm_retreival_17','$abstinence_17','$volume_17','$sperm_counted_pre_wash_17','$sperm_counted_post_wash_17','$progressively_pre_wash_17','$progressively_post_wash_17','$morphology_17','$pus_cells_17','$agglutination_17','$cands_17','$preperation_method_17','$purpose_17','$media_used_17','$remarks_17','$image_video_17','$freezing_date_17','$freezing_media_17','$freezing_container_no_17','$freezing_holder_no_17','$freezing_colour_17','$freezing_position_17','$thawing_date_17','$thawing_purpose_17','$thawing_path_17','$storage_renewal_date_17','$take_away_date_17','$take_away_purpose_17','$prepared_by_17','$witness_1_17','$witness_2_17','$s_no_18','$produced_at_center_18','$produced_at_home_18','$produced_at_sperm_retreival_18','$abstinence_18','$volume_18','$sperm_counted_pre_wash_18','$sperm_counted_post_wash_18','$progressively_pre_wash_18','$progressively_post_wash_18','$morphology_18','$pus_cells_18','$agglutination_18','$cands_18','$preperation_method_18','$purpose_18','$media_used_18','$remarks_18','$image_video_18','$freezing_date_18','$freezing_media_18','$freezing_container_no_18','$freezing_holder_no_18','$freezing_colour_18','$freezing_position_18','$thawing_date_18','$thawing_purpose_18','$thawing_path_18','$storage_renewal_date_18','$take_away_date_18','$take_away_purpose_18','$prepared_by_18','$witness_1_18','$witness_2_18','$s_no_19','$produced_at_center_19','$produced_at_home_19','$produced_at_sperm_retreival_19','$abstinence_19','$volume_19','$sperm_counted_pre_wash_19','$sperm_counted_post_wash_19','$progressively_pre_wash_19','$progressively_post_wash_19','$morphology_19','$pus_cells_19','$agglutination_19','$cands_19','$preperation_method_19','$purpose_19','$media_used_19','$remarks_19','$image_video_19','$freezing_date_19','$freezing_media_19','$freezing_container_no_19','$freezing_holder_no_19','$freezing_colour_19','$freezing_position_19','$thawing_date_19','$thawing_purpose_19','$thawing_path_19','$storage_renewal_date_19','$take_away_date_19','$take_away_purpose_19','$prepared_by_19','$witness_1_19','$witness_2_19','$s_no_20','$produced_at_center_20','$produced_at_home_20','$produced_at_sperm_retreival_20','$abstinence_20','$volume_20','$sperm_counted_pre_wash_20','$sperm_counted_post_wash_20','$progressively_pre_wash_20','$progressively_post_wash_20','$morphology_20','$pus_cells_20','$agglutination_20','$cands_20','$preperation_method_20','$purpose_20','$media_used_20','$remarks_20','$image_video_20','$freezing_date_20','$freezing_media_20','$freezing_container_no_20','$freezing_holder_no_20','$freezing_colour_20','$freezing_position_20','$thawing_date_20','$thawing_purpose_20','$thawing_path_20','$storage_renewal_date_20','$take_away_date_20','$take_away_purpose_20','$prepared_by_20','$witness_1_20','$witness_2_20','$partners_name','$art_bank_reg_no','$form_id','$donor_d')";

    //     $result = run_form_query($query);

    //     if($result){
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
				// 	die();
    //     }else{
    //       header("location:" .base_url(). "procedure_reports/".$appointment_id."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
				// 	die();
    //     }
    // }
?>-->

 <form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
     
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

     <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
                <input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
                <input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
                <input type="hidden" value="pending" name="status"> 
                <div class="container red-field form mt-5 mb-5">
                    <ul class="d-flex mb-1 mt-2 list-unstyled">
                        <div class="table-responsive">
                            <table style="text-align: center;" class="table table-bordered table-hover table-sm red-field">
                                <thead>
                                    <tr>
                                        <th colspan="2"><h2>SEMEN PREPARATION</h2></th>
                                        <th colspan="2">
                            			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
                            			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
                            			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
                            			            ){?>
                            			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
                            			    <?php } ?>
                            			</th>
                                    </tr>
                                </thead>
                                <thead>
                                    <tr>
                                        <th colspan="2"><h2>SELF CYCLE (S)</h2></th>
                                        <th style="color: black;" colspan="2"><h2>DONOR CYCLE (DI)</h2></th>
                                    </tr>
                                </thead>
                                <thead>
                                    <tr>
                                        <th><strong>PARTNER NAME</strong></th>
                                        <th><input type="text" value="<?php echo isset($select_result['partners_name'])?$select_result['partners_name']:""; ?>" maxlength="20" name="partners_name"></th>
                                        <th style="color: black;"><strong>ART BANK ID</strong></th>
                                        <th><input type="text" value="<?php echo isset($select_result['art_bank_reg_no'])?$select_result['art_bank_reg_no']:""; ?>" maxlength="20" name="art_bank_reg_no"></th>
                                    </tr>
                                </thead>
                                <thead>
                                    <tr>
                                        <th><strong>PATIENT ID</strong></th>
                                        <th><?php echo $patient_id; ?></th>
                                        <th style="color: black;"><strong>DONOR ID</strong></th>
                                        <th><input type="text" value="<?php echo isset($select_result['donor_d'])?$select_result['donor_d']:""; ?>" maxlength="20" name="donor_d"></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </ul>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-sm tableMg">
                            <thead>
                                <tr>
                                    <td rowspan="2" style="background: #FFFFFF;">SNO</td>
                                    <td colspan="3" style="background: #ffd965;">PRODUCED AT</td>
                                    <td rowspan="2" style="background: #b4c6e7;">Abstinence</td>
                                    <td rowspan="2" style="background: #d0cece;">VOLUME</td>
                                    <td colspan="2" style="background: #fbe4d5;">All sperm counted</td>
                                    <td colspan="2" style="background: #e2efd9;">Progressively motile sperm</td>
                                    <td rowspan="2" style="background: #f4b083;">Morphology</td>
                                    <td rowspan="2" style="background: #8eaadb;">Pus cells</td>
                                    <td rowspan="2" style="background: #a8d08d;">Agglutination</td>
                                    <td rowspan="2" style="background: #ffd965;">C&S</td>
                                    <td rowspan="2" style="background: #d8d8d8;">Method of PREPERATION</td>
                                    <td rowspan="2" style="background: #f4b083;">Purpose</td>
                                    <td rowspan="2" style="background: #adb9ca;">Media used</td>
                                    <td rowspan="2" style="background: #a8d08d;">Remarks</td>
                                    <td rowspan="2" style="background: #e7e6e6;">Image/ video</td>
                                    <td colspan="6" style="background: #bf9000;">Freezing</td>
                                    <td colspan="3" style="background: #92d050;">Thawing</td>
                                    <td rowspan="2" style="background: #8eaadb;">Storage renewal date</td>
                                    <td colspan="2" style="background: #ffd965;">Discard /take away</td>
                                    <td rowspan="2" style="background: #FFFFFF;">PREPARED BY</td>
                                    <td rowspan="2" style="background: #FFFFFF;">WITNESS 1</td>
                                    <td rowspan="2" style="background: #FFFFFF;">WITNESS 2</td>
                                </tr>
                                <tr>
                                    <td style="background: #ffd965;">Centre</td>
                                    <td style="background: #ffd965;">Home</td>
                                    <td style="background: #ffd965;">Sperm retreival</td>
                                    <td style="background: #fbe4d5;">PRE WASH</td>
                                    <td style="background: #fbe4d5;">POST WASH</td>
                                    <td style="background: #e2efd9;">PRE WASH</td>
                                    <td style="background: #e2efd9;">POST WASH</td>
                                    <td style="background: #bf9000;">Date</td>
                                    <td style="background: #bf9000;">MEDIA</td>
                                    <td style="background: #bf9000;">CONTAINER NUMBER</td>
                                    <td style="background: #bf9000;">HOLDER NO</td>
                                    <td style="background: #bf9000;">COLOUR</td>
                                    <td style="background: #bf9000;">POSITION-</td>
                                    <td style="background: #92d050;">Date</td>
                                    <td style="background: #92d050;">PURPOSE</td>
                                    <td style="background: #92d050;">THAWING PATH</td>
                                    <td style="background: #ffd965;">DATE</td>
                                    <td style="background: #ffd965;">PURPOSE</td>
                                </tr>
                                <tr>
                                    <td><input type="number" min="0" name="s_no_"></td>
                                    <td style="background: #ffd965;">
                                        <input type="radio"  name="produced_at_center_" value="Yes" <?php if(isset($select_result['produced_at_center_']) && $select_result['produced_at_center_'] == "Yes"){echo 'checked="checked"'; }?> > Yes <br>
                                        <input type="radio"  name="produced_at_center_" value="No" <?php if(isset($select_result['produced_at_center_']) && $select_result['produced_at_center_'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['produced_at_center_']) && $select_result['produced_at_center_'] != "Yes"){echo 'checked="checked"';}?> > No
                                    </td>
                                    <td style="background: #ffd965;">
                                        <input type="radio"  name="produced_at_home_" value="Yes" <?php if(isset($select_result['produced_at_home_']) && $select_result['produced_at_home_'] == "Yes"){echo 'checked="checked"'; }?> > Yes <br>
                                        <input type="radio"  name="produced_at_home_" value="No" <?php if(isset($select_result['produced_at_home_']) && $select_result['produced_at_home_'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['produced_at_home_']) && $select_result['produced_at_home_'] != "Yes"){echo 'checked="checked"';}?> > No
                                    </td>f
                                    <td style="background: #ffd965;">
                                        <input type="radio"  name="produced_at_sperm_retreival_" value="Yes" <?php if(isset($select_result['produced_at_sperm_retreival_']) && $select_result['produced_at_sperm_retreival_'] == "Yes"){echo 'checked="checked"'; }?> > Yes <br>
                                        <input type="radio"  name="produced_at_sperm_retreival_" value="No" <?php if(isset($select_result['produced_at_sperm_retreival_']) && $select_result['produced_at_sperm_retreival_'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['produced_at_sperm_retreival_']) && $select_result['produced_at_sperm_retreival_'] != "Yes"){echo 'checked="checked"';}?> > No
                                    </td>
                                    <td style="background: #b4c6e7;"><input type="number" value="<?php echo isset($select_result['abstinence_'])?$select_result['abstinence_']:""; ?>" min="0" name="abstinence_"></td>
                                    <td style="background: #d0cece;"><input type="text" pattern="[-+]?[0-9]*[.,]?[0-9]+" value="<?php echo isset($select_result['volume_'])?$select_result['volume_']:""; ?>" min="0" name="volume_"></td>
                                    <td style="background: #fbe4d5;"><input type="text" value="<?php echo isset($select_result['sperm_counted_pre_wash_'])?$select_result['sperm_counted_pre_wash_']:""; ?>" maxlength="20" name="sperm_counted_pre_wash_"></td>
                                    <td style="background: #fbe4d5;"><input type="text" value="<?php echo isset($select_result['sperm_counted_post_wash_'])?$select_result['sperm_counted_post_wash_']:""; ?>" maxlength="20" name="sperm_counted_post_wash_"></td>
                                    <td style="background: #e2efd9;"><input type="text" value="<?php echo isset($select_result['progressively_pre_wash_'])?$select_result['progressively_pre_wash_']:""; ?>" maxlength="20" name="progressively_pre_wash_"></td>
                                    <td style="background: #e2efd9;"><input type="text" value="<?php echo isset($select_result['progressively_post_wash_'])?$select_result['progressively_post_wash_']:""; ?>" maxlength="20" name="progressively_post_wash_"></td>
                                    <td style="background: #f4b083;"><input type="text" value="<?php echo isset($select_result['morphology_'])?$select_result['morphology_']:""; ?>" maxlength="20" name="morphology_"></td>
                                    <td style="background: #8eaadb;"><input type="text" value="<?php echo isset($select_result['pus_cells_'])?$select_result['pus_cells_']:""; ?>" maxlength="20" name="pus_cells_"></td>
                                    <td style="background: #a8d08d;">
                                        <input type="radio"  name="agglutination_" value="Yes" <?php if(isset($select_result['agglutination_']) && $select_result['agglutination_'] == "Yes"){echo 'checked="checked"'; }?> > Yes <br>
                                        <input type="radio"  name="agglutination_" value="No" <?php if(isset($select_result['agglutination_']) && $select_result['agglutination_'] == "No"){echo 'checked="checked"'; }
  else if(isset($select_result['agglutination_']) && $select_result['agglutination_'] != "Yes"){echo 'checked="checked"';}?> > No
                                    </td>
                                    <td style="background: #ffd965;">
                                        <input type="radio"  name="cands_" value="Sterile" <?php if(isset($select_result['cands_']) && $select_result['cands_'] == "Sterile"){echo 'checked="checked"'; }?> > Sterile <br>
                                        <input type="radio"  name="cands_" value="Non_Sterile" <?php if(isset($select_result['cands_']) && $select_result['cands_'] == "Non_Sterile"){echo 'checked="checked"'; }?> > Non Sterile
                                    </td>
                                    <td style="background: #d8d8d8;"><input type="text" value="<?php echo isset($select_result['preperation_method_'])?$select_result['preperation_method_']:""; ?>" maxlength="20" name="preperation_method_"></td>
                                    <td style="background: #f4b083;">
                                        <div><input type="radio"  name="purpose_" value="IUI" <?php if(isset($select_result['purpose_']) && $select_result['purpose_'] == "IUI"){echo 'checked="checked"'; }?> > IUI </div>
                                        <div><input type="radio"  name="purpose_" value="IVF" <?php if(isset($select_result['purpose_']) && $select_result['purpose_'] == "IVF"){echo 'checked="checked"'; }?> > IVF </div>
                                        <div><input type="radio"  name="purpose_" value="ICSI" <?php if(isset($select_result['purpose_']) && $select_result['purpose_'] == "ICSI"){echo 'checked="checked"'; }?> > ICSI </div>
                                        <div><input type="radio"  name="purpose_" value="FREEZING" <?php if(isset($select_result['purpose_']) && $select_result['purpose_'] == "FREEZING"){echo 'checked="checked"'; }?> > FREEZING </div>

                                    </td>
                                    <td style="background: #adb9ca;"><input type="text" value="<?php echo isset($select_result['media_used_'])?$select_result['media_used_']:""; ?>" maxlength="20" name="media_used_"></td>
                                    <td style="background: #a8d08d;"><input type="text" value="<?php echo isset($select_result['remarks_'])?$select_result['remarks_']:""; ?>" maxlength="20" name="remarks_"></td>
                                    <td style="background: #e7e6e6;">
                                        <input type="file" name="image_video_">
                                        <a target="_blank" href="<?php echo !empty($select_result['image_video_'])?$select_result['image_video_']:"javascript:void(0)"; ?>">Download</a>
                                    </td>
                                    <td style="background: #bf9000;"><input type="date" value="<?php echo isset($select_result['freezing_date_'])?$select_result['freezing_date_']:""; ?>" name="freezing_date_"></td>
                                    <td style="background: #bf9000;"><input type="text" value="<?php echo isset($select_result['freezing_media_'])?$select_result['freezing_media_']:""; ?>" maxlength="20" name="freezing_media_"></td>
                                    <td style="background: #bf9000;"><input type="text" value="<?php echo isset($select_result['freezing_container_no_'])?$select_result['freezing_container_no_']:""; ?>" maxlength="20" name="freezing_container_no_"></td>
                                    <td style="background: #bf9000;"><input type="text" value="<?php echo isset($select_result['freezing_holder_no_'])?$select_result['freezing_holder_no_']:""; ?>" maxlength="20" name="freezing_holder_no_"></td>
                                    <td style="background: #bf9000;"><input type="text" value="<?php echo isset($select_result['freezing_colour_'])?$select_result['freezing_colour_']:""; ?>" maxlength="20" name="freezing_colour_"></td>
                                    <td style="background: #bf9000;">
                                        <input type="radio"  name="freezing_position_" value="ABOVE"> ABOVE <br>
                                        <input type="radio"  name="freezing_position_" value="BELOW"> BELOW
                                    </td>
                                    <td style="background: #92d050;"><input type="date" value="<?php echo isset($select_result['thawing_date_'])?$select_result['thawing_date_']:""; ?>" name="thawing_date_"></td>
                                    <td style="background: #92d050;"><input type="text" value="<?php echo isset($select_result['thawing_purpose_'])?$select_result['thawing_purpose_']:""; ?>" maxlength="20" name="thawing_purpose_"></td>
                                    <td style="background: #92d050;"><input type="text" value="<?php echo isset($select_result['thawing_path_'])?$select_result['thawing_path_']:""; ?>" maxlength="20" name="thawing_path_"></td>
                                    <td style="background: #8eaadb;"><input type="date" value="<?php echo isset($select_result['storage_renewal_date_'])?$select_result['storage_renewal_date_']:""; ?>" name="storage_renewal_date_"></td>
                                    <td style="background: #ffd965;"><input type="date" value="<?php echo isset($select_result['take_away_date_'])?$select_result['take_away_date_']:""; ?>" name="take_away_date_"></td>
                                    <td style="background: #ffd965;"><input type="text" value="<?php echo isset($select_result['take_away_purpose_'])?$select_result['take_away_purpose_']:""; ?>" maxlength="20" name="take_away_purpose_"></td>
                                    <td><input type="text" value="<?php echo isset($select_result['prepared_by_'])?$select_result['prepared_by_']:""; ?>" maxlength="20" name="prepared_by_"></td>
                                    <td><input type="text" value="<?php echo isset($select_result['witness_1_'])?$select_result['witness_1_']:""; ?>" maxlength="20" name="witness_1_"></td>
                                    <td><input type="text" value="<?php echo isset($select_result['witness_2_'])?$select_result['witness_2_']:""; ?>" maxlength="20" name="witness_2_"></td>
                                </tr>

        <?php
            for($i=1;$i<=20;$i++){
                echo '<tr>';
                    $value1 = '';
                    if(isset($select_result['s_no_'.$i])) {$value = $select_result['s_no_'.$i]; }
                    echo '<td><input type="number" min="0" value="'.$value1.'" name="s_no_'.$i.'"></td>';

                    $yes_selected_2 = $no_selected_2 = '';
                    if(isset($select_result['produced_at_center_'.$i]) && $select_result['produced_at_center_'.$i] == "Yes") 
                    {$yes_selected_2 = 'checked="checked"'; }
                    if(isset($select_result['produced_at_center_'.$i]) && $select_result['produced_at_center_'.$i] == "No") 
                    {$no_selected_2 = 'checked="checked"'; }
                    echo '<td style="background: #ffd965;">';
                        echo '<input type="radio"  name="produced_at_center_'.$i.'" '.$yes_selected_2.' value="Yes"> Yes <br>';
                        echo '<input type="radio"  name="produced_at_center_'.$i.'" '.$no_selected_2.' value="No"> No';
                    echo '</td>';

                    $yes_selected_3 = $no_selected_3 = '';
                    if(isset($select_result['produced_at_home_'.$i]) && $select_result['produced_at_home_'.$i] == "Yes") 
                    {$yes_selected_3 = 'checked="checked"'; }
                    if(isset($select_result['produced_at_home_'.$i]) && $select_result['produced_at_home_'.$i] == "No") 
                    {$no_selected_3 = 'checked="checked"'; }
                    echo '<td style="background: #ffd965;">';
                        echo '<input type="radio"  name="produced_at_home_'.$i.'" '.$yes_selected_3.' value="Yes"> Yes <br>';
                        echo '<input type="radio"  name="produced_at_home_'.$i.'" '.$no_selected_3.' value="No"> No';
                    echo '</td>';

                    $yes_selected_4 = $no_selected_4 = '';
                    if(isset($select_result['produced_at_sperm_retreival_'.$i]) && $select_result['produced_at_sperm_retreival_'.$i] == "Yes") 
                    {$yes_selected_4 = 'checked="checked"'; }
                    if(isset($select_result['produced_at_sperm_retreival_'.$i]) && $select_result['produced_at_sperm_retreival_'.$i] == "No") 
                    {$no_selected_4 = 'checked="checked"'; }
                    echo '<td style="background: #ffd965;">';
                        echo '<input type="radio"  name="produced_at_sperm_retreival_'.$i.'" '.$yes_selected_4.' value="Yes"> Yes <br>';
                        echo '<input type="radio"  name="produced_at_sperm_retreival_'.$i.'" '.$no_selected_4.' value="No"> No';
                    echo '</td>';

                    $value5 = '';
                    if(isset($select_result['abstinence_'.$i])) {$value5 = $select_result['abstinence_'.$i]; }
                    echo '<td style="background: #b4c6e7;"><input type="number" value="'.$value5.'" min="0" name="abstinence_'.$i.'"></td>';

                    $value6 = '';
                    if(isset($select_result['volume_'.$i])) {$value6 = $select_result['volume_'.$i]; }
                    echo '<td style="background: #d0cece;"><input type="text"  pattern="[-+]?[0-9]*[.,]?[0-9]+" value="'.$value6.'" min="0" name="volume_'.$i.'"></td>';

                    $value7 = '';
                    if(isset($select_result['sperm_counted_pre_wash_'.$i])) {$value7 = $select_result['sperm_counted_pre_wash_'.$i]; }
                    echo '<td style="background: #fbe4d5;"><input type="text" maxlength="20" value="'.$value7.'" name="sperm_counted_pre_wash_'.$i.'"></td>';

                    $value8 = '';
                    if(isset($select_result['sperm_counted_post_wash_'.$i])) {$value8 = $select_result['sperm_counted_post_wash_'.$i]; }
                    echo '<td style="background: #fbe4d5;"><input type="text" maxlength="20" value="'.$value8.'" name="sperm_counted_post_wash_'.$i.'"></td>';

                    $value9 = '';
                    if(isset($select_result['progressively_pre_wash_'.$i])) {$value9 = $select_result['progressively_pre_wash_'.$i]; }
                    echo '<td style="background: #e2efd9;"><input type="text" maxlength="20" value="'.$value9.'" name="progressively_pre_wash_'.$i.'"></td>';

                    $value10 = '';
                    if(isset($select_result['progressively_post_wash_'.$i])) {$value10 = $select_result['progressively_post_wash_'.$i]; }
                    echo '<td style="background: #e2efd9;"><input type="text" maxlength="20" value="'.$value10.'" name="progressively_post_wash_'.$i.'"></td>';

                    $value11 = '';
                    if(isset($select_result['morphology_'.$i])) {$value11 = $select_result['morphology_'.$i]; }
                    echo '<td style="background: #f4b083;"><input type="text" maxlength="20" value="'.$value11.'" name="morphology_'.$i.'"></td>';

                    $value12 = '';
                    if(isset($select_result['pus_cells_'.$i])) {$value12 = $select_result['pus_cells_'.$i]; }
                    echo '<td style="background: #8eaadb;"><input type="text" maxlength="20" value="'.$value12.'" name="pus_cells_'.$i.'"></td>';

                    $yes_selected_13 = $no_selected_13 = '';
                    if(isset($select_result['agglutination_'.$i]) && $select_result['agglutination_'.$i] == "Yes") 
                    {$yes_selected_13 = 'checked="checked"'; }
                    if(isset($select_result['agglutination_'.$i]) && $select_result['agglutination_'.$i] == "No") 
                    {$no_selected_13 = 'checked="checked"'; }
                    echo '<td style="background: #a8d08d;">';
                        echo '<input type="radio"  name="agglutination_'.$i.'" '.$yes_selected_13.' value="Yes"> Yes <br>';
                        echo '<input type="radio"  name="agglutination_'.$i.'" '.$no_selected_13.' value="No"> No';
                    echo '</td>';

                    $yes_selected_14 = $no_selected_14 = '';
                    if(isset($select_result['cands_'.$i]) && $select_result['cands_'.$i] == "Yes") 
                    {$yes_selected_14 = 'checked="checked"'; }
                    if(isset($select_result['cands_'.$i]) && $select_result['cands_'.$i] == "No") 
                    {$no_selected_14 = 'checked="checked"'; }
                    echo '<td style="background: #ffd965;">';
                        echo '<input type="radio"  name="cands_'.$i.'" '.$yes_selected_14.' value="Sterile"> Sterile <br>';
                        echo '<input type="radio"  name="cands_'.$i.'" '.$no_selected_14.' value="Non_Sterile"> Non Sterile';
                    echo '</td>';

                    $value15 = '';
                    if(isset($select_result['preperation_method_'.$i])) {$value15 = $select_result['preperation_method_'.$i]; }
                    echo '<td style="background: #d8d8d8;"><input type="text" maxlength="20" value="'.$value15.'" name="preperation_method_'.$i.'"></td>';

                    $iui_selected_16 = $ivf_selected_16 = $icsi_selected_16 = $freezing_selected_16 = '';
                    if(isset($select_result['purpose_'.$i]) && $select_result['purpose_'.$i] == "IUI") 
                    {$iui_selected_16 = 'checked="checked"'; }
                    if(isset($select_result['purpose_'.$i]) && $select_result['purpose_'.$i] == "IVF") 
                    {$ivf_selected_16 = 'checked="checked"'; }
                    if(isset($select_result['purpose_'.$i]) && $select_result['purpose_'.$i] == "ICSI") 
                    {$icsi_selected_16 = 'checked="checked"'; }
                    if(isset($select_result['purpose_'.$i]) && $select_result['purpose_'.$i] == "FREEZING") 
                    {$freezing_selected_16 = 'checked="checked"'; }
                    echo '<td style="background: #f4b083;">';
                        echo '<div><input type="radio"  name="purpose_'.$i.'" '.$iui_selected_16.' value="IUI"> IUI </div>';
                        echo '<div><input type="radio"  name="purpose_'.$i.'" '.$ivf_selected_16.' value="IVF"> IVF </div>';
                        echo '<div><input type="radio"  name="purpose_'.$i.'" '.$icsi_selected_16.' value="ICSI"> ICSI </div>';
                        echo '<div><input type="radio"  name="purpose_'.$i.'" '.$freezing_selected_16.' value="FREEZING"> FREEZING </div>';
                    echo '</td>';

                    $value17 = '';
                    if(isset($select_result['media_used_'.$i])) {$value17 = $select_result['media_used_'.$i]; }
                    echo '<td style="background: #adb9ca;"><input type="text" maxlength="20" value="'.$value17.'" name="media_used_'.$i.'"></td>';

                    $value18 = '';
                    if(isset($select_result['remarks_'.$i])) {$value17 = $select_result['remarks_'.$i]; }
                    echo '<td style="background: #a8d08d;"><input type="text" maxlength="20" value="'.$value18.'" name="remarks_'.$i.'"></td>';
                    
                    $file_value = "javascript:void(0)";
                    if(!empty($select_result['image_video_'.$i])){
                        $file_value = $select_result['image_video_'.$i];
                    }
                    echo '<td style="background: #e7e6e6;">
                    <input type="file" name="image_video_'.$i.'">
                    <a target="_blank" href="'.$file_value.'">Download</a>
                    </td>';

                    $value20 = '';
                    if(isset($select_result['freezing_date_'.$i])) {$value20 = $select_result['freezing_date_'.$i]; }
                    echo '<td style="background: #bf9000;"><input type="date" value="'.$value20.'" name="freezing_date_'.$i.'"></td>';

                    $value21 = '';
                    if(isset($select_result['freezing_media_'.$i])) {$value21 = $select_result['freezing_media_'.$i]; }
                    echo '<td style="background: #bf9000;"><input type="text" value="'.$value21.'" maxlength="20" name="freezing_media_'.$i.'"></td>';

                    $value22 = '';
                    if(isset($select_result['freezing_container_no_'.$i])) {$value22 = $select_result['freezing_container_no_'.$i]; }
                    echo '<td style="background: #bf9000;"><input type="text" maxlength="20" value="'.$value22.'" name="freezing_container_no_'.$i.'"></td>';

                    $value23 = '';
                    if(isset($select_result['freezing_holder_no_'.$i])) {$value23 = $select_result['freezing_holder_no_'.$i]; }
                    echo '<td style="background: #bf9000;"><input type="text" maxlength="20" value="'.$value23.'" name="freezing_holder_no_'.$i.'"></td>';

                    $value24 = '';
                    if(isset($select_result['freezing_colour_'.$i])) {$value24 = $select_result['freezing_colour_'.$i]; }
                    echo '<td style="background: #bf9000;"><input type="text" maxlength="20" value="'.$value24.'" name="freezing_colour_'.$i.'"></td>';

                    $above_selected_25 = $below_selected_25 = 'c';
                    if(isset($select_result['freezing_position_'.$i]) && $select_result['freezing_position_'.$i] == "ABOVE") 
                    {$above_selected_25 = 'checked="checked"'; }
                    if(isset($select_result['freezing_position_'.$i]) && $select_result['freezing_position_'.$i] == "BELOW") 
                    {$below_selected_25 = 'checked="checked"'; }
                    echo '<td style="background: #bf9000;">';
                        echo '<input type="radio"  name="freezing_position_'.$i.'" '.$above_selected_25.' value="ABOVE"> ABOVE <br>';
                        echo '<input type="radio"  name="freezing_position_'.$i.'" '.$below_selected_25.' value="BELOW"> BELOW';
                    echo '</td>';

                    $value26 = '';
                    if(isset($select_result['thawing_date_'.$i])) {$value26 = $select_result['thawing_date_'.$i]; }
                    echo '<td style="background: #92d050;"><input type="date" value="'.$value26.'" name="thawing_date_'.$i.'"></td>';

                    $value27 = '';
                    if(isset($select_result['thawing_purpose_'.$i])) {$value27 = $select_result['thawing_purpose_'.$i]; }
                    echo '<td style="background: #92d050;"><input type="text" maxlength="20" value="'.$value27.'" name="thawing_purpose_'.$i.'"></td>';

                    $value28 = '';
                    if(isset($select_result['thawing_path_'.$i])) {$value28 = $select_result['thawing_path_'.$i]; }
                    echo '<td style="background: #92d050;"><input type="text" maxlength="20" value="'.$value28.'" name="thawing_path_'.$i.'"></td>';

                    $value29 = '';
                    if(isset($select_result['storage_renewal_date_'.$i])) {$value29 = $select_result['storage_renewal_date_'.$i]; }
                    echo '<td style="background: #8eaadb;"><input type="date" value="'.$value29.'" name="storage_renewal_date_'.$i.'"></td>';

                    $value30 = '';
                    if(isset($select_result['take_away_date_'.$i])) {$value30 = $select_result['take_away_date_'.$i]; }
                    echo '<td style="background: #ffd965;"><input type="date" value="'.$value30.'" name="take_away_date_'.$i.'"></td>';

                    $value31 = '';
                    if(isset($select_result['take_away_purpose_'.$i])) {$value31 = $select_result['take_away_purpose_'.$i]; }
                    echo '<td style="background: #ffd965;"><input type="text" maxlength="20" value="'.$value31.'" name="take_away_purpose_'.$i.'"></td>';

                    $value32 = '';
                    if(isset($select_result['prepared_by_'.$i])) {$value32 = $select_result['prepared_by_'.$i]; }
                    echo '<td><input type="text" maxlength="20" value="'.$value32.'" name="prepared_by_'.$i.'"></td>';

                    $value33 = '';
                    if(isset($select_result['witness_1_'.$i])) {$value33 = $select_result['witness_1_'.$i]; }
                    echo '<td><input type="text" maxlength="20" value="'.$value33.'" name="witness_1_'.$i.'"></td>';

                    $value34 = '';
                    if(isset($select_result['witness_2_'.$i])) {$value34 = $select_result['witness_2_'.$i]; }
                    echo '<td><input type="text" maxlength="20" value="'.$value34.'" name="witness_2_'.$i.'"></td>';
                echo '</tr>';
            }
        ?>
                            </thead>
                        </table>
                    </div>
                    <!-- <input typechecked="checked" namechecked="checked" class="btn btn-primary mt-2 mb-2" value="submit"> -->
                    <input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
                </div>
            </form>