<?php
	    if(isset($_POST['submit'])){
			unset($_POST['submit']);
					
			$select_query = "SELECT * FROM `pre_embryo_transfer` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
			$select_result = run_select_query($select_query); 
			if(empty($select_result)){
				// mysql query to insert data
				$query = "INSERT INTO `pre_embryo_transfer` SET ";
				$sqlArr = array();
				foreach( $_POST as $key=> $value )
				{
				  $sqlArr[] = " $key = '".addslashes($value)."'";
				}		
				$query .= implode(',' , $sqlArr);
			}else{
				// mysql query to update data
				$query = "UPDATE pre_embryo_transfer SET ";
				foreach( $_POST as $key=> $value )
				{
				  $sqlArr[] = " $key = '".$value."'"	;
				}
				$query .= implode(',' , $sqlArr);
				$query .= " WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
			}
			$result = run_form_query($query);        
	
			if($result){
              header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
    					die();
            }else{
              header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
    					die();
            }
		}
		$select_query = "SELECT * FROM `pre_embryo_transfer` WHERE patient_id='$patient_id' and receipt_number='$receipt_number'";
		$select_result = run_select_query($select_query);  

	// php code to Insert data into mysql database from input text
	// if(isset($_POST['submit'])){
	// 	$patient_id = $_POST['patient_id'];
    //     $receipt_number = $_POST['receipt_number'];
	// 	$status = $_POST['status'];
	// 	// get values form input text and number
	// 	$partners_name = $_POST['partners_name'];
	// 	$art_bank_reg_no = $_POST['art_bank_reg_no'];
	// 	$form_id = $_POST['form_id'];
	// 	$surrogate_id = $_POST['surrogate_id'];
	// 	$last_menstrual_period = $_POST['last_menstrual_period'];
	// 	$date1 = $_POST['date1'];
	// 	$date2 = $_POST['date2'];
	// 	$date3 = $_POST['date3'];
	// 	$date4 = $_POST['date4'];
	// 	$date5 = $_POST['date5'];
	// 	$date6 = $_POST['date6'];
	// 	$date7 = $_POST['date7'];
	// 	$date8 = $_POST['date8'];
	// 	$date9 = $_POST['date9'];
	// 	$date10 = $_POST['date10'];
	// 	$date11 = $_POST['date11'];
	// 	$date12 = $_POST['date12'];
	// 	$date13 = $_POST['date13'];
	// 	$date14 = $_POST['date14'];
	// 	$date15 = $_POST['date15'];
	// 	$date16 = $_POST['date16'];
	// 	$date17 = $_POST['date17'];
	// 	$date18 = $_POST['date18'];
	// 	$date19 = $_POST['date19'];
	// 	$date20 = $_POST['date20'];
	// 	$date21 = $_POST['date21'];
	// 	$date22 = $_POST['date22'];
	// 	$date23 = $_POST['date23'];
	// 	$date24 = $_POST['date24'];
	// 	$date25 = $_POST['date25'];
	// 	$date26 = $_POST['date26'];
	// 	$date27 = $_POST['date27'];
	// 	$endometrial_thickness1 = $_POST['endometrial_thickness1'];
	// 	$endometrial_thickness2 = $_POST['endometrial_thickness2'];
	// 	$endometrial_thickness3 = $_POST['endometrial_thickness3'];
	// 	$endometrial_thickness4 = $_POST['endometrial_thickness4'];
	// 	$endometrial_thickness5 = $_POST['endometrial_thickness5'];
	// 	$endometrial_thickness6 = $_POST['endometrial_thickness6'];
	// 	$endometrial_thickness7 = $_POST['endometrial_thickness7'];
	// 	$endometrial_thickness8 = $_POST['endometrial_thickness8'];
	// 	$endometrial_thickness9 = $_POST['endometrial_thickness9'];
	// 	$endometrial_thickness10 = $_POST['endometrial_thickness10'];
	// 	$endometrial_thickness11 = $_POST['endometrial_thickness11'];
	// 	$endometrial_thickness12 = $_POST['endometrial_thickness12'];
	// 	$endometrial_thickness13 = $_POST['endometrial_thickness13'];
	// 	$endometrial_thickness14 = $_POST['endometrial_thickness14'];
	// 	$endometrial_thickness15 = $_POST['endometrial_thickness15'];
	// 	$endometrial_thickness16 = $_POST['endometrial_thickness16'];
	// 	$endometrial_thickness17 = $_POST['endometrial_thickness17'];
	// 	$endometrial_thickness18 = $_POST['endometrial_thickness18'];
	// 	$endometrial_thickness19 = $_POST['endometrial_thickness19'];
	// 	$endometrial_thickness20 = $_POST['endometrial_thickness20'];
	// 	$endometrial_thickness21 = $_POST['endometrial_thickness21'];
	// 	$endometrial_thickness22 = $_POST['endometrial_thickness22'];
	// 	$endometrial_thickness23 = $_POST['endometrial_thickness23'];
	// 	$endometrial_thickness24 = $_POST['endometrial_thickness24'];
	// 	$endometrial_thickness25 = $_POST['endometrial_thickness25'];
	// 	$endometrial_thickness26 = $_POST['endometrial_thickness26'];
	// 	$endometrial_thickness27 = $_POST['endometrial_thickness27'];
	// 	$estrogen1 = $_POST['estrogen1'];
	// 	$estrogen2 = $_POST['estrogen2'];
	// 	$estrogen3 = $_POST['estrogen3'];
	// 	$estrogen4 = $_POST['estrogen4'];
	// 	$estrogen5 = $_POST['estrogen5'];
	// 	$estrogen6 = $_POST['estrogen6'];
	// 	$estrogen7 = $_POST['estrogen7'];
	// 	$estrogen8 = $_POST['estrogen8'];
	// 	$estrogen9 = $_POST['estrogen9'];
	// 	$estrogen10 = $_POST['estrogen10'];
	// 	$estrogen11 = $_POST['estrogen11'];
	// 	$estrogen12 = $_POST['estrogen12'];
	// 	$estrogen13 = $_POST['estrogen13'];
	// 	$estrogen14 = $_POST['estrogen14'];
	// 	$estrogen15 = $_POST['estrogen15'];
	// 	$estrogen16 = $_POST['estrogen16'];
	// 	$estrogen17 = $_POST['estrogen17'];
	// 	$estrogen18 = $_POST['estrogen18'];
	// 	$estrogen19 = $_POST['estrogen19'];
	// 	$estrogen20 = $_POST['estrogen20'];
	// 	$estrogen21 = $_POST['estrogen21'];
	// 	$estrogen22 = $_POST['estrogen22'];
	// 	$estrogen23 = $_POST['estrogen23'];
	// 	$estrogen24 = $_POST['estrogen24'];
	// 	$estrogen25 = $_POST['estrogen25'];
	// 	$estrogen26 = $_POST['estrogen26'];
	// 	$estrogen27 = $_POST['estrogen27'];
	// 	$progesterone1 = $_POST['progesterone1'];
	// 	$progesterone2 = $_POST['progesterone2'];
	// 	$progesterone3 = $_POST['progesterone3'];
	// 	$progesterone4 = $_POST['progesterone4'];
	// 	$progesterone5 = $_POST['progesterone5'];
	// 	$progesterone6 = $_POST['progesterone6'];
	// 	$progesterone7 = $_POST['progesterone7'];
	// 	$progesterone8 = $_POST['progesterone8'];
	// 	$progesterone9 = $_POST['progesterone9'];
	// 	$progesterone10 = $_POST['progesterone10'];
	// 	$progesterone11 = $_POST['progesterone11'];
	// 	$progesterone12 = $_POST['progesterone12'];
	// 	$progesterone13 = $_POST['progesterone13'];
	// 	$progesterone14 = $_POST['progesterone14'];
	// 	$progesterone15 = $_POST['progesterone15'];
	// 	$progesterone16 = $_POST['progesterone16'];
	// 	$progesterone17 = $_POST['progesterone17'];
	// 	$progesterone18 = $_POST['progesterone18'];
	// 	$progesterone19 = $_POST['progesterone19'];
	// 	$progesterone20 = $_POST['progesterone20'];
	// 	$progesterone21 = $_POST['progesterone21'];
	// 	$progesterone22 = $_POST['progesterone22'];
	// 	$progesterone23 = $_POST['progesterone23'];
	// 	$progesterone24 = $_POST['progesterone24'];
	// 	$progesterone25 = $_POST['progesterone25'];
	// 	$progesterone26 = $_POST['progesterone26'];
	// 	$progesterone27 = $_POST['progesterone27'];
	// 	$followup_on1 = $_POST['followup_on1'];
	// 	$followup_on2 = $_POST['followup_on2'];
	// 	$followup_on3 = $_POST['followup_on3'];
	// 	$followup_on4 = $_POST['followup_on4'];
	// 	$followup_on5 = $_POST['followup_on5'];
	// 	$followup_on6 = $_POST['followup_on6'];
	// 	$followup_on7 = $_POST['followup_on7'];
	// 	$followup_on8 = $_POST['followup_on8'];
	// 	$followup_on9 = $_POST['followup_on9'];
	// 	$followup_on10 = $_POST['followup_on10'];
	// 	$followup_on11 = $_POST['followup_on11'];
	// 	$followup_on12 = $_POST['followup_on12'];
	// 	$followup_on13 = $_POST['followup_on13'];
	// 	$followup_on14 = $_POST['followup_on14'];
	// 	$followup_on15 = $_POST['followup_on15'];
	// 	$followup_on16 = $_POST['followup_on16'];
	// 	$followup_on17 = $_POST['followup_on17'];
	// 	$followup_on18 = $_POST['followup_on18'];
	// 	$followup_on19 = $_POST['followup_on19'];
	// 	$followup_on20 = $_POST['followup_on20'];
	// 	$followup_on21 = $_POST['followup_on21'];
	// 	$followup_on22 = $_POST['followup_on22'];
	// 	$followup_on23 = $_POST['followup_on23'];
	// 	$followup_on24 = $_POST['followup_on24'];
	// 	$followup_on25 = $_POST['followup_on25'];
	// 	$followup_on26 = $_POST['followup_on26'];
	// 	$followup_on27 = $_POST['followup_on27'];
	// 	$serum_e2_level1 = $_POST['serum_e2_level1'];
	// 	$serum_e2_level2 = $_POST['serum_e2_level2'];
	// 	$serum_e2_level3 = $_POST['serum_e2_level3'];
	// 	$serum_e2_level4 = $_POST['serum_e2_level4'];
	// 	$serum_e2_level5 = $_POST['serum_e2_level5'];
	// 	$serum_e2_level6 = $_POST['serum_e2_level6'];
	// 	$serum_e2_level7 = $_POST['serum_e2_level7'];
	// 	$serum_e2_level8 = $_POST['serum_e2_level8'];
	// 	$serum_e2_level9 = $_POST['serum_e2_level9'];
	// 	$serum_e2_level10 = $_POST['serum_e2_level10'];
	// 	$serum_e2_level11 = $_POST['serum_e2_level11'];
	// 	$serum_e2_level12 = $_POST['serum_e2_level12'];
	// 	$serum_e2_level13 = $_POST['serum_e2_level13'];
	// 	$serum_e2_level14 = $_POST['serum_e2_level14'];
	// 	$serum_e2_level15 = $_POST['serum_e2_level15'];
	// 	$serum_e2_level16 = $_POST['serum_e2_level16'];
	// 	$serum_e2_level17 = $_POST['serum_e2_level17'];
	// 	$serum_e2_level18 = $_POST['serum_e2_level18'];
	// 	$serum_e2_level19 = $_POST['serum_e2_level19'];
	// 	$serum_e2_level20 = $_POST['serum_e2_level20'];
	// 	$serum_e2_level21 = $_POST['serum_e2_level21'];
	// 	$serum_e2_level22 = $_POST['serum_e2_level22'];
	// 	$serum_e2_level23 = $_POST['serum_e2_level23'];
	// 	$serum_e2_level24 = $_POST['serum_e2_level24'];
	// 	$serum_e2_level25 = $_POST['serum_e2_level25'];
	// 	$serum_e2_level26 = $_POST['serum_e2_level26'];
	// 	$serum_e2_level27 = $_POST['serum_e2_level27'];
	// 	$serum_progesterone_level1 = $_POST['serum_progesterone_level1'];
	// 	$serum_progesterone_level2 = $_POST['serum_progesterone_level2'];
	// 	$serum_progesterone_level3 = $_POST['serum_progesterone_level3'];
	// 	$serum_progesterone_level4 = $_POST['serum_progesterone_level4'];
	// 	$serum_progesterone_level5 = $_POST['serum_progesterone_level5'];
	// 	$serum_progesterone_level6 = $_POST['serum_progesterone_level6'];
	// 	$serum_progesterone_level7 = $_POST['serum_progesterone_level7'];
	// 	$serum_progesterone_level8 = $_POST['serum_progesterone_level8'];
	// 	$serum_progesterone_level9 = $_POST['serum_progesterone_level9'];
	// 	$serum_progesterone_level10 = $_POST['serum_progesterone_level10'];
	// 	$serum_progesterone_level11 = $_POST['serum_progesterone_level11'];
	// 	$serum_progesterone_level12 = $_POST['serum_progesterone_level12'];
	// 	$serum_progesterone_level13 = $_POST['serum_progesterone_level13'];
	// 	$serum_progesterone_level14 = $_POST['serum_progesterone_level14'];
	// 	$serum_progesterone_level15 = $_POST['serum_progesterone_level15'];
	// 	$serum_progesterone_level16 = $_POST['serum_progesterone_level16'];
	// 	$serum_progesterone_level17 = $_POST['serum_progesterone_level17'];
	// 	$serum_progesterone_level18 = $_POST['serum_progesterone_level18'];
	// 	$serum_progesterone_level19 = $_POST['serum_progesterone_level19'];
	// 	$serum_progesterone_level20 = $_POST['serum_progesterone_level20'];
	// 	$serum_progesterone_level21 = $_POST['serum_progesterone_level21'];
	// 	$serum_progesterone_level22 = $_POST['serum_progesterone_level22'];
	// 	$serum_progesterone_level23 = $_POST['serum_progesterone_level23'];
	// 	$serum_progesterone_level24 = $_POST['serum_progesterone_level24'];
	// 	$serum_progesterone_level25 = $_POST['serum_progesterone_level25'];
	// 	$serum_progesterone_level26 = $_POST['serum_progesterone_level26'];
	// 	$serum_progesterone_level27 = $_POST['serum_progesterone_level27'];
	// 	$other_investigation1 = $_POST['other_investigation1'];
	// 	$other_investigation2 = $_POST['other_investigation2'];
	// 	$other_investigation3 = $_POST['other_investigation3'];
	// 	$other_investigation4 = $_POST['other_investigation4'];
	// 	$other_investigation5 = $_POST['other_investigation5'];
	// 	$other_investigation6 = $_POST['other_investigation6'];
	// 	$other_investigation7 = $_POST['other_investigation7'];
	// 	$other_investigation8 = $_POST['other_investigation8'];
	// 	$other_investigation9 = $_POST['other_investigation9'];
	// 	$other_investigation10 = $_POST['other_investigation10'];
	// 	$other_investigation11 = $_POST['other_investigation11'];
	// 	$other_investigation12 = $_POST['other_investigation12'];
	// 	$other_investigation13 = $_POST['other_investigation13'];
	// 	$other_investigation14 = $_POST['other_investigation14'];
	// 	$other_investigation15 = $_POST['other_investigation15'];
	// 	$other_investigation16 = $_POST['other_investigation16'];
	// 	$other_investigation17 = $_POST['other_investigation17'];
	// 	$other_investigation18 = $_POST['other_investigation18'];
	// 	$other_investigation19 = $_POST['other_investigation19'];
	// 	$other_investigation20 = $_POST['other_investigation20'];
	// 	$other_investigation21 = $_POST['other_investigation21'];
	// 	$other_investigation22 = $_POST['other_investigation22'];
	// 	$other_investigation23 = $_POST['other_investigation23'];
	// 	$other_investigation24 = $_POST['other_investigation24'];
	// 	$other_investigation25 = $_POST['other_investigation25'];
	// 	$other_investigation26 = $_POST['other_investigation26'];
	// 	$other_investigation27 = $_POST['other_investigation27'];
	// 	$medicine_added1 = $_POST['medicine_added1'];
	// 	$medicine_added2 = $_POST['medicine_added2'];
	// 	$medicine_added3 = $_POST['medicine_added3'];
	// 	$medicine_added4 = $_POST['medicine_added4'];
	// 	$medicine_added5 = $_POST['medicine_added5'];
	// 	$medicine_added6 = $_POST['medicine_added6'];
	// 	$medicine_added7 = $_POST['medicine_added7'];
	// 	$medicine_added8 = $_POST['medicine_added8'];
	// 	$medicine_added9 = $_POST['medicine_added9'];
	// 	$medicine_added10 = $_POST['medicine_added10'];
	// 	$medicine_added11 = $_POST['medicine_added11'];
	// 	$medicine_added12 = $_POST['medicine_added12'];
	// 	$medicine_added13 = $_POST['medicine_added13'];
	// 	$medicine_added14 = $_POST['medicine_added14'];
	// 	$medicine_added15 = $_POST['medicine_added15'];
	// 	$medicine_added16 = $_POST['medicine_added16'];
	// 	$medicine_added17 = $_POST['medicine_added17'];
	// 	$medicine_added18 = $_POST['medicine_added18'];
	// 	$medicine_added19 = $_POST['medicine_added19'];
	// 	$medicine_added20 = $_POST['medicine_added20'];
	// 	$medicine_added21 = $_POST['medicine_added21'];
	// 	$medicine_added22 = $_POST['medicine_added22'];
	// 	$medicine_added23 = $_POST['medicine_added23'];
	// 	$medicine_added24 = $_POST['medicine_added24'];
	// 	$medicine_added25 = $_POST['medicine_added25'];
	// 	$medicine_added26 = $_POST['medicine_added26'];
	// 	$medicine_added27 = $_POST['medicine_added27'];
	// 	$remarks1 = $_POST['remarks1'];
	// 	$remarks2 = $_POST['remarks2'];
	// 	$remarks3 = $_POST['remarks3'];
	// 	$remarks4 = $_POST['remarks4'];
	// 	$remarks5 = $_POST['remarks5'];
	// 	$remarks6 = $_POST['remarks6'];
	// 	$remarks7 = $_POST['remarks7'];
	// 	$remarks8 = $_POST['remarks8'];
	// 	$remarks9 = $_POST['remarks9'];
	// 	$remarks10 = $_POST['remarks10'];
	// 	$remarks11 = $_POST['remarks11'];
	// 	$remarks12 = $_POST['remarks12'];
	// 	$remarks13 = $_POST['remarks13'];
	// 	$remarks14 = $_POST['remarks14'];
	// 	$remarks15 = $_POST['remarks15'];
	// 	$remarks16 = $_POST['remarks16'];
	// 	$remarks17 = $_POST['remarks17'];
	// 	$remarks18 = $_POST['remarks18'];
	// 	$remarks19 = $_POST['remarks19'];
	// 	$remarks20 = $_POST['remarks20'];
	// 	$remarks21 = $_POST['remarks21'];
	// 	$remarks22 = $_POST['remarks22'];
	// 	$remarks23 = $_POST['remarks23'];
	// 	$remarks24 = $_POST['remarks24'];
	// 	$remarks25 = $_POST['remarks25'];
	// 	$remarks26 = $_POST['remarks26'];
	// 	$remarks27 = $_POST['remarks27'];
	// 	$doctor = $_POST['doctor'];
	// 	$counsellor = $_POST['counsellor'];
	// 	$nurse = $_POST['nurse'];

	// 	// connect to mysql database using mysqli
		

	// 	// mysql query to insert data
	// 	$query = "INSERT INTO `pre_embryo_transfer`(`patient_id`, `receipt_number`, `status`,`partners_name`,`art_bank_reg_no`,`form_id`,`surrogate_id`,`last_menstrual_period`,`date1`,`date2`,`date3`,`date4`,`date5`,`date6`,`date7`,`date8`,`date9`,`date10`,`date11`,`date12`,`date13`,`date14`,`date15`,`date16`,`date17`,`date18`,`date19`,`date20`,`date21`,`date22`,`date23`,`date24`,`date25`,`date26`,`date27`,`endometrial_thickness1`,`endometrial_thickness2`,`endometrial_thickness3`,`endometrial_thickness4`,`endometrial_thickness5`,`endometrial_thickness6`,`endometrial_thickness7`,`endometrial_thickness8`,`endometrial_thickness9`,`endometrial_thickness10`,`endometrial_thickness11`,`endometrial_thickness12`,`endometrial_thickness13`,`endometrial_thickness14`,`endometrial_thickness15`,`endometrial_thickness16`,`endometrial_thickness17`,`endometrial_thickness18`,`endometrial_thickness19`,`endometrial_thickness20`,`endometrial_thickness21`,`endometrial_thickness22`,`endometrial_thickness23`,`endometrial_thickness24`,`endometrial_thickness25`,`endometrial_thickness26`,`endometrial_thickness27`,`estrogen1`,`estrogen2`,`estrogen3`,`estrogen4`,`estrogen5`,`estrogen6`,`estrogen7`,`estrogen8`,`estrogen9`,`estrogen10`,`estrogen11`,`estrogen12`,`estrogen13`,`estrogen14`,`estrogen15`,`estrogen16`,`estrogen17`,`estrogen18`,`estrogen19`,`estrogen20`,`estrogen21`,`estrogen22`,`estrogen23`,`estrogen24`,`estrogen25`,`estrogen26`,`estrogen27`,`progesterone1`,`progesterone2`,`progesterone3`,`progesterone4`,`progesterone5`,`progesterone6`,`progesterone7`,`progesterone8`,`progesterone9`,`progesterone10`,`progesterone11`,`progesterone12`,`progesterone13`,`progesterone14`,`progesterone15`,`progesterone16`,`progesterone17`,`progesterone18`,`progesterone19`,`progesterone20`,`progesterone21`,`progesterone22`,`progesterone23`,`progesterone24`,`progesterone25`,`progesterone26`,`progesterone27`,`followup_on1`,`followup_on2`,`followup_on3`,`followup_on4`,`followup_on5`,`followup_on6`,`followup_on7`,`followup_on8`,`followup_on9`,`followup_on10`,`followup_on11`,`followup_on12`,`followup_on13`,`followup_on14`,`followup_on15`,`followup_on16`,`followup_on17`,`followup_on18`,`followup_on19`,`followup_on20`,`followup_on21`,`followup_on22`,`followup_on23`,`followup_on24`,`followup_on25`,`followup_on26`,`followup_on27`,`serum_e2_level1`,`serum_e2_level2`,`serum_e2_level3`,`serum_e2_level4`,`serum_e2_level5`,`serum_e2_level6`,`serum_e2_level7`,`serum_e2_level8`,`serum_e2_level9`,`serum_e2_level10`,`serum_e2_level11`,`serum_e2_level12`,`serum_e2_level13`,`serum_e2_level14`,`serum_e2_level15`,`serum_e2_level16`,`serum_e2_level17`,`serum_e2_level18`,`serum_e2_level19`,`serum_e2_level20`,`serum_e2_level21`,`serum_e2_level22`,`serum_e2_level23`,`serum_e2_level24`,`serum_e2_level25`,`serum_e2_level26`,`serum_e2_level27`,`serum_progesterone_level1`,`serum_progesterone_level2`,`serum_progesterone_level3`,`serum_progesterone_level4`,`serum_progesterone_level5`,`serum_progesterone_level6`,`serum_progesterone_level7`,`serum_progesterone_level8`,`serum_progesterone_level9`,`serum_progesterone_level10`,`serum_progesterone_level11`,`serum_progesterone_level12`,`serum_progesterone_level13`,`serum_progesterone_level14`,`serum_progesterone_level15`,`serum_progesterone_level16`,`serum_progesterone_level17`,`serum_progesterone_level18`,`serum_progesterone_level19`,`serum_progesterone_level20`,`serum_progesterone_level21`,`serum_progesterone_level22`,`serum_progesterone_level23`,`serum_progesterone_level24`,`serum_progesterone_level25`,`serum_progesterone_level26`,`serum_progesterone_level27`,`other_investigation1`,`other_investigation2`,`other_investigation3`,`other_investigation4`,`other_investigation5`,`other_investigation6`,`other_investigation7`,`other_investigation8`,`other_investigation9`,`other_investigation10`,`other_investigation11`,`other_investigation12`,`other_investigation13`,`other_investigation14`,`other_investigation15`,`other_investigation16`,`other_investigation17`,`other_investigation18`,`other_investigation19`,`other_investigation20`,`other_investigation21`,`other_investigation22`,`other_investigation23`,`other_investigation24`,`other_investigation25`,`other_investigation26`,`other_investigation27`,`medicine_added1`,`medicine_added2`,`medicine_added3`,`medicine_added4`,`medicine_added5`,`medicine_added6`,`medicine_added7`,`medicine_added8`,`medicine_added9`,`medicine_added10`,`medicine_added11`,`medicine_added12`,`medicine_added13`,`medicine_added14`,`medicine_added15`,`medicine_added16`,`medicine_added17`,`medicine_added18`,`medicine_added19`,`medicine_added20`,`medicine_added21`,`medicine_added22`,`medicine_added23`,`medicine_added24`,`medicine_added25`,`medicine_added26`,`medicine_added27`,`remarks1`,`remarks2`,`remarks3`,`remarks4`,`remarks5`,`remarks6`,`remarks7`,`remarks8`,`remarks9`,`remarks10`,`remarks11`,`remarks12`,`remarks13`,`remarks14`,`remarks15`,`remarks16`,`remarks17`,`remarks18`,`remarks19`,`remarks20`,`remarks21`,`remarks22`,`remarks23`,`remarks24`,`remarks25`,`remarks26`,`remarks27`,`doctor`,`counsellor`,`nurse`) VALUES ('$patient_id','$receipt_number','$status','$partners_name','$art_bank_reg_no','$form_id','$surrogate_id','$last_menstrual_period','$date1','$date2','$date3','$date4','$date5','$date6','$date7','$date8','$date9','$date10','$date11','$date12','$date13','$date14','$date15','$date16','$date17','$date18','$date19','$date20','$date21','$date22','$date23','$date24','$date25','$date26','$date27','$endometrial_thickness1','$endometrial_thickness2','$endometrial_thickness3','$endometrial_thickness4','$endometrial_thickness5','$endometrial_thickness6','$endometrial_thickness7','$endometrial_thickness8','$endometrial_thickness9','$endometrial_thickness10','$endometrial_thickness11','$endometrial_thickness12','$endometrial_thickness13','$endometrial_thickness14','$endometrial_thickness15','$endometrial_thickness16','$endometrial_thickness17','$endometrial_thickness18','$endometrial_thickness19','$endometrial_thickness20','$endometrial_thickness21','$endometrial_thickness22','$endometrial_thickness23','$endometrial_thickness24','$endometrial_thickness25','$endometrial_thickness26','$endometrial_thickness27','$estrogen1','$estrogen2','$estrogen3','$estrogen4','$estrogen5','$estrogen6','$estrogen7','$estrogen8','$estrogen9','$estrogen10','$estrogen11','$estrogen12','$estrogen13','$estrogen14','$estrogen15','$estrogen16','$estrogen17','$estrogen18','$estrogen19','$estrogen20','$estrogen21','$estrogen22','$estrogen23','$estrogen24','$estrogen25','$estrogen26','$estrogen27','$progesterone1','$progesterone2','$progesterone3','$progesterone4','$progesterone5','$progesterone6','$progesterone7','$progesterone8','$progesterone9','$progesterone10','$progesterone11','$progesterone12','$progesterone13','$progesterone14','$progesterone15','$progesterone16','$progesterone17','$progesterone18','$progesterone19','$progesterone20','$progesterone21','$progesterone22','$progesterone23','$progesterone24','$progesterone25','$progesterone26','$progesterone27','$followup_on1','$followup_on2','$followup_on3','$followup_on4','$followup_on5','$followup_on6','$followup_on7','$followup_on8','$followup_on9','$followup_on10','$followup_on11','$followup_on12','$followup_on13','$followup_on14','$followup_on15','$followup_on16','$followup_on17','$followup_on18','$followup_on19','$followup_on20','$followup_on21','$followup_on22','$followup_on23','$followup_on24','$followup_on25','$followup_on26','$followup_on27','$serum_e2_level1','$serum_e2_level2','$serum_e2_level3','$serum_e2_level4','$serum_e2_level5','$serum_e2_level6','$serum_e2_level7','$serum_e2_level8','$serum_e2_level9','$serum_e2_level10','$serum_e2_level11','$serum_e2_level12','$serum_e2_level13','$serum_e2_level14','$serum_e2_level15','$serum_e2_level16','$serum_e2_level17','$serum_e2_level18','$serum_e2_level19','$serum_e2_level20','$serum_e2_level21','$serum_e2_level22','$serum_e2_level23','$serum_e2_level24','$serum_e2_level25','$serum_e2_level26','$serum_e2_level27','$serum_progesterone_level1','$serum_progesterone_level2','$serum_progesterone_level3','$serum_progesterone_level4','$serum_progesterone_level5','$serum_progesterone_level6','$serum_progesterone_level7','$serum_progesterone_level8','$serum_progesterone_level9','$serum_progesterone_level10','$serum_progesterone_level11','$serum_progesterone_level12','$serum_progesterone_level13','$serum_progesterone_level14','$serum_progesterone_level15','$serum_progesterone_level16','$serum_progesterone_level17','$serum_progesterone_level18','$serum_progesterone_level19','$serum_progesterone_level20','$serum_progesterone_level21','$serum_progesterone_level22','$serum_progesterone_level23','$serum_progesterone_level24','$serum_progesterone_level25','$serum_progesterone_level26','$serum_progesterone_level27','$other_investigation1','$other_investigation2','$other_investigation3','$other_investigation4','$other_investigation5','$other_investigation6','$other_investigation7','$other_investigation8','$other_investigation9','$other_investigation10','$other_investigation11','$other_investigation12','$other_investigation13','$other_investigation14','$other_investigation15','$other_investigation16','$other_investigation17','$other_investigation18','$other_investigation19','$other_investigation20','$other_investigation21','$other_investigation22','$other_investigation23','$other_investigation24','$other_investigation25','$other_investigation26','$other_investigation27','$medicine_added1','$medicine_added2','$medicine_added3','$medicine_added4','$medicine_added5','$medicine_added6','$medicine_added7','$medicine_added8','$medicine_added9','$medicine_added10','$medicine_added11','$medicine_added12','$medicine_added13','$medicine_added14','$medicine_added15','$medicine_added16','$medicine_added17','$medicine_added18','$medicine_added19','$medicine_added20','$medicine_added21','$medicine_added22','$medicine_added23','$medicine_added24','$medicine_added25','$medicine_added26','$medicine_added27','$remarks1','$remarks2','$remarks3','$remarks4','$remarks5','$remarks6','$remarks7','$remarks8','$remarks9','$remarks10','$remarks11','$remarks12','$remarks13','$remarks14','$remarks15','$remarks16','$remarks17','$remarks18','$remarks19','$remarks20','$remarks21','$remarks22','$remarks23','$remarks24','$remarks25','$remarks26','$remarks27','$doctor','$counsellor','$nurse')";
		
	// 	$result = mysqli_query($connect, $query);
		
	// 	if($result){
	// 		echo '<center>Data Inserted</center>';
	// 	}else{
	// 		echo '<center>Data Not Inserted</center>';
	// 	}
	// }
?>
<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
    
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">

    <input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
	<input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
	<input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
	<input type="hidden" value="pending" name="status"> 
	
	<table class="table-bordered" width="100%">
		<tr>
			
			<td colspan="2">
			    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
			            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
			            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
			            ){?>
			        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
			    <?php } ?>
			</td>
		</tr>
	</table>
			
	<table class="table-bordered" width="100%">
		<tr>
			<td colspan="2">SELF CYCLE (S)</td>
			<td style="color: black;" colspan="2">SURROGATE MOTHER CYCLE (SUR)</td>
		</tr>
		<tr>
			<td>Partners name</td>
			<td><input  type="text" value="<?php echo isset($select_result['partners_name'])?$select_result['partners_name']:""; ?>"   maxlength="20" name="partners_name" class="form-control"></td>
			<td style="color: black;">ART bank reg no</td>
			<td><input  type="text" value="<?php echo isset($select_result['art_bank_reg_no'])?$select_result['art_bank_reg_no']:""; ?>"   maxlength="20" name="art_bank_reg_no" class="form-control"></td>
		</tr>
		<tr>
			<td>ID</td>
			<td><input  type="text" value="<?php echo isset($select_result['form_id'])?$select_result['form_id']:""; ?>"   maxlength="20" name="form_id" class="form-control"></td>
			<td style="color: black;">Surrogate ID</td>
			<td><input  type="text" value="<?php echo isset($select_result['surrogate_id'])?$select_result['surrogate_id']:""; ?>"   maxlength="20" name="surrogate_id" class="form-control"></td>
		</tr>
		<tr>
			<td colspan="2">LAST MENSTRUAL PERIOD</td>
			<td colspan="2"><input  type="date" value="<?php echo isset($select_result['last_menstrual_period'])?$select_result['last_menstrual_period']:""; ?>"   name="last_menstrual_period" class="form-control"></td>
		</tr>
	</table>
	<div class="table-responsive">
		<table class="table-bordered" width="100%">
			<tr>
				<td style="width: 20%;"><br></td>
				<td colspan="10" style="background-color: yellow;">ESTROGEN</td>
				<td colspan="17" style="background-color: orange;">PROGESTERONE</td>
			</tr>
			<tr>
				<td>Day of Stimulation</td>
				<td style="background-color: yellow;">1</td>
				<td style="background-color: yellow;">2</td>
				<td style="background-color: yellow;">3</td>
				<td style="background-color: yellow;">4</td>
				<td style="background-color: yellow;">5</td>
				<td style="background-color: yellow;">6</td>
				<td style="background-color: yellow;">7</td>
				<td style="background-color: yellow;">8</td>
				<td style="background-color: yellow;">9</td>
				<td style="background-color: yellow;">10</td>
				<td style="background-color: orange;">11</td>
				<td style="background-color: orange;">12</td>
				<td style="background-color: orange;">13</td>
				<td style="background-color: orange;">14</td>
				<td style="background-color: orange;">15</td>
				<td style="background-color: orange;">16</td>
				<td style="background-color: orange;">17</td>
				<td style="background-color: orange;">18</td>
				<td style="background-color: orange;">19</td>
				<td style="background-color: orange;">20</td>
				<td style="background-color: orange;">21</td>
				<td style="background-color: orange;">22</td>
				<td style="background-color: orange;">23</td>
				<td style="background-color: orange;">24</td>
				<td style="background-color: orange;">25</td>
				<td style="background-color: orange;">26</td>
				<td style="background-color: orange;">27</td>
			</tr>
			<tr>
				<td>DATE</td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date1'])?$select_result['date1']:""; ?>"   name="date1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date2'])?$select_result['date2']:""; ?>"   name="date2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date3'])?$select_result['date3']:""; ?>"   name="date3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date4'])?$select_result['date4']:""; ?>"   name="date4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date5'])?$select_result['date5']:""; ?>"   name="date5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date6'])?$select_result['date6']:""; ?>"   name="date6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date7'])?$select_result['date7']:""; ?>"   name="date7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date8'])?$select_result['date8']:""; ?>"   name="date8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date9'])?$select_result['date9']:""; ?>"   name="date9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="date" value="<?php echo isset($select_result['date10'])?$select_result['date10']:""; ?>"   name="date10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date11'])?$select_result['date11']:""; ?>"   name="date11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date12'])?$select_result['date12']:""; ?>"   name="date12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date13'])?$select_result['date13']:""; ?>"   name="date13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date14'])?$select_result['date14']:""; ?>"   name="date14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date15'])?$select_result['date15']:""; ?>"   name="date15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date16'])?$select_result['date16']:""; ?>"   name="date16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date17'])?$select_result['date17']:""; ?>"   name="date17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date18'])?$select_result['date18']:""; ?>"   name="date18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date19'])?$select_result['date19']:""; ?>"   name="date19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date20'])?$select_result['date20']:""; ?>"   name="date20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date21'])?$select_result['date21']:""; ?>"   name="date21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date22'])?$select_result['date22']:""; ?>"   name="date22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date23'])?$select_result['date23']:""; ?>"   name="date23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date24'])?$select_result['date24']:""; ?>"   name="date24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date25'])?$select_result['date25']:""; ?>"   name="date25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date26'])?$select_result['date26']:""; ?>"   name="date26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="date" value="<?php echo isset($select_result['date27'])?$select_result['date27']:""; ?>"   name="date27" class="form-control"></td>
			</tr>
			<tr>
				<td>ENDOMETRIAL THICKNESS (cm)</td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness1'])?$select_result['endometrial_thickness1']:""; ?>"   min="0" name="endometrial_thickness1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness2'])?$select_result['endometrial_thickness2']:""; ?>"   min="0" name="endometrial_thickness2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness3'])?$select_result['endometrial_thickness3']:""; ?>"   min="0" name="endometrial_thickness3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness4'])?$select_result['endometrial_thickness4']:""; ?>"   min="0" name="endometrial_thickness4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness5'])?$select_result['endometrial_thickness5']:""; ?>"   min="0" name="endometrial_thickness5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness6'])?$select_result['endometrial_thickness6']:""; ?>"   min="0" name="endometrial_thickness6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness7'])?$select_result['endometrial_thickness7']:""; ?>"   min="0" name="endometrial_thickness7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness8'])?$select_result['endometrial_thickness8']:""; ?>"   min="0" name="endometrial_thickness8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness9'])?$select_result['endometrial_thickness9']:""; ?>"   min="0" name="endometrial_thickness9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness10'])?$select_result['endometrial_thickness10']:""; ?>"   min="0" name="endometrial_thickness10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness11'])?$select_result['endometrial_thickness11']:""; ?>"   min="0" name="endometrial_thickness11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness12'])?$select_result['endometrial_thickness12']:""; ?>"   min="0" name="endometrial_thickness12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness13'])?$select_result['endometrial_thickness13']:""; ?>"   min="0" name="endometrial_thickness13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness14'])?$select_result['endometrial_thickness14']:""; ?>"   min="0" name="endometrial_thickness14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness15'])?$select_result['endometrial_thickness15']:""; ?>"   min="0" name="endometrial_thickness15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness16'])?$select_result['endometrial_thickness16']:""; ?>"   min="0" name="endometrial_thickness16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness17'])?$select_result['endometrial_thickness17']:""; ?>"   min="0" name="endometrial_thickness17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness18'])?$select_result['endometrial_thickness18']:""; ?>"   min="0" name="endometrial_thickness18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness19'])?$select_result['endometrial_thickness19']:""; ?>"   min="0" name="endometrial_thickness19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness20'])?$select_result['endometrial_thickness20']:""; ?>"   min="0" name="endometrial_thickness20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness21'])?$select_result['endometrial_thickness21']:""; ?>"   min="0" name="endometrial_thickness21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness22'])?$select_result['endometrial_thickness22']:""; ?>"   min="0" name="endometrial_thickness22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness23'])?$select_result['endometrial_thickness23']:""; ?>"   min="0" name="endometrial_thickness23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness24'])?$select_result['endometrial_thickness24']:""; ?>"   min="0" name="endometrial_thickness24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness25'])?$select_result['endometrial_thickness25']:""; ?>"   min="0" name="endometrial_thickness25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness26'])?$select_result['endometrial_thickness26']:""; ?>"   min="0" name="endometrial_thickness26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="number" value="<?php echo isset($select_result['endometrial_thickness27'])?$select_result['endometrial_thickness27']:""; ?>"   min="0" name="endometrial_thickness27" class="form-control"></td>
			</tr>
			<tr>
				<td>ESTROGEN</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen1'])?$select_result['estrogen1']:""; ?>"   maxlength="20" name="estrogen1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen2'])?$select_result['estrogen2']:""; ?>"   maxlength="20" name="estrogen2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen3'])?$select_result['estrogen3']:""; ?>"   maxlength="20" name="estrogen3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen4'])?$select_result['estrogen4']:""; ?>"   maxlength="20" name="estrogen4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen5'])?$select_result['estrogen5']:""; ?>"   maxlength="20" name="estrogen5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen6'])?$select_result['estrogen6']:""; ?>"   maxlength="20" name="estrogen6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen7'])?$select_result['estrogen7']:""; ?>"   maxlength="20" name="estrogen7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen8'])?$select_result['estrogen8']:""; ?>"   maxlength="20" name="estrogen8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen9'])?$select_result['estrogen9']:""; ?>"   maxlength="20" name="estrogen9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['estrogen10'])?$select_result['estrogen10']:""; ?>"   maxlength="20" name="estrogen10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen11'])?$select_result['estrogen11']:""; ?>"   maxlength="20" name="estrogen11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen12'])?$select_result['estrogen12']:""; ?>"   maxlength="20" name="estrogen12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen13'])?$select_result['estrogen13']:""; ?>"   maxlength="20" name="estrogen13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen14'])?$select_result['estrogen14']:""; ?>"   maxlength="20" name="estrogen14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen15'])?$select_result['estrogen15']:""; ?>"   maxlength="20" name="estrogen15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen16'])?$select_result['estrogen16']:""; ?>"   maxlength="20" name="estrogen16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen17'])?$select_result['estrogen17']:""; ?>"   maxlength="20" name="estrogen17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen18'])?$select_result['estrogen18']:""; ?>"   maxlength="20" name="estrogen18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen19'])?$select_result['estrogen19']:""; ?>"   maxlength="20" name="estrogen19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen20'])?$select_result['estrogen20']:""; ?>"   maxlength="20" name="estrogen20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen21'])?$select_result['estrogen21']:""; ?>"   maxlength="20" name="estrogen21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen22'])?$select_result['estrogen22']:""; ?>"   maxlength="20" name="estrogen22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen23'])?$select_result['estrogen23']:""; ?>"   maxlength="20" name="estrogen23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen24'])?$select_result['estrogen24']:""; ?>"   maxlength="20" name="estrogen24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen25'])?$select_result['estrogen25']:""; ?>"   maxlength="20" name="estrogen25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen26'])?$select_result['estrogen26']:""; ?>"   maxlength="20" name="estrogen26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['estrogen27'])?$select_result['estrogen27']:""; ?>"   maxlength="20" name="estrogen27" class="form-control"></td>
			</tr>
			<tr>
				<td>PROGESTERONE</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone1'])?$select_result['progesterone1']:""; ?>"   maxlength="20" name="progesterone1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone2'])?$select_result['progesterone2']:""; ?>"   maxlength="20" name="progesterone2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone3'])?$select_result['progesterone3']:""; ?>"   maxlength="20" name="progesterone3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone4'])?$select_result['progesterone4']:""; ?>"   maxlength="20" name="progesterone4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone5'])?$select_result['progesterone5']:""; ?>"   maxlength="20" name="progesterone5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone6'])?$select_result['progesterone6']:""; ?>"   maxlength="20" name="progesterone6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone7'])?$select_result['progesterone7']:""; ?>"   maxlength="20" name="progesterone7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone8'])?$select_result['progesterone8']:""; ?>"   maxlength="20" name="progesterone8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone9'])?$select_result['progesterone9']:""; ?>"   maxlength="20" name="progesterone9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['progesterone10'])?$select_result['progesterone10']:""; ?>"   maxlength="20" name="progesterone10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone11'])?$select_result['progesterone11']:""; ?>"   maxlength="20" name="progesterone11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone12'])?$select_result['progesterone12']:""; ?>"   maxlength="20" name="progesterone12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone13'])?$select_result['progesterone13']:""; ?>"   maxlength="20" name="progesterone13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone14'])?$select_result['progesterone14']:""; ?>"   maxlength="20" name="progesterone14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone15'])?$select_result['progesterone15']:""; ?>"   maxlength="20" name="progesterone15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone16'])?$select_result['progesterone16']:""; ?>"   maxlength="20" name="progesterone16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone17'])?$select_result['progesterone17']:""; ?>"   maxlength="20" name="progesterone17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone18'])?$select_result['progesterone18']:""; ?>"   maxlength="20" name="progesterone18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone19'])?$select_result['progesterone19']:""; ?>"   maxlength="20" name="progesterone19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone20'])?$select_result['progesterone20']:""; ?>"   maxlength="20" name="progesterone20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone21'])?$select_result['progesterone21']:""; ?>"   maxlength="20" name="progesterone21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone22'])?$select_result['progesterone22']:""; ?>"   maxlength="20" name="progesterone22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone23'])?$select_result['progesterone23']:""; ?>"   maxlength="20" name="progesterone23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone24'])?$select_result['progesterone24']:""; ?>"   maxlength="20" name="progesterone24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone25'])?$select_result['progesterone25']:""; ?>"   maxlength="20" name="progesterone25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone26'])?$select_result['progesterone26']:""; ?>"   maxlength="20" name="progesterone26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['progesterone27'])?$select_result['progesterone27']:""; ?>"   maxlength="20" name="progesterone27" class="form-control"></td>
			</tr>
			<tr>
				<td>MEDICINE ADDED</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added1'])?$select_result['medicine_added1']:""; ?>"   maxlength="20" name="medicine_added1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added2'])?$select_result['medicine_added2']:""; ?>"   maxlength="20" name="medicine_added2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added3'])?$select_result['medicine_added3']:""; ?>"   maxlength="20" name="medicine_added3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added4'])?$select_result['medicine_added4']:""; ?>"   maxlength="20" name="medicine_added4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added5'])?$select_result['medicine_added5']:""; ?>"   maxlength="20" name="medicine_added5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added6'])?$select_result['medicine_added6']:""; ?>"   maxlength="20" name="medicine_added6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added7'])?$select_result['medicine_added7']:""; ?>"   maxlength="20" name="medicine_added7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added8'])?$select_result['medicine_added8']:""; ?>"   maxlength="20" name="medicine_added8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added9'])?$select_result['medicine_added9']:""; ?>"   maxlength="20" name="medicine_added9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['medicine_added10'])?$select_result['medicine_added10']:""; ?>"   maxlength="20" name="medicine_added10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added11'])?$select_result['medicine_added11']:""; ?>"   maxlength="20" name="medicine_added11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added12'])?$select_result['medicine_added12']:""; ?>"   maxlength="20" name="medicine_added12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added13'])?$select_result['medicine_added13']:""; ?>"   maxlength="20" name="medicine_added13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added14'])?$select_result['medicine_added14']:""; ?>"   maxlength="20" name="medicine_added14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added15'])?$select_result['medicine_added15']:""; ?>"   maxlength="20" name="medicine_added15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added16'])?$select_result['medicine_added16']:""; ?>"   maxlength="20" name="medicine_added16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added17'])?$select_result['medicine_added17']:""; ?>"   maxlength="20" name="medicine_added17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added18'])?$select_result['medicine_added18']:""; ?>"   maxlength="20" name="medicine_added18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added19'])?$select_result['medicine_added19']:""; ?>"   maxlength="20" name="medicine_added19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added20'])?$select_result['medicine_added20']:""; ?>"   maxlength="20" name="medicine_added20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added21'])?$select_result['medicine_added21']:""; ?>"   maxlength="20" name="medicine_added21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added22'])?$select_result['medicine_added22']:""; ?>"   maxlength="20" name="medicine_added22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added23'])?$select_result['medicine_added23']:""; ?>"   maxlength="20" name="medicine_added23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added24'])?$select_result['medicine_added24']:""; ?>"   maxlength="20" name="medicine_added24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added25'])?$select_result['medicine_added25']:""; ?>"   maxlength="20" name="medicine_added25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added26'])?$select_result['medicine_added26']:""; ?>"   maxlength="20" name="medicine_added26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['medicine_added27'])?$select_result['medicine_added27']:""; ?>"   maxlength="20" name="medicine_added27" class="form-control"></td>
			</tr>
			<tr>
				<td>REMARKS</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks1'])?$select_result['remarks1']:""; ?>"   maxlength="20" name="remarks1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks2'])?$select_result['remarks2']:""; ?>"   maxlength="20" name="remarks2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks3'])?$select_result['remarks3']:""; ?>"   maxlength="20" name="remarks3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks4'])?$select_result['remarks4']:""; ?>"   maxlength="20" name="remarks4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks5'])?$select_result['remarks5']:""; ?>"   maxlength="20" name="remarks5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks6'])?$select_result['remarks6']:""; ?>"   maxlength="20" name="remarks6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks7'])?$select_result['remarks7']:""; ?>"   maxlength="20" name="remarks7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks8'])?$select_result['remarks8']:""; ?>"   maxlength="20" name="remarks8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks9'])?$select_result['remarks9']:""; ?>"   maxlength="20" name="remarks9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks10'])?$select_result['remarks10']:""; ?>"   maxlength="20" name="remarks10" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks11'])?$select_result['remarks11']:""; ?>"   maxlength="20" name="remarks11" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks12'])?$select_result['remarks12']:""; ?>"   maxlength="20" name="remarks12" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks13'])?$select_result['remarks13']:""; ?>"   maxlength="20" name="remarks13" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks14'])?$select_result['remarks14']:""; ?>"   maxlength="20" name="remarks14" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks15'])?$select_result['remarks15']:""; ?>"   maxlength="20" name="remarks15" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks16'])?$select_result['remarks16']:""; ?>"   maxlength="20" name="remarks16" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks17'])?$select_result['remarks17']:""; ?>"   maxlength="20" name="remarks17" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks18'])?$select_result['remarks18']:""; ?>"   maxlength="20" name="remarks18" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks19'])?$select_result['remarks19']:""; ?>"   maxlength="20" name="remarks19" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks20'])?$select_result['remarks20']:""; ?>"   maxlength="20" name="remarks20" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks21'])?$select_result['remarks21']:""; ?>"   maxlength="20" name="remarks21" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks22'])?$select_result['remarks22']:""; ?>"   maxlength="20" name="remarks22" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks23'])?$select_result['remarks23']:""; ?>"   maxlength="20" name="remarks23" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks24'])?$select_result['remarks24']:""; ?>"   maxlength="20" name="remarks24" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks25'])?$select_result['remarks25']:""; ?>"   maxlength="20" name="remarks25" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks26'])?$select_result['remarks26']:""; ?>"   maxlength="20" name="remarks26" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['remarks27'])?$select_result['remarks27']:""; ?>"   maxlength="20" name="remarks27" class="form-control"></td>
			</tr>
			<tr>
				<td>FOLLOWUP ON</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on1'])?$select_result['followup_on1']:""; ?>"   maxlength="20" name="followup_on1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on2'])?$select_result['followup_on2']:""; ?>"   maxlength="20" name="followup_on2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on3'])?$select_result['followup_on3']:""; ?>"   maxlength="20" name="followup_on3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on4'])?$select_result['followup_on4']:""; ?>"   maxlength="20" name="followup_on4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on5'])?$select_result['followup_on5']:""; ?>"   maxlength="20" name="followup_on5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on6'])?$select_result['followup_on6']:""; ?>"   maxlength="20" name="followup_on6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on7'])?$select_result['followup_on7']:""; ?>"   maxlength="20" name="followup_on7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on8'])?$select_result['followup_on8']:""; ?>"   maxlength="20" name="followup_on8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on9'])?$select_result['followup_on9']:""; ?>"   maxlength="20" name="followup_on9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['followup_on10'])?$select_result['followup_on10']:""; ?>"   maxlength="20" name="followup_on10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on11'])?$select_result['followup_on11']:""; ?>"   maxlength="20" name="followup_on11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on12'])?$select_result['followup_on12']:""; ?>"   maxlength="20" name="followup_on12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on13'])?$select_result['followup_on13']:""; ?>"   maxlength="20" name="followup_on13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on14'])?$select_result['followup_on14']:""; ?>"   maxlength="20" name="followup_on14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on15'])?$select_result['followup_on15']:""; ?>"   maxlength="20" name="followup_on15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on16'])?$select_result['followup_on16']:""; ?>"   maxlength="20" name="followup_on16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on17'])?$select_result['followup_on17']:""; ?>"   maxlength="20" name="followup_on17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on18'])?$select_result['followup_on18']:""; ?>"   maxlength="20" name="followup_on18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on19'])?$select_result['followup_on19']:""; ?>"   maxlength="20" name="followup_on19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on20'])?$select_result['followup_on20']:""; ?>"   maxlength="20" name="followup_on20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on21'])?$select_result['followup_on21']:""; ?>"   maxlength="20" name="followup_on21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on22'])?$select_result['followup_on22']:""; ?>"   maxlength="20" name="followup_on22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on23'])?$select_result['followup_on23']:""; ?>"   maxlength="20" name="followup_on23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on24'])?$select_result['followup_on24']:""; ?>"   maxlength="20" name="followup_on24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on25'])?$select_result['followup_on25']:""; ?>"   maxlength="20" name="followup_on25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on26'])?$select_result['followup_on26']:""; ?>"   maxlength="20" name="followup_on26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['followup_on27'])?$select_result['followup_on27']:""; ?>"   maxlength="20" name="followup_on27" class="form-control"></td>
			</tr>
			<tr>
				<td>SERUM ESTRADIOL (E2) LEVEL</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level1'])?$select_result['serum_e2_level1']:""; ?>"   maxlength="20" name="serum_e2_level1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level2'])?$select_result['serum_e2_level2']:""; ?>"   maxlength="20" name="serum_e2_level2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level3'])?$select_result['serum_e2_level3']:""; ?>"   maxlength="20" name="serum_e2_level3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level4'])?$select_result['serum_e2_level4']:""; ?>"   maxlength="20" name="serum_e2_level4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level5'])?$select_result['serum_e2_level5']:""; ?>"   maxlength="20" name="serum_e2_level5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level6'])?$select_result['serum_e2_level6']:""; ?>"   maxlength="20" name="serum_e2_level6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level7'])?$select_result['serum_e2_level7']:""; ?>"   maxlength="20" name="serum_e2_level7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level8'])?$select_result['serum_e2_level8']:""; ?>"   maxlength="20" name="serum_e2_level8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level9'])?$select_result['serum_e2_level9']:""; ?>"   maxlength="20" name="serum_e2_level9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level10'])?$select_result['serum_e2_level10']:""; ?>"   maxlength="20" name="serum_e2_level10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level11'])?$select_result['serum_e2_level11']:""; ?>"   maxlength="20" name="serum_e2_level11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level12'])?$select_result['serum_e2_level12']:""; ?>"   maxlength="20" name="serum_e2_level12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level13'])?$select_result['serum_e2_level13']:""; ?>"   maxlength="20" name="serum_e2_level13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level14'])?$select_result['serum_e2_level14']:""; ?>"   maxlength="20" name="serum_e2_level14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level15'])?$select_result['serum_e2_level15']:""; ?>"   maxlength="20" name="serum_e2_level15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level16'])?$select_result['serum_e2_level16']:""; ?>"   maxlength="20" name="serum_e2_level16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level17'])?$select_result['serum_e2_level17']:""; ?>"   maxlength="20" name="serum_e2_level17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level18'])?$select_result['serum_e2_level18']:""; ?>"   maxlength="20" name="serum_e2_level18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level19'])?$select_result['serum_e2_level19']:""; ?>"   maxlength="20" name="serum_e2_level19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level20'])?$select_result['serum_e2_level20']:""; ?>"   maxlength="20" name="serum_e2_level20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level21'])?$select_result['serum_e2_level21']:""; ?>"   maxlength="20" name="serum_e2_level21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level22'])?$select_result['serum_e2_level22']:""; ?>"   maxlength="20" name="serum_e2_level22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level23'])?$select_result['serum_e2_level23']:""; ?>"   maxlength="20" name="serum_e2_level23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level24'])?$select_result['serum_e2_level24']:""; ?>"   maxlength="20" name="serum_e2_level24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level25'])?$select_result['serum_e2_level25']:""; ?>"   maxlength="20" name="serum_e2_level25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level26'])?$select_result['serum_e2_level26']:""; ?>"   maxlength="20" name="serum_e2_level26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_e2_level27'])?$select_result['serum_e2_level27']:""; ?>"   maxlength="20" name="serum_e2_level27" class="form-control"></td>
			</tr>
			<tr>
				<td>SERUM PROGESTERONE LEVEL</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level1'])?$select_result['serum_progesterone_level1']:""; ?>"   maxlength="20" name="serum_progesterone_level1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level2'])?$select_result['serum_progesterone_level2']:""; ?>"   maxlength="20" name="serum_progesterone_level2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level3'])?$select_result['serum_progesterone_level3']:""; ?>"   maxlength="20" name="serum_progesterone_level3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level4'])?$select_result['serum_progesterone_level4']:""; ?>"   maxlength="20" name="serum_progesterone_level4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level5'])?$select_result['serum_progesterone_level5']:""; ?>"   maxlength="20" name="serum_progesterone_level5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level6'])?$select_result['serum_progesterone_level6']:""; ?>"   maxlength="20" name="serum_progesterone_level6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level7'])?$select_result['serum_progesterone_level7']:""; ?>"   maxlength="20" name="serum_progesterone_level7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level8'])?$select_result['serum_progesterone_level8']:""; ?>"   maxlength="20" name="serum_progesterone_level8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level9'])?$select_result['serum_progesterone_level9']:""; ?>"   maxlength="20" name="serum_progesterone_level9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level10'])?$select_result['serum_progesterone_level10']:""; ?>"   maxlength="20" name="serum_progesterone_level10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level11'])?$select_result['serum_progesterone_level11']:""; ?>"   maxlength="20" name="serum_progesterone_level11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level12'])?$select_result['serum_progesterone_level12']:""; ?>"   maxlength="20" name="serum_progesterone_level12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level13'])?$select_result['serum_progesterone_level13']:""; ?>"   maxlength="20" name="serum_progesterone_level13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level14'])?$select_result['serum_progesterone_level14']:""; ?>"   maxlength="20" name="serum_progesterone_level14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level15'])?$select_result['serum_progesterone_level15']:""; ?>"   maxlength="20" name="serum_progesterone_level15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level16'])?$select_result['serum_progesterone_level16']:""; ?>"   maxlength="20" name="serum_progesterone_level16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level17'])?$select_result['serum_progesterone_level17']:""; ?>"   maxlength="20" name="serum_progesterone_level17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level18'])?$select_result['serum_progesterone_level18']:""; ?>"   maxlength="20" name="serum_progesterone_level18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level19'])?$select_result['serum_progesterone_level19']:""; ?>"   maxlength="20" name="serum_progesterone_level19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level20'])?$select_result['serum_progesterone_level20']:""; ?>"   maxlength="20" name="serum_progesterone_level20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level21'])?$select_result['serum_progesterone_level21']:""; ?>"   maxlength="20" name="serum_progesterone_level21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level22'])?$select_result['serum_progesterone_level22']:""; ?>"   maxlength="20" name="serum_progesterone_level22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level23'])?$select_result['serum_progesterone_level23']:""; ?>"   maxlength="20" name="serum_progesterone_level23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level24'])?$select_result['serum_progesterone_level24']:""; ?>"   maxlength="20" name="serum_progesterone_level24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level25'])?$select_result['serum_progesterone_level25']:""; ?>"   maxlength="20" name="serum_progesterone_level25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level26'])?$select_result['serum_progesterone_level26']:""; ?>"   maxlength="20" name="serum_progesterone_level26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['serum_progesterone_level27'])?$select_result['serum_progesterone_level27']:""; ?>"   maxlength="20" name="serum_progesterone_level27" class="form-control"></td>
			</tr>
			<tr>
				<td>OTHER INVESTIGATION</td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation1'])?$select_result['other_investigation1']:""; ?>"   maxlength="20" name="other_investigation1" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation2'])?$select_result['other_investigation2']:""; ?>"   maxlength="20" name="other_investigation2" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation3'])?$select_result['other_investigation3']:""; ?>"   maxlength="20" name="other_investigation3" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation4'])?$select_result['other_investigation4']:""; ?>"   maxlength="20" name="other_investigation4" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation5'])?$select_result['other_investigation5']:""; ?>"   maxlength="20" name="other_investigation5" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation6'])?$select_result['other_investigation6']:""; ?>"   maxlength="20" name="other_investigation6" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation7'])?$select_result['other_investigation7']:""; ?>"   maxlength="20" name="other_investigation7" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation8'])?$select_result['other_investigation8']:""; ?>"   maxlength="20" name="other_investigation8" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation9'])?$select_result['other_investigation9']:""; ?>"   maxlength="20" name="other_investigation9" class="form-control"></td>
				<td style="background-color: yellow;"><input  type="text" value="<?php echo isset($select_result['other_investigation10'])?$select_result['other_investigation10']:""; ?>"   maxlength="20" name="other_investigation10" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation11'])?$select_result['other_investigation11']:""; ?>"   maxlength="20" name="other_investigation11" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation12'])?$select_result['other_investigation12']:""; ?>"   maxlength="20" name="other_investigation12" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation13'])?$select_result['other_investigation13']:""; ?>"   maxlength="20" name="other_investigation13" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation14'])?$select_result['other_investigation14']:""; ?>"   maxlength="20" name="other_investigation14" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation15'])?$select_result['other_investigation15']:""; ?>"   maxlength="20" name="other_investigation15" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation16'])?$select_result['other_investigation16']:""; ?>"   maxlength="20" name="other_investigation16" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation17'])?$select_result['other_investigation17']:""; ?>"   maxlength="20" name="other_investigation17" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation18'])?$select_result['other_investigation18']:""; ?>"   maxlength="20" name="other_investigation18" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation19'])?$select_result['other_investigation19']:""; ?>"   maxlength="20" name="other_investigation19" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation20'])?$select_result['other_investigation20']:""; ?>"   maxlength="20" name="other_investigation20" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation21'])?$select_result['other_investigation21']:""; ?>"   maxlength="20" name="other_investigation21" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation22'])?$select_result['other_investigation22']:""; ?>"   maxlength="20" name="other_investigation22" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation23'])?$select_result['other_investigation23']:""; ?>"   maxlength="20" name="other_investigation23" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation24'])?$select_result['other_investigation24']:""; ?>"   maxlength="20" name="other_investigation24" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation25'])?$select_result['other_investigation25']:""; ?>"   maxlength="20" name="other_investigation25" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation26'])?$select_result['other_investigation26']:""; ?>"   maxlength="20" name="other_investigation26" class="form-control"></td>
				<td style="background-color: orange;"><input  type="text" value="<?php echo isset($select_result['other_investigation27'])?$select_result['other_investigation27']:""; ?>"   maxlength="20" name="other_investigation27" class="form-control"></td>
			</tr>
		</table>
		<table width="100%">
			<tr>
				<td>DOCTOR <input  type="text" value="<?php echo isset($select_result['doctor'])?$select_result['doctor']:""; ?>"   maxlength="20" name="doctor" class="form-control"></td>
				<td>COUNSELLOR <input  type="text" value="<?php echo isset($select_result['counsellor'])?$select_result['counsellor']:""; ?>"   maxlength="20" name="counsellor" class="form-control"></td>
				<td>NURSE <input  type="text" value="<?php echo isset($select_result['nurse'])?$select_result['nurse']:""; ?>"   maxlength="20" name="nurse" class="form-control"></td>
			</tr>
		</table>
	</div>
	<!-- /.card-body -->
	<div class="card-footer">
		<!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
		<input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
	</div>
</form>