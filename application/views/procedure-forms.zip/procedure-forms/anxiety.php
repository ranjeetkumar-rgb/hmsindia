<?php
	// php code to Insert data into mysql database from input text
	if(isset($_POST['submit'])){
        $updated_by = $_POST['updated_by'];
        $updated_type = $_POST['updated_type'];
        $updated_at = $_POST['updated_at'];
        
        $procedure_id = $_POST['procedure_id'];
        $patient_id = $_POST['patient_id'];
        $receipt_number = $_POST['receipt_number'];
		$status = $_POST['status'];
		// get values form input text and numbe
		$feel_fine = $_POST['feel_fine'];
		$feel_satisfied = $_POST['feel_satisfied'];
		$not_important = $_POST['not_important'];
		$happy = $_POST['happy'];
		$troubled_dusturbing = $_POST['troubled_dusturbing'];
		$feel_safe = $_POST['feel_safe'];
		$pleased = $_POST['pleased'];
		$haunting = $_POST['haunting'];
		$disappointments = $_POST['disappointments'];
		$nervous = $_POST['nervous'];
		$feeling_sad = $_POST['feeling_sad'];
		$discouraged = $_POST['discouraged'];
		$failure = $_POST['failure'];
		$satisfied = $_POST['satisfied'];
		$disappointed = $_POST['disappointed'];
		$comparison = $_POST['comparison'];
		$suicide = $_POST['suicide'];
		$someone_to_help = $_POST['someone_to_help'];
		$someone_to_talk = $_POST['someone_to_talk'];
		$comfort_me = $_POST['comfort_me'];
		$someone_to_talk_when_sad = $_POST['someone_to_talk_when_sad'];
		$help_with_job = $_POST['help_with_job'];
		$fertility_problems = $_POST['fertility_problems'];
		$fertility_problems_consequences = $_POST['fertility_problems_consequences'];
		$learned_to_live = $_POST['learned_to_live'];
		$control_life = $_POST['control_life'];
		$feeling_useless = $_POST['feeling_useless'];
		$incomplete = $_POST['incomplete'];
		$learned_to_accept = $_POST['learned_to_accept'];
		$affect_important_things = $_POST['affect_important_things'];
		$accept_fertility_problems = $_POST['accept_fertility_problems'];
		$cope_with_unsolved_fertility_problems = $_POST['cope_with_unsolved_fertility_problems'];
		$helpless = $_POST['helpless'];
		$cope_with_fertility_problems = $_POST['cope_with_fertility_problems'];

		// connect to mysql database using mysqli
		

		// mysql query to insert data
		$query = "INSERT INTO `anxiety`(`updated_by`,`updated_type`,`updated_at`,`procedure_id`, `patient_id`, `receipt_number`, `status`,`feel_fine`,`feel_satisfied`,`not_important`,`happy`,`troubled_dusturbing`,`feel_safe`,`pleased`,`haunting`,`disappointments`,`nervous`,`feeling_sad`,`discouraged`,`failure`,`satisfied`,`disappointed`,`comparison`,`suicide`,`someone_to_help`,`someone_to_talk`,`comfort_me`,`someone_to_talk_when_sad`,`help_with_job`,`fertility_problems`,`fertility_problems_consequences`,`learned_to_live`,`control_life`,`feeling_useless`,`incomplete`,`learned_to_accept`,`affect_important_things`,`accept_fertility_problems`,`cope_with_unsolved_fertility_problems`,`helpless`,`cope_with_fertility_problems`) VALUES ('$updated_by', '$updated_type','$updated_at','$procedure_id', '$patient_id','$receipt_number','$status','$feel_fine','$feel_satisfied','$not_important','$happy','$troubled_dusturbing','$feel_safe','$pleased','$haunting','$disappointments','$nervous','$feeling_sad','$discouraged','$failure','$satisfied','$disappointed','$comparison','$suicide','$someone_to_help','$someone_to_talk','$comfort_me','$someone_to_talk_when_sad','$help_with_job','$fertility_problems','$fertility_problems_consequences','$learned_to_live','$control_life','$feeling_useless','$incomplete','$learned_to_accept','$affect_important_things','$accept_fertility_problems','$cope_with_unsolved_fertility_problems','$helpless','$cope_with_fertility_problems')";
	
		$result = run_form_query($query);

        if($result){
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Procedure form inserted!').'&t='.base64_encode('success'));
					die();
        }else{
          header("location:" .$_SERVER['HTTP_REFERER']."?m=".base64_encode('Something went wrong!').'&t='.base64_encode('error'));
					die();
        }
	}
?>
<form enctype='multipart/form-data'  class ="searchform" name="form" action="" method="POST">
<input type="hidden" value="<?php echo $updated_by; ?>" class="form" name="updated_by">
<input type="hidden" value="<?php echo $updated_type; ?>" class="form" name="updated_type">
<input type="hidden" value="<?php echo $updated_at; ?>" class="form" name="updated_at">
  
<input type="hidden" value="<?php echo $procedure_id; ?>" class="form" name="procedure_id">
<input type="hidden" value="<?php echo $patient_id; ?>" class="form" name="patient_id">
<input type="hidden" value="<?php echo $receipt_number; ?>" class="form" name="receipt_number">
<input type="hidden" value="pending" name="status"> 
<table class="table-bordered" width="100%">
	<tr>
		<td colspan="2">
		    <?php if(isset($select_result['updated_by']) && !empty($select_result['updated_by']) &&
		            isset($select_result['updated_at']) && !empty($select_result['updated_at']) && 
		            isset($select_result['updated_type']) && !empty($select_result['updated_type'])
		            ){?>
		        <p id="last_updated">Last updated on <?php echo $select_result['updated_at']; ?> by <?php echo last_updated_user($select_result['updated_type'],$select_result['updated_by']); ?></p>
		    <?php } ?>
		</td>
	</tr>
</table>
<table class="table-bordered" width="100%">
	<tr>
		<td>I feel fine</td>
		<td>
			<select class="form-control" name="feel_fine">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I feel satisfied</td>
		<td>
			<select class="form-control" name="feel_satisfied">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I worry too much about not really important things</td>
		<td>
			<select class="form-control" name="not_important">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I am happy</td>
		<td>
			<select class="form-control" name="happy">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I am troubled by disturbing thoughts</td>
		<td>
			<select class="form-control" name="troubled_dusturbing">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I feel safe</td>
		<td>
			<select class="form-control" name="feel_safe">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I am pleased</td>
		<td>
			<select class="form-control" name="pleased">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>There are thoughts that keep haunting me</td>
		<td>
			<select class="form-control" name="haunting">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I take disappointments so seriously that I cannot get them out of my mind</td>
		<td>
			<select class="form-control" name="disappointments">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I get very nervous and worried when thinking about my current troubles</td>
		<td>
			<select class="form-control" name="nervous">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Often</option>
				<option value="4">Nearly always</option>
			</select>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<p>* reverse scoring, see instruction. Do not indicate asterisks on patient form</p>
			<p>Cut off 24 and above</p>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<h3>Depression</h3>
			<p>So it is about how you felt during the last week.</p>
		</td>
	</tr>
	<tr>
		<td>Are you feeling sad?</td>
		<td>
			<select class="form-control" name="feeling_sad">
				<option value="0">I do not feel sad.</option>
				<option value="1">I feel sad.</option>
				<option value="2">I am sad all the time and I can’t snap out of it.</option>
				<option value="3">I am so sad and unhappy that I can’t stand it.</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>Are you feeling discouraged?</td>
		<td>
			<select class="form-control" name="discouraged">
				<option value="0">I am not particularly discouraged about the future.</option>
				<option value="1">I feel discouraged about the future.</option>
				<option value="2">I feel I have nothing to look forward to.</option>
				<option value="3">I feel the future is hopeless and that things cannot improve.</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>Are do you feel about failure?</td>
		<td>
			<select class="form-control" name="failure">
				<option value="0">I do not feel like a failure.</option>
				<option value="1">I feel I have failed more than the average person.</option>
				<option value="2">As I look back on my life, all I can see is a lot of failures.</option>
				<option value="3">I feel I am a complete failure as a person.</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>How much satisfied are you?</td>
		<td>
			<select class="form-control" name="satisfied">
				<option value="0">I get as much satisfaction out of things as I used to.</option>
				<option value="1">I don’t enjoy things the way I used to.</option>
				<option value="2">I don’t get real satisfaction out of anything anymore.</option>
				<option value="3">I am dissatisfied or bored with everything.</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>Do you feel disappointed?</td>
		<td>
			<select class="form-control" name="disappointed">
				<option value="0">I don’t feel disappointed in myself.</option>
				<option value="1">I am disappointed in myself.</option>
				<option value="2">I am disgusted with myself.</option>
				<option value="3">I hate myself.</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>How do you feel about yourself in comparison with others?</td>
		<td>
			<select class="form-control" name="comparison">
				<option value="0">I don’t feel I am any worse than anybody else.</option>
				<option value="1">I am critical of myself for my weaknesses or mistakes.</option>
				<option value="2">I blame myself all the time for my faults.</option>
				<option value="3">I blame myself for everything bad that happens.</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>Do think of committing suicide?</td>
		<td>
			<select class="form-control" name="suicide">
				<option value="0">I don’t have any thoughts about killing myself.</option>
				<option value="1">I have thoughts about killing myself, but I would not carry them out.</option>
				<option value="2">I would like to kill myself.</option>
				<option value="3">I would like to kill myself if I had the chance.</option>
			</select>
		</td>
	</tr>
	<tr>
		<td colspan="2"><p>Cut off 4</p></td>
	</tr>
	<tr>
		<td colspan="2">
			<h3>Social support</h3>
			<p>The questions refer to how you felt about your social relationships the last six months.</p>
		</td>
	</tr>
	<tr>
	<tr>
		<td>When I feel tense or nervous, there is someone to help me</td>
		<td>
			<select class="form-control" name="someone_to_help">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Regularly</option>
				<option value="4">Often</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>When I experience some nice things, there is someone with whom to talk about it</td>
		<td>
			<select class="form-control" name="someone_to_talk">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Regularly</option>
				<option value="4">Often</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>When I am in pain there is someone to comfort me</td>
		<td>
			<select class="form-control" name="comfort_me">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Regularly</option>
				<option value="4">Often</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>When I am sad there is someone with whom to talk about it</td>
		<td>
			<select class="form-control" name="someone_to_talk_when_sad">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Regularly</option>
				<option value="4">Often</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>When I need help with a job I cannot carry out alone there is someone to help me</td>
		<td>
			<select class="form-control" name="help_with_job">
				<option value="1">Nearly never</option>
				<option value="2">Sometimes</option>
				<option value="3">Regularly</option>
				<option value="4">Often</option>
			</select>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<h3>Cognitions regarding fertility problems</h3>
			<p>The next items are statements from people with fertility problems. We ask you to indicate to what extent you agree with the statements. You can do that by encircling the number next to the statement that most closely matches with what you think about the statement. Do not think too deeply, your first impression is usually best.</p>
		</td>
	</tr>
	<tr>
		<td>Because of my fertility problems I miss things that are most important for me</td>
		<td>
			<select class="form-control" name="fertility_problems">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I can deal with the consequences of my fertility problems</td>
		<td>
			<select class="form-control" name="fertility_problems_consequences">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I have learned to live with my fertility problems</td>
		<td>
			<select class="form-control" name="learned_to_live">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>My fertility problems control my life</td>
		<td>
			<select class="form-control" name="control_life">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>My fertility problems sometimes give me the feeling of being useless</td>
		<td>
			<select class="form-control" name="feeling_useless">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>My fertility problems make my life incomplete</td>
		<td>
			<select class="form-control" name="incomplete">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I have learned to accept my fertility problems</td>
		<td>
			<select class="form-control" name="learned_to_accept">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>My fertility problems affect everything that is important for me</td>
		<td>
			<select class="form-control" name="affect_important_things">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I can accept my fertility problems</td>
		<td>
			<select class="form-control" name="accept_fertility_problems">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I think I can cope with my fertility problems, even if they are not solved</td>
		<td>
			<select class="form-control" name="cope_with_unsolved_fertility_problems">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I often feel helpless because of my fertility Problems</td>
		<td>
			<select class="form-control" name="helpless">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>I can cope well with my fertility problems</td>
		<td>
			<select class="form-control" name="cope_with_fertility_problems">
				<option value="1">Do not agree</option>
				<option value="2">Agree a little bit</option>
				<option value="3">Agree</option>
				<option value="4">Strongly agree</option>
			</select>
		</td>
	</tr>
</table>
<!-- /.card-body -->
<div class="card-footer">
	<!-- <input type="" name="" class="btn btn-primary mt-2 mb-2" value="submit"> -->
	<input type="submit" name="submit" class="btn btn-primary mt-2 mb-2" value="submit">
</div>
</form>