
  <form class="col-sm-12 col-xs-12" method="post" action="" >
    <input type="hidden" name="action" value="update_item" />
    <input type="hidden" name="center_number" value="<?php echo $data['center_number']; ?>" />
    <div class="row">
      <div class="col-sm-12 col-xs-12 panel panel-piluku">
        <div class="panel-heading">
          <h3 class="heading">Edit Item</h3>
        </div>
        <div class="panel-body profile-edit">
          <p>
          
        <div class="row">
            <div class="form-group col-sm-6 col-xs-12">
              <label for="item_name">Center Name (Required)</label>
              <input value="<?php echo $data['center_name']; ?>" placeholder="Center name" id="center_name" name="center_name" type="text" class="form-control validate" required>
            </div>
            <div class="form-group col-sm-6 col-xs-12 role">
              <label for="item_name">Center Type (Required)</label>
              <select name="type" required>
                  <option value="">Select Type</option>
                  <option value="stand-alone" <?php if($data['type'] == "stand-alone"){echo "selected='selected'"; } ?>>Stand Alone</option>
                  <option value="associated" <?php if($data['type'] == "associated"){echo "selected='selected'"; } ?>>Associated</option>
              </select>
            </div>
        </div>
        
        <div class="form-group col-sm-6 col-xs-12">
            <label for="item_name">Center Location (Required)</label>
            <textarea value="" placeholder="Center location" id="center_location" name="center_location" class="form-control validate" required><?php echo $data['center_location']; ?></textarea>
          </div>

        <div class="row">
           <div class="form-group col-sm-6 col-xs-12">
              <label for="Landline">Status(Required)</label><br/>
               <input type="radio" name="status" <?php if($data['status'] == '1'){echo "checked='checked'";} ?> value="1" class="statuss" > Active 
               <input type="radio" name="status" <?php if($data['status'] == '0'){echo "checked='checked'";} ?> value="0" class="statuss"> Inactive
            </div>
        </div>
                   
        </div>
        <div class="clearfix"></div>
        <div class="form-group col-sm-12 col-xs-12">
          <input type="submit" id="submitbutton" class="btn btn-large" value="Submit" />
        </div>
        </p>
      </div>
    </div>
  </form>
